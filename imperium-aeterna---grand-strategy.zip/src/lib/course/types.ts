export type Track = "intro" | "bots" | "assistants" | "agents";

export type CalloutTone = "note" | "tip" | "warn";

export type LessonBlock =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "callout"; tone: CalloutTone; title: string; text: string }
  | { type: "code"; lang: string; title?: string; code: string }
  | {
      type: "compare";
      left: { title: string; items: string[] };
      right: { title: string; items: string[] };
    }
  | { type: "steps"; items: { title: string; text: string }[] }
  | { type: "list"; items: string[] }
  | { type: "diagram"; kind: "stack" | "loop" | "rag" }
  | {
      type: "quiz";
      id: string;
      question: string;
      options: string[];
      correct: number;
      explain: string;
    }
  | { type: "lab"; labId: string; label: string; hint: string }
  | { type: "widget"; kind: "tokens" | "temperature" | "roles" };

export type Lesson = {
  id: string;
  track: Track;
  number: string;
  title: string;
  kicker: string;
  minutes: number;
  summary: string;
  blocks: LessonBlock[];
};

export type LabId = "prompt" | "bot" | "tools" | "agent";

export type Lab = {
  id: LabId;
  title: string;
  kicker: string;
  summary: string;
};

export type BotDraft = {
  name: string;
  role: string;
  rules: string;
  temperature: number;
};
