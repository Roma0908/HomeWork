import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { BotDraft } from "./types";

const defaultBot: BotDraft = {
  name: "Репетитор",
  role: "Ты терпеливый репетитор по школьной математике. Объясняй коротко, простыми словами, с одним примером.",
  rules: "Не решай контрольные целиком — направляй вопросами. Если не знаешь — так и скажи. Не выходи за тему учёбы.",
  temperature: 0.4,
};

type ProgressState = {
  studentName: string;
  onboarded: boolean;
  completed: Record<string, boolean>;
  quizzes: Record<string, boolean>;
  lastLessonId: string;
  botDraft: BotDraft;
  examScore: number | null;
  setName: (name: string) => void;
  setOnboarded: () => void;
  markLesson: (id: string) => void;
  markQuiz: (id: string, passed: boolean) => void;
  setLast: (id: string) => void;
  setBotDraft: (draft: Partial<BotDraft>) => void;
  setExamScore: (score: number) => void;
  reset: () => void;
};

export const useProgress = create<ProgressState>()(
  persist(
    (set) => ({
      studentName: "",
      onboarded: false,
      completed: {},
      quizzes: {},
      lastLessonId: "intro",
      botDraft: defaultBot,
      examScore: null,
      setName: (studentName) => set({ studentName }),
      setOnboarded: () => set({ onboarded: true }),
      markLesson: (id) =>
        set((s) => ({ completed: { ...s.completed, [id]: true }, lastLessonId: id })),
      markQuiz: (id, passed) =>
        set((s) => ({ quizzes: { ...s.quizzes, [id]: passed } })),
      setLast: (lastLessonId) => set({ lastLessonId }),
      setBotDraft: (draft) =>
        set((s) => ({ botDraft: { ...s.botDraft, ...draft } })),
      setExamScore: (examScore) => set({ examScore }),
      reset: () =>
        set({
          completed: {},
          quizzes: {},
          lastLessonId: "intro",
          botDraft: defaultBot,
          examScore: null,
          onboarded: false,
        }),
    }),
    { name: "kafedra-progress-v1" },
  ),
);

export { defaultBot };
