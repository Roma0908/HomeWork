import type { ErrorComponentProps } from "@tanstack/react-router";
import { TriangleAlert } from "lucide-react";

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-paper px-6 text-center text-ink">
      <TriangleAlert className="size-8 text-danger" strokeWidth={1.75} aria-hidden="true" />
      <h1 className="font-display text-lg font-medium">Сбой на кафедре</h1>
      <p className="max-w-md text-sm break-words text-muted">
        {error.message || "Непредвиденная ошибка. Обнови страницу."}
      </p>
    </main>
  );
}

export function AppNotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-paper px-6 text-center text-ink">
      <h1 className="font-display text-2xl font-medium">Нет такой аудитории</h1>
      <p className="max-w-md text-sm text-muted">Эта страница не входит в журнал семестра.</p>
      <a href="/" className="mt-2 text-sm font-medium text-forest underline-offset-4 hover:underline">
        Во двор кафедры
      </a>
    </main>
  );
}
