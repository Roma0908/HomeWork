import { EraId, Nation, Province, Army, DiplomaticRelation, GameEvent, Technology, DiplomaticAttitude } from '../types/game';
import { VICTORIAN_NATIONS, WW2_NATIONS, MODERN_NATIONS, RENAISSANCE_NATIONS, ERA_SPECIFIC_EVENTS, HISTORICAL_ERAS } from './historicalEras';
import { getProvincesForEra } from './worldMapProvinces';
import { getTechnologiesForEra } from './eraTechnologies';
import { GAME_EVENTS } from './events';

export function getEraSetup(eraId: EraId) {
  let nations: Record<string, Nation> = {};
  let defaultPlayerId = 'britain_1836';
  let startYear = 1836;
  let startMonth = 1;
  let startDay = 1;

  if (eraId === 'victorian_1836') {
    nations = JSON.parse(JSON.stringify(VICTORIAN_NATIONS));
    defaultPlayerId = 'britain_1836';
    startYear = 1836;
  } else if (eraId === 'ww2_1939') {
    nations = JSON.parse(JSON.stringify(WW2_NATIONS));
    defaultPlayerId = 'ussr_1939';
    startYear = 1936;
  } else if (eraId === 'modern_2026') {
    nations = JSON.parse(JSON.stringify(MODERN_NATIONS));
    defaultPlayerId = 'russia_2026';
    startYear = 2024;
  } else {
    nations = JSON.parse(JSON.stringify(RENAISSANCE_NATIONS));
    defaultPlayerId = 'valerion';
    startYear = 1500;
  }

  const provinces = getProvincesForEra(eraId);
  const technologies = getTechnologiesForEra(eraId);
  const events = [...(ERA_SPECIFIC_EVENTS[eraId] || []), ...GAME_EVENTS];

  // Armies setup by era with generals and unit distributions
  const armies: Record<string, Army> = {};
  Object.values(nations).forEach(nation => {
    const armyId = `army_${nation.id}_1`;
    let armyName = `Гвардейский Корпус (${nation.name})`;
    let generalName = `Маршал ${nation.name}`;
    let infantryCount = 18000;
    let cavalryCount = 4500;
    let artilleryCount = 500;
    let eliteCount = 1500;

    if (eraId === 'ww2_1939') {
      armyName = `1-я Ударная Танковая Армия (${nation.name})`;
      generalName = nation.id === 'ussr_1939' ? 'Маршал Г. К. Жуков' :
                    nation.id === 'germany_1939' ? 'Генерал-фельдмаршал Э. фон Манштейн' :
                    nation.id === 'britain_1939' ? 'Фельдмаршал Б. Монтгомери' :
                    nation.id === 'usa_1939' ? 'Генерал Дж. Паттон' :
                    nation.id === 'japan_1939' ? 'Генерал Т. Ямасита' :
                    nation.id === 'france_1939' ? 'Генерал Ш. де Голль' :
                    `Командующий фронтом (${nation.name})`;
      infantryCount = 28000;
      cavalryCount = 7500; // Represents Tanks & Motorized
      artilleryCount = 900;
      eliteCount = 3000;
    } else if (eraId === 'modern_2026') {
      armyName = `Группа быстрого реагирования (${nation.name})`;
      generalName = `Командующий объединенной группировкой (${nation.name})`;
      infantryCount = 22000;
      cavalryCount = 6000; // Mechanized / Armor
      artilleryCount = 750;
      eliteCount = 3500;
    }

    const startProvId = provinces[nation.capitalProvinceId] ? nation.capitalProvinceId : Object.keys(provinces)[0];

    armies[armyId] = {
      id: armyId,
      name: armyName,
      nationId: nation.id,
      provinceId: startProvId,
      path: [],
      movementProgress: 0,
      units: {
        infantry: infantryCount,
        cavalry: cavalryCount,
        artillery: artilleryCount,
        siege: 60,
        elite: eliteCount
      },
      morale: 95,
      maxMorale: 100,
      general: { name: generalName, attack: 5, defense: 5, maneuver: 4, moraleBuff: 12 },
      isMoving: false,
      status: 'idle',
      isRebel: false,
      attritionRate: 0
    };
  });

  // Calculate Diplomatic Relationships & Stances (Friendship / Hatred / Rivalry)
  const diplomacy: Record<string, Record<string, DiplomaticRelation>> = {};
  const nationIds = Object.keys(nations);

  nationIds.forEach(idA => {
    diplomacy[idA] = {};
    nationIds.forEach(idB => {
      if (idA === idB) return;

      let opinion = 15;
      let attitude: DiplomaticAttitude = 'neutral';
      let attitudeReason = 'Дипломатический нейтралитет';
      let isAllied = false;
      let hasNonAggression = false;
      let hasTradeAgreement = false;
      let isAtWar = false;
      let isDeclaredRival = false;

      // Victorian 1836 Relations
      if (eraId === 'victorian_1836') {
        if ((idA === 'russia_1836' && idB === 'prussia_1836') || (idA === 'prussia_1836' && idB === 'russia_1836')) {
          opinion = 75; attitude = 'allied'; attitudeReason = 'Священный союз монархий (+75)'; hasNonAggression = true;
        } else if ((idA === 'russia_1836' && idB === 'austria_1836') || (idA === 'austria_1836' && idB === 'russia_1836')) {
          opinion = 65; attitude = 'friendly'; attitudeReason = 'Концерт Европы и монархическая солидарность (+65)'; hasNonAggression = true;
        } else if ((idA === 'britain_1836' && idB === 'russia_1836') || (idA === 'russia_1836' && idB === 'britain_1836')) {
          opinion = -60; attitude = 'rival'; attitudeReason = 'Большая Игра в Центральной Азии (-60)'; isDeclaredRival = true;
        } else if ((idA === 'ottoman_1836' && idB === 'russia_1836') || (idA === 'russia_1836' && idB === 'ottoman_1836')) {
          opinion = -85; attitude = 'nemesis'; attitudeReason = 'Вековой спор за Проливы и Балканы (-85)'; isDeclaredRival = true;
        } else if ((idA === 'ottoman_1836' && idB === 'egypt_1836') || (idA === 'egypt_1836' && idB === 'ottoman_1836')) {
          opinion = -90; attitude = 'nemesis'; attitudeReason = 'Османо-египетские войны за независимость (-90)'; isDeclaredRival = true;
        } else if ((idA === 'netherlands_1836' && idB === 'belgium_1836') || (idA === 'belgium_1836' && idB === 'netherlands_1836')) {
          opinion = -70; attitude = 'rival'; attitudeReason = 'Последствия Бельгийской революции 1830 г. (-70)'; isDeclaredRival = true;
        } else if ((idA === 'usa_1836' && idB === 'mexico_1836') || (idA === 'mexico_1836' && idB === 'usa_1836')) {
          opinion = -75; attitude = 'hostile'; attitudeReason = 'Территориальный спор за Техас (-75)'; isDeclaredRival = true;
        } else if ((idA === 'britain_1836' && idB === 'france_1836') || (idA === 'france_1836' && idB === 'britain_1836')) {
          opinion = -35; attitude = 'rival'; attitudeReason = 'Колониальное и морское соперничество (-35)';
        } else if ((idA === 'brazil_1836' && idB === 'argentina_1836') || (idA === 'argentina_1836' && idB === 'brazil_1836')) {
          opinion = -60; attitude = 'rival'; attitudeReason = 'Спор за контроль над бассейном Ла-Платы (-60)'; isDeclaredRival = true;
        } else if ((idA === 'peru_1836' && idB === 'argentina_1836') || (idA === 'argentina_1836' && idB === 'peru_1836')) {
          opinion = -50; attitude = 'hostile'; attitudeReason = 'Соперничество в Андах (-50)';
        }
      }
      // WW2 1939 Relations
      else if (eraId === 'ww2_1939') {
        if ((idA === 'germany_1939' && idB === 'britain_1939') || (idA === 'britain_1939' && idB === 'germany_1939')) {
          opinion = -100; attitude = 'nemesis'; attitudeReason = 'Тотальная война на уничтожение (-100)'; isAtWar = true; isDeclaredRival = true;
        } else if ((idA === 'germany_1939' && idB === 'france_1939') || (idA === 'france_1939' && idB === 'germany_1939')) {
          opinion = -100; attitude = 'nemesis'; attitudeReason = 'Состояние войны за Европу (-100)'; isAtWar = true; isDeclaredRival = true;
        } else if ((idA === 'britain_1939' && idB === 'france_1939') || (idA === 'france_1939' && idB === 'britain_1939')) {
          opinion = 95; attitude = 'allied'; attitudeReason = 'Военно-политический союз Союзников (+95)'; isAllied = true;
        } else if ((idA === 'germany_1939' && idB === 'italy_1939') || (idA === 'italy_1939' && idB === 'germany_1939')) {
          opinion = 90; attitude = 'allied'; attitudeReason = 'Стальной Пакт Держав Оси (+90)'; isAllied = true;
        } else if ((idA === 'japan_1939' && idB === 'china_1939') || (idA === 'china_1939' && idB === 'japan_1939')) {
          opinion = -100; attitude = 'nemesis'; attitudeReason = 'Японо-китайская война (-100)'; isAtWar = true; isDeclaredRival = true;
        } else if ((idA === 'ussr_1939' && idB === 'germany_1939') || (idA === 'germany_1939' && idB === 'ussr_1939')) {
          opinion = -40; attitude = 'rival'; attitudeReason = 'Пакт о ненападении Молотова-Риббентропа (+0 / вражда)'; hasNonAggression = true;
        } else if ((idA === 'ussr_1939' && idB === 'finland_1939') || (idA === 'finland_1939' && idB === 'ussr_1939')) {
          opinion = -85; attitude = 'hostile'; attitudeReason = 'Советско-финские территориальные споры (-85)'; isDeclaredRival = true;
        } else if ((idA === 'usa_1939' && idB === 'britain_1939') || (idA === 'britain_1939' && idB === 'usa_1939')) {
          opinion = 85; attitude = 'friendly'; attitudeReason = 'Программа Ленд-Лиза и общие ценности (+85)'; hasTradeAgreement = true;
        }
      }
      // Modern Day 2024 Relations
      else if (eraId === 'modern_2026') {
        const westernBlock = ['usa_2026', 'britain_2026', 'germany_2026', 'france_2026', 'poland_2026', 'italy_2026', 'canada_2026', 'australia_2026', 'japan_2026', 'korea_2026'];
        if (westernBlock.includes(idA) && westernBlock.includes(idB)) {
          opinion = 90; attitude = 'allied'; attitudeReason = 'Коллективная безопасность и союзные соглашения (+90)'; isAllied = true; hasTradeAgreement = true;
        } else if ((idA === 'russia_2026' && idB === 'ukraine_2026') || (idA === 'ukraine_2026' && idB === 'russia_2026')) {
          opinion = -100; attitude = 'nemesis'; attitudeReason = 'Открытый вооруженный конфликт (-100)'; isAtWar = true; isDeclaredRival = true;
        } else if ((idA === 'russia_2026' && idB === 'china_2026') || (idA === 'china_2026' && idB === 'russia_2026')) {
          opinion = 92; attitude = 'friendly'; attitudeReason = 'Всеобъемлющее стратегическое партнерство БРИКС (+92)'; hasTradeAgreement = true; hasNonAggression = true;
        } else if ((idA === 'usa_2026' && idB === 'russia_2026') || (idA === 'russia_2026' && idB === 'usa_2026')) {
          opinion = -85; attitude = 'rival'; attitudeReason = 'Глобальное геополитическое противостояние (-85)'; isDeclaredRival = true;
        } else if ((idA === 'usa_2026' && idB === 'china_2026') || (idA === 'china_2026' && idB === 'usa_2026')) {
          opinion = -50; attitude = 'rival'; attitudeReason = 'Технологическое и торговое соперничество (-50)'; isDeclaredRival = true;
        } else if ((idA === 'russia_2026' && idB === 'iran_2026') || (idA === 'iran_2026' && idB === 'russia_2026')) {
          opinion = 85; attitude = 'friendly'; attitudeReason = 'Военно-техническое партнерство (+85)'; hasTradeAgreement = true;
        } else if ((idA === 'saudi_2026' && idB === 'iran_2026') || (idA === 'iran_2026' && idB === 'saudi_2026')) {
          opinion = -65; attitude = 'rival'; attitudeReason = 'Региональное соперничество в Заливе (-65)';
        }
      }
      // Renaissance 1500 Relations
      else {
        if ((idA === 'valerion' && idB === 'castelia') || (idA === 'castelia' && idB === 'valerion')) {
          opinion = -60; attitude = 'rival'; attitudeReason = 'Борьба за Итальянские земли (-60)'; isDeclaredRival = true;
        } else if ((idA === 'castelia' && idB === 'al_zahir') || (idA === 'al_zahir' && idB === 'castelia')) {
          opinion = -85; attitude = 'nemesis'; attitudeReason = 'Религиозный конфликт и реконкиста (-85)'; isDeclaredRival = true;
        } else if ((idA === 'bergland' && idB === 'valerion') || (idA === 'valerion' && idB === 'bergland')) {
          opinion = -50; attitude = 'rival'; attitudeReason = 'Соперничество Габсбургов и Валуа (-50)';
        }
      }

      diplomacy[idA][idB] = {
        opinion,
        attitude,
        attitudeReason,
        isAllied,
        hasNonAggression,
        hasTradeAgreement,
        isAtWar,
        hasSanctions: opinion < -50,
        isVassal: false,
        isDeclaredRival,
        guaranteeIndependence: false,
        militaryAidSent: false,
        truceDaysRemaining: 0
      };
    });
  });

  return {
    nations,
    provinces,
    technologies,
    events,
    armies,
    diplomacy,
    defaultPlayerId,
    startDate: { day: startDay, month: startMonth, year: startYear }
  };
}
