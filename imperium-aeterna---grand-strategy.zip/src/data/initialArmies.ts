import { Army, DiplomaticRelation } from '../types/game';

export const INITIAL_ARMIES: Record<string, Army> = {
  'army_valerion_1': {
    id: 'army_valerion_1',
    name: 'I Имперский Легион Аврелии',
    nationId: 'valerion',
    provinceId: 'prov_aurelia',
    path: [],
    movementProgress: 0,
    units: { infantry: 12000, cavalry: 3500, artillery: 400, siege: 50, elite: 1000 },
    morale: 95,
    maxMorale: 100,
    general: { name: 'Маршал Тиберий Векс', attack: 4, defense: 4, maneuver: 3, moraleBuff: 10 },
    isMoving: false,
    status: 'idle'
  },
  'army_yarogor_1': {
    id: 'army_yarogor_1',
    name: 'Царская Дружина Китежа',
    nationId: 'yarogor',
    provinceId: 'prov_kitezh',
    path: [],
    movementProgress: 0,
    units: { infantry: 16000, cavalry: 4000, artillery: 300, siege: 40, elite: 1200 },
    morale: 90,
    maxMorale: 100,
    general: { name: 'Воевода Добрыня Радомир', attack: 5, defense: 5, maneuver: 2, moraleBuff: 12 },
    isMoving: false,
    status: 'idle'
  },
  'army_castelia_1': {
    id: 'army_castelia_1',
    name: 'Королевская Терция Сан-Леона',
    nationId: 'castelia',
    provinceId: 'prov_san_leon',
    path: [],
    movementProgress: 0,
    units: { infantry: 11000, cavalry: 2500, artillery: 500, siege: 60, elite: 800 },
    morale: 92,
    maxMorale: 100,
    general: { name: 'Герцог Гонсало де Кордоба', attack: 4, defense: 5, maneuver: 4, moraleBuff: 15 },
    isMoving: false,
    status: 'idle'
  },
  'army_al_zahir_1': {
    id: 'army_al_zahir_1',
    name: 'Гвардия Золотого Полумесяца',
    nationId: 'al_zahir',
    provinceId: 'prov_medinat',
    path: [],
    movementProgress: 0,
    units: { infantry: 10000, cavalry: 6000, artillery: 250, siege: 40, elite: 1500 },
    morale: 94,
    maxMorale: 100,
    general: { name: 'Эмир Халид аль-Джазири', attack: 5, defense: 3, maneuver: 5, moraleBuff: 12 },
    isMoving: false,
    status: 'idle'
  },
  'army_bergland_1': {
    id: 'army_bergland_1',
    name: 'Железный Корпус Айзенбурга',
    nationId: 'bergland',
    provinceId: 'prov_eisenburg',
    path: [],
    movementProgress: 0,
    units: { infantry: 13000, cavalry: 2000, artillery: 800, siege: 80, elite: 1000 },
    morale: 91,
    maxMorale: 100,
    general: { name: 'Генерал-фельдмаршал Блюхер', attack: 4, defense: 5, maneuver: 3, moraleBuff: 10 },
    isMoving: false,
    status: 'idle'
  },
  'army_serenissima_1': {
    id: 'army_serenissima_1',
    name: 'Кондотта Святого Марка',
    nationId: 'serenissima',
    provinceId: 'prov_rialto',
    path: [],
    movementProgress: 0,
    units: { infantry: 8000, cavalry: 2000, artillery: 350, siege: 30, elite: 600 },
    morale: 88,
    maxMorale: 100,
    general: { name: 'Капитан Бартоломео Коллеони', attack: 3, defense: 4, maneuver: 4, moraleBuff: 8 },
    isMoving: false,
    status: 'idle'
  },
  'army_ostmark_1': {
    id: 'army_ostmark_1',
    name: 'Имперский Полк Виндобоны',
    nationId: 'ostmark',
    provinceId: 'prov_vindobona',
    path: [],
    movementProgress: 0,
    units: { infantry: 9500, cavalry: 2500, artillery: 300, siege: 40, elite: 700 },
    morale: 89,
    maxMorale: 100,
    general: { name: 'Граф фон Траун', attack: 3, defense: 4, maneuver: 3, moraleBuff: 10 },
    isMoving: false,
    status: 'idle'
  },
  'army_minghai_1': {
    id: 'army_minghai_1',
    name: 'Нефритовая Армия Поднебесной',
    nationId: 'minghai',
    provinceId: 'prov_tiancheng',
    path: [],
    movementProgress: 0,
    units: { infantry: 22000, cavalry: 5000, artillery: 600, siege: 90, elite: 2500 },
    morale: 93,
    maxMorale: 100,
    general: { name: 'Генерал Ци Цзигуан', attack: 5, defense: 5, maneuver: 4, moraleBuff: 15 },
    isMoving: false,
    status: 'idle'
  },
  'army_golden_horde_1': {
    id: 'army_golden_horde_1',
    name: 'Крылатый Тумен Золотой Степи',
    nationId: 'golden_horde',
    provinceId: 'prov_sarai',
    path: [],
    movementProgress: 0,
    units: { infantry: 4000, cavalry: 12000, artillery: 50, siege: 20, elite: 1500 },
    morale: 96,
    maxMorale: 100,
    general: { name: 'Батыр Субэдей', attack: 6, defense: 2, maneuver: 6, moraleBuff: 14 },
    isMoving: false,
    status: 'idle'
  },
  'army_bohemia_1': {
    id: 'army_bohemia_1',
    name: 'Гуситский Вагенбург Праги',
    nationId: 'bohemia',
    provinceId: 'prov_praga',
    path: [],
    movementProgress: 0,
    units: { infantry: 9000, cavalry: 1800, artillery: 450, siege: 40, elite: 800 },
    morale: 92,
    maxMorale: 100,
    general: { name: 'Ян Жижка Младший', attack: 4, defense: 6, maneuver: 2, moraleBuff: 16 },
    isMoving: false,
    status: 'idle'
  },
  'army_magyar_1': {
    id: 'army_magyar_1',
    name: 'Черная Армия Корвина',
    nationId: 'magyar',
    provinceId: 'prov_buda',
    path: [],
    movementProgress: 0,
    units: { infantry: 11000, cavalry: 4500, artillery: 350, siege: 50, elite: 1200 },
    morale: 94,
    maxMorale: 100,
    general: { name: 'Палатин Пал Кинижи', attack: 5, defense: 4, maneuver: 4, moraleBuff: 12 },
    isMoving: false,
    status: 'idle'
  }
};

export function createInitialDiplomacy(nationIds: string[]): Record<string, Record<string, DiplomaticRelation>> {
  const diplo: Record<string, Record<string, DiplomaticRelation>> = {};

  nationIds.forEach(idA => {
    diplo[idA] = {};
    nationIds.forEach(idB => {
      if (idA === idB) return;
      // Default base neutral relation
      let opinion = 10;
      let isAllied = false;
      let hasNonAggression = false;
      let hasTradeAgreement = false;
      let isAtWar = false;

      // Historical rivalries and alliances
      if ((idA === 'valerion' && idB === 'bergland') || (idA === 'bergland' && idB === 'valerion')) {
        opinion = -45; // Traditional border rivalry
      } else if ((idA === 'valerion' && idB === 'ostmark') || (idA === 'ostmark' && idB === 'valerion')) {
        opinion = 60;
        isAllied = true;
        hasNonAggression = true;
      } else if ((idA === 'castelia' && idB === 'lusitania') || (idA === 'lusitania' && idB === 'castelia')) {
        opinion = 50;
        hasTradeAgreement = true;
        hasNonAggression = true;
      } else if ((idA === 'castelia' && idB === 'granada') || (idA === 'granada' && idB === 'castelia')) {
        opinion = -65; // Reconquista tension
      } else if ((idA === 'yarogor' && idB === 'golden_horde') || (idA === 'golden_horde' && idB === 'yarogor')) {
        opinion = -75; // Steppe raids
      } else if ((idA === 'yarogor' && idB === 'kievograd') || (idA === 'kievograd' && idB === 'yarogor')) {
        opinion = 40;
        hasNonAggression = true;
      } else if ((idA === 'serenissima' && idB === 'al_zahir') || (idA === 'al_zahir' && idB === 'serenissima')) {
        opinion = 35;
        hasTradeAgreement = true;
      } else if ((idA === 'bohemia' && idB === 'magyar') || (idA === 'magyar' && idB === 'bohemia')) {
        opinion = 30;
        hasNonAggression = true;
      }

      diplo[idA][idB] = {
        opinion,
        isAllied,
        hasNonAggression,
        hasTradeAgreement,
        isAtWar,
        hasSanctions: false,
        isVassal: false,
        truceDaysRemaining: 0
      };
    });
  });

  return diplo;
}
