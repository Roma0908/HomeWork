import { Technology } from '../types/game';

export const TECHNOLOGIES_DATA: Record<string, Technology> = {
  // Military
  'tech_infantry_1': {
    id: 'tech_infantry_1',
    name: 'Мушкеты и пики',
    category: 'military',
    tier: 1,
    cost: 100,
    description: 'Оснащение пехоты первыми кремневыми мушкетами и длинными пиками против кавалерии.',
    effects: '+15% к атаке пехоты, +5% к боевому духу армии',
    modifier: { infantryAttack: 0.15, moraleBonus: 5 }
  },
  'tech_cavalry_1': {
    id: 'tech_cavalry_1',
    name: 'Кавалерийский караколь',
    category: 'military',
    tier: 1,
    cost: 120,
    description: 'Тактика конного построения с последовательными залпами из пистолетов.',
    effects: '+20% к фланговой мощи кавалерии',
    modifier: { cavalryAttack: 0.20 }
  },
  'tech_artillery_1': {
    id: 'tech_artillery_1',
    name: 'Бронзовые осадные бомбарды',
    category: 'military',
    tier: 2,
    cost: 200,
    description: 'Литые орудия крупного калибра, способные сокрушать каменные бастионы.',
    effects: '+30% к урону артиллерии и ускорение осад на 25%',
    modifier: { artilleryAttack: 0.30 }
  },
  'tech_fort_1': {
    id: 'tech_fort_1',
    name: 'Бастионная фортификация',
    category: 'military',
    tier: 2,
    cost: 180,
    description: 'Звездчатые бастионы с низкими земляными валами против пушечных ядер.',
    effects: '+40% к защите крепостей, замедление вражеских осад',
    modifier: { fortDefense: 0.40 }
  },
  'tech_doctrine_1': {
    id: 'tech_doctrine_1',
    name: 'Генеральный штаб',
    category: 'military',
    tier: 3,
    cost: 320,
    description: 'Профессиональная организация армейского командования, картографии и снабжения.',
    effects: '+15% к максимуму рекрутов, +10% к общему моральному духу',
    modifier: { manpowerMaxBonus: 0.15, moraleBonus: 10 }
  },

  // Economy
  'tech_agri_1': {
    id: 'tech_agri_1',
    name: 'Трехпольный севооборот',
    category: 'economy',
    tier: 1,
    cost: 90,
    description: 'Передовая система земледелия, снижающая истощение почвы и дающая избыток зерна.',
    effects: '+20% к сбору налогов с провинций, +10% к росту населения',
    modifier: { taxEfficiency: 0.20 }
  },
  'tech_bank_1': {
    id: 'tech_bank_1',
    name: 'Векселя и двойная бухгалтерия',
    category: 'economy',
    tier: 2,
    cost: 170,
    description: 'Итальянские методы кредитования, позволяющие безопасно перемещать капиталы.',
    effects: '+25% к торговому доходу, снижает процент по займам',
    modifier: { tradeEfficiency: 0.25 }
  },
  'tech_industry_1': {
    id: 'tech_industry_1',
    name: 'Водяные мельницы и кузницы',
    category: 'economy',
    tier: 2,
    cost: 210,
    description: 'Использование гидроэнергии для привода кузнечных молотов и лесопилок.',
    effects: '+30% к производству товаров (железо, уголь, древесина)',
    modifier: { productionEfficiency: 0.30 }
  },
  'tech_trade_fleet': {
    id: 'tech_trade_fleet',
    name: 'Океанские каравеллы и торговые дома',
    category: 'economy',
    tier: 3,
    cost: 300,
    description: 'Крупнотоннажные торговые суда и монопольные купеческие гильдии.',
    effects: '+35% к торговому доходу всех провинций',
    modifier: { tradeEfficiency: 0.35 }
  },

  // Administration
  'tech_chancery_1': {
    id: 'tech_chancery_1',
    name: 'Королевская канцелярия',
    category: 'administration',
    tier: 1,
    cost: 110,
    description: 'Централизованный архив указов, налоговых реестров и земельных кадастров.',
    effects: '+15% к налоговой эффективности, снижение риска восстаний',
    modifier: { taxEfficiency: 0.15, stabilityCostReduction: 0.20 }
  },
  'tech_law_1': {
    id: 'tech_law_1',
    name: 'Единый судебный кодекс',
    category: 'administration',
    tier: 2,
    cost: 190,
    description: 'Унификация законов по всей территории державы взамен феодальных обычаев.',
    effects: '+25% к стабильности державы, удешевление поддержания порядка',
    modifier: { stabilityCostReduction: 0.25 }
  },
  'tech_meritocracy_1': {
    id: 'tech_meritocracy_1',
    name: 'Государственные экзамены',
    category: 'administration',
    tier: 3,
    cost: 280,
    description: 'Отбор чиновников по знаниям и заслугам вместо знатного происхождения.',
    effects: '+1 ежемесячное очко дипломатии и управления, +10% к налогам',
    modifier: { taxEfficiency: 0.10 }
  },

  // Science
  'tech_press_1': {
    id: 'tech_press_1',
    name: 'Печатный станок',
    category: 'science',
    tier: 1,
    cost: 100,
    description: 'Распространение книг, научных трактатов и карт с помощью наборного шрифта.',
    effects: '+25% к скорости исследования всех будущих технологий',
    modifier: { researchSpeed: 0.25 }
  },
  'tech_medicine_1': {
    id: 'tech_medicine_1',
    name: 'Полевая хирургия и карантины',
    category: 'science',
    tier: 2,
    cost: 180,
    description: 'Борьба с чумой и инфекциями, санитарные кордоны и лечение раненых.',
    effects: '+20% к восстановлению рекрутов, снижает небоевые потери',
    modifier: { manpowerMaxBonus: 0.20 }
  },
  'tech_metallurgy_1': {
    id: 'tech_metallurgy_1',
    name: 'Доменная плавка стали',
    category: 'science',
    tier: 2,
    cost: 240,
    description: 'Высокотемпературные печи для получения упругой стали для клинков и орудий.',
    effects: '+15% к урону всех родов войск, +25% к доходу от железа',
    modifier: { infantryAttack: 0.10, artilleryAttack: 0.15 }
  },
  'tech_navigation_1': {
    id: 'tech_navigation_1',
    name: 'Астролябия и точная картография',
    category: 'science',
    tier: 3,
    cost: 290,
    description: 'Измерение широты в открытом море и составление подробных генеральных карт.',
    effects: '+30% к скорости перемещения армий, открывает новые дипломатические контакты',
    modifier: { tradeEfficiency: 0.20 }
  }
};
