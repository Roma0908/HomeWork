import { Province, ResourceType, TerrainType, EraId } from '../types/game';

export interface ProvinceTemplate {
  id: string;
  name: string;
  capital: boolean;
  population: number;
  taxBase: number;
  productionBase: number;
  resource: ResourceType;
  terrain: TerrainType;
  center: [number, number];
  svgPath: string;
  neighborIds: string[];
  supplyLimit: number;
}

// World Map Canvas: 1900 x 950
// Complete geographical projection with recognizable continent shapes
export const BASE_WORLD_PROVINCES: Record<string, ProvinceTemplate> = {
  // ==========================================
  // 1. BRITISH ISLES
  // ==========================================
  'prov_london': {
    id: 'prov_london', name: 'Лондон и Англия', capital: true,
    population: 2400000, taxBase: 42, productionBase: 40, resource: 'coal', terrain: 'plains',
    center: [765, 330], svgPath: 'M 745,310 L 785,310 L 795,350 L 755,360 L 740,335 Z',
    neighborIds: ['prov_scotland', 'prov_ireland', 'prov_brussels', 'prov_paris', 'prov_amsterdam'],
    supplyLimit: 45000
  },
  'prov_scotland': {
    id: 'prov_scotland', name: 'Шотландия и Эдинбург', capital: false,
    population: 850000, taxBase: 20, productionBase: 24, resource: 'iron', terrain: 'hills',
    center: [750, 250], svgPath: 'M 735,215 L 770,225 L 775,280 L 735,285 L 725,245 Z',
    neighborIds: ['prov_london', 'prov_ireland', 'prov_oslo'],
    supplyLimit: 30000
  },
  'prov_ireland': {
    id: 'prov_ireland', name: 'Ирландия и Дублин', capital: false,
    population: 950000, taxBase: 18, productionBase: 22, resource: 'grain', terrain: 'plains',
    center: [710, 305], svgPath: 'M 695,275 L 730,280 L 735,335 L 695,335 Z',
    neighborIds: ['prov_london', 'prov_scotland'],
    supplyLimit: 28000
  },

  // ==========================================
  // 2. WESTERN EUROPE & LOW COUNTRIES
  // ==========================================
  'prov_paris': {
    id: 'prov_paris', name: 'Иль-де-Франс и Париж', capital: true,
    population: 2200000, taxBase: 44, productionBase: 38, resource: 'grain', terrain: 'plains',
    center: [810, 375], svgPath: 'M 780,345 L 840,340 L 850,405 L 785,410 Z',
    neighborIds: ['prov_london', 'prov_brussels', 'prov_aquitaine', 'prov_marseille', 'prov_rhineland'],
    supplyLimit: 48000
  },
  'prov_aquitaine': {
    id: 'prov_aquitaine', name: 'Аквитания и Бордо', capital: false,
    population: 1100000, taxBase: 26, productionBase: 28, resource: 'grain', terrain: 'plains',
    center: [785, 455], svgPath: 'M 760,415 L 820,410 L 825,485 L 755,485 Z',
    neighborIds: ['prov_paris', 'prov_marseille', 'prov_madrid', 'prov_barcelona'],
    supplyLimit: 35000
  },
  'prov_marseille': {
    id: 'prov_marseille', name: 'Прованс и Марсель', capital: false,
    population: 1200000, taxBase: 28, productionBase: 26, resource: 'tar', terrain: 'coastal',
    center: [845, 470], svgPath: 'M 825,435 L 880,430 L 875,505 L 820,500 Z',
    neighborIds: ['prov_paris', 'prov_aquitaine', 'prov_milan', 'prov_barcelona'],
    supplyLimit: 38000
  },
  'prov_brussels': {
    id: 'prov_brussels', name: 'Бельгия и Фландрия', capital: false,
    population: 1250000, taxBase: 32, productionBase: 35, resource: 'iron', terrain: 'plains',
    center: [830, 340], svgPath: 'M 810,320 L 855,320 L 855,365 L 810,365 Z',
    neighborIds: ['prov_london', 'prov_paris', 'prov_amsterdam', 'prov_rhineland'],
    supplyLimit: 35000
  },
  'prov_amsterdam': {
    id: 'prov_amsterdam', name: 'Нидерланды и Голландия', capital: false,
    population: 1350000, taxBase: 36, productionBase: 32, resource: 'gold', terrain: 'coastal',
    center: [850, 305], svgPath: 'M 830,285 L 875,285 L 875,330 L 830,330 Z',
    neighborIds: ['prov_brussels', 'prov_rhineland', 'prov_copenhagen', 'prov_london'],
    supplyLimit: 36000
  },

  // ==========================================
  // 3. IBERIAN PENINSULA
  // ==========================================
  'prov_madrid': {
    id: 'prov_madrid', name: 'Кастилия и Мадрид', capital: true,
    population: 1500000, taxBase: 32, productionBase: 28, resource: 'iron', terrain: 'hills',
    center: [740, 510], svgPath: 'M 710,475 L 775,470 L 780,545 L 715,550 Z',
    neighborIds: ['prov_aquitaine', 'prov_barcelona', 'prov_andalusia', 'prov_lisbon'],
    supplyLimit: 35000
  },
  'prov_barcelona': {
    id: 'prov_barcelona', name: 'Каталония и Барселона', capital: false,
    population: 1200000, taxBase: 30, productionBase: 30, resource: 'tar', terrain: 'coastal',
    center: [795, 505], svgPath: 'M 770,475 L 825,475 L 820,540 L 770,540 Z',
    neighborIds: ['prov_aquitaine', 'prov_marseille', 'prov_madrid', 'prov_andalusia'],
    supplyLimit: 34000
  },
  'prov_andalusia': {
    id: 'prov_andalusia', name: 'Андалусия и Севилья', capital: false,
    population: 1100000, taxBase: 26, productionBase: 26, resource: 'grain', terrain: 'coastal',
    center: [730, 580], svgPath: 'M 695,545 L 765,540 L 760,615 L 690,610 Z',
    neighborIds: ['prov_madrid', 'prov_barcelona', 'prov_lisbon', 'prov_algiers', 'prov_morocco'],
    supplyLimit: 32000
  },
  'prov_lisbon': {
    id: 'prov_lisbon', name: 'Португалия и Лиссабон', capital: true,
    population: 950000, taxBase: 26, productionBase: 28, resource: 'tar', terrain: 'coastal',
    center: [685, 535], svgPath: 'M 665,495 L 710,490 L 710,580 L 665,575 Z',
    neighborIds: ['prov_madrid', 'prov_andalusia'],
    supplyLimit: 32000
  },

  // ==========================================
  // 4. CENTRAL EUROPE (GERMANY, AUSTRIA, ALPS)
  // ==========================================
  'prov_berlin': {
    id: 'prov_berlin', name: 'Бранденбург и Берлин', capital: true,
    population: 2300000, taxBase: 44, productionBase: 46, resource: 'iron', terrain: 'plains',
    center: [920, 320], svgPath: 'M 885,285 L 955,285 L 960,355 L 890,355 Z',
    neighborIds: ['prov_rhineland', 'prov_bavaria', 'prov_prague', 'prov_warsaw', 'prov_copenhagen'],
    supplyLimit: 50000
  },
  'prov_rhineland': {
    id: 'prov_rhineland', name: 'Рейнланд и Рур', capital: false,
    population: 2600000, taxBase: 46, productionBase: 52, resource: 'coal', terrain: 'hills',
    center: [875, 365], svgPath: 'M 845,335 L 905,335 L 910,405 L 850,405 Z',
    neighborIds: ['prov_brussels', 'prov_paris', 'prov_berlin', 'prov_bavaria', 'prov_amsterdam', 'prov_switzerland'],
    supplyLimit: 48000
  },
  'prov_bavaria': {
    id: 'prov_bavaria', name: 'Бавария и Мюнхен', capital: false,
    population: 1450000, taxBase: 32, productionBase: 34, resource: 'grain', terrain: 'hills',
    center: [910, 420], svgPath: 'M 880,385 L 945,385 L 950,455 L 885,455 Z',
    neighborIds: ['prov_rhineland', 'prov_berlin', 'prov_vienna', 'prov_prague', 'prov_milan', 'prov_switzerland'],
    supplyLimit: 40000
  },
  'prov_switzerland': {
    id: 'prov_switzerland', name: 'Швейцарские Альпы', capital: false,
    population: 850000, taxBase: 26, productionBase: 24, resource: 'gold', terrain: 'mountains',
    center: [870, 430], svgPath: 'M 850,410 L 890,410 L 890,450 L 850,450 Z',
    neighborIds: ['prov_rhineland', 'prov_bavaria', 'prov_milan', 'prov_paris'],
    supplyLimit: 25000
  },
  'prov_prague': {
    id: 'prov_prague', name: 'Богемия и Прага', capital: true,
    population: 1400000, taxBase: 34, productionBase: 36, resource: 'iron', terrain: 'hills',
    center: [945, 375], svgPath: 'M 915,345 L 975,340 L 980,410 L 920,415 Z',
    neighborIds: ['prov_berlin', 'prov_bavaria', 'prov_vienna', 'prov_warsaw', 'prov_silesia'],
    supplyLimit: 42000
  },
  'prov_silesia': {
    id: 'prov_silesia', name: 'Силезия и Вроцлав', capital: false,
    population: 1300000, taxBase: 30, productionBase: 40, resource: 'coal', terrain: 'plains',
    center: [970, 340], svgPath: 'M 945,310 L 995,310 L 1000,370 L 950,370 Z',
    neighborIds: ['prov_berlin', 'prov_prague', 'prov_warsaw'],
    supplyLimit: 40000
  },
  'prov_vienna': {
    id: 'prov_vienna', name: 'Австрия и Вена', capital: true,
    population: 1900000, taxBase: 42, productionBase: 38, resource: 'grain', terrain: 'plains',
    center: [975, 420], svgPath: 'M 945,390 L 1010,385 L 1015,455 L 950,460 Z',
    neighborIds: ['prov_bavaria', 'prov_prague', 'prov_budapest', 'prov_milan', 'prov_venice'],
    supplyLimit: 46000
  },
  'prov_budapest': {
    id: 'prov_budapest', name: 'Венгрия и Будапешт', capital: false,
    population: 1500000, taxBase: 32, productionBase: 36, resource: 'horses', terrain: 'plains',
    center: [1020, 425], svgPath: 'M 990,395 L 1055,390 L 1060,465 L 995,470 Z',
    neighborIds: ['prov_vienna', 'prov_warsaw', 'prov_belgrade', 'prov_bucharest'],
    supplyLimit: 42000
  },

  // ==========================================
  // 5. SCANDINAVIA & BALTIC
  // ==========================================
  'prov_copenhagen': {
    id: 'prov_copenhagen', name: 'Дания и Копенгаген', capital: true,
    population: 850000, taxBase: 24, productionBase: 24, resource: 'grain', terrain: 'coastal',
    center: [890, 265], svgPath: 'M 870,245 L 915,245 L 915,290 L 870,290 Z',
    neighborIds: ['prov_berlin', 'prov_stockholm', 'prov_oslo', 'prov_amsterdam'],
    supplyLimit: 32000
  },
  'prov_stockholm': {
    id: 'prov_stockholm', name: 'Швеция и Стокгольм', capital: true,
    population: 1200000, taxBase: 28, productionBase: 34, resource: 'iron', terrain: 'forest',
    center: [945, 195], svgPath: 'M 915,150 L 980,150 L 985,245 L 920,245 Z',
    neighborIds: ['prov_oslo', 'prov_copenhagen', 'prov_helsinki'],
    supplyLimit: 36000
  },
  'prov_oslo': {
    id: 'prov_oslo', name: 'Норвегия и Осло', capital: false,
    population: 700000, taxBase: 20, productionBase: 28, resource: 'timber', terrain: 'mountains',
    center: [885, 195], svgPath: 'M 855,150 L 915,150 L 915,245 L 855,245 Z',
    neighborIds: ['prov_stockholm', 'prov_copenhagen', 'prov_scotland'],
    supplyLimit: 26000
  },
  'prov_helsinki': {
    id: 'prov_helsinki', name: 'Финляндия и Хельсинки', capital: false,
    population: 750000, taxBase: 20, productionBase: 28, resource: 'timber', terrain: 'forest',
    center: [1020, 185], svgPath: 'M 985,145 L 1055,145 L 1060,230 L 990,230 Z',
    neighborIds: ['prov_stockholm', 'prov_stpetersburg'],
    supplyLimit: 30000
  },

  // ==========================================
  // 6. ITALY
  // ==========================================
  'prov_milan': {
    id: 'prov_milan', name: 'Ломбардия и Милан', capital: false,
    population: 1600000, taxBase: 36, productionBase: 38, resource: 'grain', terrain: 'plains',
    center: [875, 470], svgPath: 'M 850,445 L 905,445 L 905,500 L 850,500 Z',
    neighborIds: ['prov_marseille', 'prov_bavaria', 'prov_vienna', 'prov_venice', 'prov_rome', 'prov_switzerland'],
    supplyLimit: 44000
  },
  'prov_venice': {
    id: 'prov_venice', name: 'Венеция и Адриатика', capital: false,
    population: 1250000, taxBase: 34, productionBase: 30, resource: 'gold', terrain: 'coastal',
    center: [925, 475], svgPath: 'M 905,450 L 955,450 L 955,505 L 905,505 Z',
    neighborIds: ['prov_milan', 'prov_vienna', 'prov_rome'],
    supplyLimit: 38000
  },
  'prov_rome': {
    id: 'prov_rome', name: 'Рим и Лацио', capital: true,
    population: 1400000, taxBase: 35, productionBase: 28, resource: 'stone', terrain: 'hills',
    center: [910, 535], svgPath: 'M 885,505 L 940,505 L 940,565 L 885,565 Z',
    neighborIds: ['prov_milan', 'prov_venice', 'prov_naples'],
    supplyLimit: 38000
  },
  'prov_naples': {
    id: 'prov_naples', name: 'Неаполь и Южная Италия', capital: false,
    population: 1250000, taxBase: 28, productionBase: 26, resource: 'grain', terrain: 'coastal',
    center: [945, 580], svgPath: 'M 920,555 L 975,555 L 975,620 L 920,620 Z',
    neighborIds: ['prov_rome', 'prov_sicily'],
    supplyLimit: 35000
  },
  'prov_sicily': {
    id: 'prov_sicily', name: 'Сицилия и Палермо', capital: false,
    population: 950000, taxBase: 24, productionBase: 26, resource: 'grain', terrain: 'coastal',
    center: [935, 640], svgPath: 'M 910,615 L 960,615 L 955,670 L 905,665 Z',
    neighborIds: ['prov_naples', 'prov_tripoli', 'prov_tunis'],
    supplyLimit: 30000
  },

  // ==========================================
  // 7. BALKANS & GREECE
  // ==========================================
  'prov_belgrade': {
    id: 'prov_belgrade', name: 'Сербия и Белград', capital: true,
    population: 1100000, taxBase: 24, productionBase: 26, resource: 'iron', terrain: 'hills',
    center: [1010, 485], svgPath: 'M 980,460 L 1045,460 L 1045,520 L 980,520 Z',
    neighborIds: ['prov_budapest', 'prov_bucharest', 'prov_athens', 'prov_constantinople'],
    supplyLimit: 36000
  },
  'prov_bucharest': {
    id: 'prov_bucharest', name: 'Румыния и Бухарест', capital: false,
    population: 1250000, taxBase: 26, productionBase: 30, resource: 'grain', terrain: 'plains',
    center: [1065, 465], svgPath: 'M 1035,435 L 1100,435 L 1100,500 L 1035,500 Z',
    neighborIds: ['prov_budapest', 'prov_belgrade', 'prov_odessa', 'prov_constantinople'],
    supplyLimit: 38000
  },
  'prov_athens': {
    id: 'prov_athens', name: 'Греция и Афины', capital: true,
    population: 1100000, taxBase: 26, productionBase: 24, resource: 'tar', terrain: 'coastal',
    center: [1030, 565], svgPath: 'M 1000,535 L 1065,535 L 1060,610 L 995,605 Z',
    neighborIds: ['prov_belgrade', 'prov_constantinople'],
    supplyLimit: 32000
  },

  // ==========================================
  // 8. POLAND, UKRAINE & EASTERN EUROPE
  // ==========================================
  'prov_warsaw': {
    id: 'prov_warsaw', name: 'Польша и Варшава', capital: true,
    population: 1800000, taxBase: 35, productionBase: 34, resource: 'grain', terrain: 'plains',
    center: [1015, 325], svgPath: 'M 985,290 L 1055,290 L 1060,365 L 990,365 Z',
    neighborIds: ['prov_berlin', 'prov_silesia', 'prov_prague', 'prov_budapest', 'prov_minsk', 'prov_kiev'],
    supplyLimit: 45000
  },
  'prov_minsk': {
    id: 'prov_minsk', name: 'Беларусь и Минск', capital: false,
    population: 1200000, taxBase: 24, productionBase: 26, resource: 'timber', terrain: 'forest',
    center: [1070, 295], svgPath: 'M 1040,260 L 1105,260 L 1110,335 L 1045,335 Z',
    neighborIds: ['prov_warsaw', 'prov_kiev', 'prov_stpetersburg', 'prov_moscow'],
    supplyLimit: 38000
  },
  'prov_kiev': {
    id: 'prov_kiev', name: 'Киев и Днепровье', capital: false,
    population: 1750000, taxBase: 36, productionBase: 38, resource: 'grain', terrain: 'plains',
    center: [1100, 365], svgPath: 'M 1065,330 L 1140,330 L 1145,405 L 1070,405 Z',
    neighborIds: ['prov_warsaw', 'prov_minsk', 'prov_kharkov', 'prov_odessa'],
    supplyLimit: 46000
  },
  'prov_kharkov': {
    id: 'prov_kharkov', name: 'Харьков и Донбасс', capital: false,
    population: 1700000, taxBase: 34, productionBase: 44, resource: 'coal', terrain: 'plains',
    center: [1165, 365], svgPath: 'M 1135,330 L 1205,330 L 1210,405 L 1140,405 Z',
    neighborIds: ['prov_kiev', 'prov_moscow', 'prov_stalingrad', 'prov_crimea'],
    supplyLimit: 45000
  },
  'prov_crimea': {
    id: 'prov_crimea', name: 'Крым и Севастополь', capital: false,
    population: 1050000, taxBase: 28, productionBase: 26, resource: 'tar', terrain: 'coastal',
    center: [1145, 455], svgPath: 'M 1120,430 L 1175,430 L 1175,480 L 1120,480 Z',
    neighborIds: ['prov_odessa', 'prov_kharkov', 'prov_caucasus'],
    supplyLimit: 35000
  },
  'prov_odessa': {
    id: 'prov_odessa', name: 'Одесса и Причерноморье', capital: false,
    population: 1200000, taxBase: 30, productionBase: 32, resource: 'grain', terrain: 'coastal',
    center: [1090, 425], svgPath: 'M 1065,400 L 1125,400 L 1120,455 L 1060,455 Z',
    neighborIds: ['prov_kiev', 'prov_bucharest', 'prov_crimea'],
    supplyLimit: 38000
  },

  // ==========================================
  // 9. RUSSIA & EURASIA
  // ==========================================
  'prov_stpetersburg': {
    id: 'prov_stpetersburg', name: 'Санкт-Петербург / Балтика', capital: true,
    population: 2600000, taxBase: 46, productionBase: 42, resource: 'iron', terrain: 'coastal',
    center: [1090, 205], svgPath: 'M 1055,165 L 1135,165 L 1140,245 L 1060,245 Z',
    neighborIds: ['prov_helsinki', 'prov_minsk', 'prov_moscow', 'prov_novgorod'],
    supplyLimit: 52000
  },
  'prov_moscow': {
    id: 'prov_moscow', name: 'Москва и Центр России', capital: true,
    population: 3400000, taxBase: 50, productionBase: 48, resource: 'iron', terrain: 'plains',
    center: [1165, 255], svgPath: 'M 1125,215 L 1215,210 L 1220,295 L 1130,300 Z',
    neighborIds: ['prov_stpetersburg', 'prov_novgorod', 'prov_minsk', 'prov_kazan', 'prov_stalingrad', 'prov_kharkov'],
    supplyLimit: 60000
  },
  'prov_novgorod': {
    id: 'prov_novgorod', name: 'Великий Новгород и Север', capital: false,
    population: 950000, taxBase: 22, productionBase: 28, resource: 'timber', terrain: 'forest',
    center: [1105, 240], svgPath: 'M 1080,215 L 1135,215 L 1135,270 L 1080,270 Z',
    neighborIds: ['prov_stpetersburg', 'prov_moscow'],
    supplyLimit: 35000
  },
  'prov_stalingrad': {
    id: 'prov_stalingrad', name: 'Нижнее Поволжье / Волгоград', capital: false,
    population: 1550000, taxBase: 32, productionBase: 38, resource: 'iron', terrain: 'plains',
    center: [1225, 365], svgPath: 'M 1185,325 L 1265,325 L 1270,410 L 1190,410 Z',
    neighborIds: ['prov_moscow', 'prov_kharkov', 'prov_kazan', 'prov_caucasus', 'prov_ural', 'prov_central_asia'],
    supplyLimit: 45000
  },
  'prov_kazan': {
    id: 'prov_kazan', name: 'Среднее Поволжье и Казань', capital: false,
    population: 1400000, taxBase: 30, productionBase: 34, resource: 'grain', terrain: 'forest',
    center: [1240, 265], svgPath: 'M 1205,225 L 1285,225 L 1290,305 L 1210,305 Z',
    neighborIds: ['prov_moscow', 'prov_stalingrad', 'prov_ural'],
    supplyLimit: 42000
  },
  'prov_caucasus': {
    id: 'prov_caucasus', name: 'Кавказ и Баку', capital: false,
    population: 1600000, taxBase: 34, productionBase: 50, resource: 'tar', terrain: 'mountains',
    center: [1245, 455], svgPath: 'M 1210,420 L 1285,420 L 1290,495 L 1215,495 Z',
    neighborIds: ['prov_stalingrad', 'prov_crimea', 'prov_ankara', 'prov_tehran'],
    supplyLimit: 38000
  },
  'prov_ural': {
    id: 'prov_ural', name: 'Урал и Екатеринбург', capital: false,
    population: 1850000, taxBase: 38, productionBase: 52, resource: 'iron', terrain: 'mountains',
    center: [1320, 240], svgPath: 'M 1280,195 L 1365,195 L 1370,290 L 1285,290 Z',
    neighborIds: ['prov_kazan', 'prov_stalingrad', 'prov_siberia_west', 'prov_central_asia'],
    supplyLimit: 45000
  },
  'prov_siberia_west': {
    id: 'prov_siberia_west', name: 'Западная Сибирь и Новосибирск', capital: false,
    population: 1950000, taxBase: 36, productionBase: 54, resource: 'coal', terrain: 'forest',
    center: [1420, 240], svgPath: 'M 1365,185 L 1475,185 L 1480,295 L 1370,295 Z',
    neighborIds: ['prov_ural', 'prov_siberia_east', 'prov_central_asia'],
    supplyLimit: 42000
  },
  'prov_siberia_east': {
    id: 'prov_siberia_east', name: 'Восточная Сибирь и Байкал', capital: false,
    population: 1200000, taxBase: 28, productionBase: 48, resource: 'gold', terrain: 'mountains',
    center: [1550, 235], svgPath: 'M 1475,175 L 1625,175 L 1630,295 L 1480,295 Z',
    neighborIds: ['prov_siberia_west', 'prov_far_east', 'prov_beijing'],
    supplyLimit: 34000
  },
  'prov_far_east': {
    id: 'prov_far_east', name: 'Дальний Восток и Владивосток', capital: false,
    population: 1300000, taxBase: 32, productionBase: 42, resource: 'tar', terrain: 'coastal',
    center: [1680, 270], svgPath: 'M 1625,205 L 1735,205 L 1740,335 L 1630,335 Z',
    neighborIds: ['prov_siberia_east', 'prov_manchuria', 'prov_tokyo'],
    supplyLimit: 36000
  },
  'prov_central_asia': {
    id: 'prov_central_asia', name: 'Центральная Азия / Туркестан', capital: false,
    population: 1650000, taxBase: 30, productionBase: 36, resource: 'horses', terrain: 'plains',
    center: [1315, 370], svgPath: 'M 1265,320 L 1370,320 L 1375,420 L 1270,420 Z',
    neighborIds: ['prov_ural', 'prov_siberia_west', 'prov_stalingrad', 'prov_tehran', 'prov_afghanistan'],
    supplyLimit: 38000
  },

  // ==========================================
  // 10. MIDDLE EAST & NORTH AFRICA
  // ==========================================
  'prov_constantinople': {
    id: 'prov_constantinople', name: 'Константинополь / Стамбул', capital: true,
    population: 2200000, taxBase: 44, productionBase: 36, resource: 'gold', terrain: 'coastal',
    center: [1090, 515], svgPath: 'M 1060,485 L 1130,485 L 1130,550 L 1060,550 Z',
    neighborIds: ['prov_belgrade', 'prov_bucharest', 'prov_athens', 'prov_ankara'],
    supplyLimit: 48000
  },
  'prov_ankara': {
    id: 'prov_ankara', name: 'Анатолия и Анкара', capital: false,
    population: 1600000, taxBase: 32, productionBase: 32, resource: 'iron', terrain: 'mountains',
    center: [1155, 515], svgPath: 'M 1125,485 L 1195,485 L 1200,555 L 1130,555 Z',
    neighborIds: ['prov_constantinople', 'prov_caucasus', 'prov_levant', 'prov_baghdad'],
    supplyLimit: 40000
  },
  'prov_levant': {
    id: 'prov_levant', name: 'Левант и Иерусалим', capital: false,
    population: 1300000, taxBase: 30, productionBase: 28, resource: 'grain', terrain: 'hills',
    center: [1150, 580], svgPath: 'M 1120,550 L 1180,550 L 1185,615 L 1125,615 Z',
    neighborIds: ['prov_ankara', 'prov_cairo', 'prov_baghdad', 'prov_arabia'],
    supplyLimit: 36000
  },
  'prov_cairo': {
    id: 'prov_cairo', name: 'Египет и Каир', capital: true,
    population: 2500000, taxBase: 40, productionBase: 42, resource: 'grain', terrain: 'plains',
    center: [1095, 630], svgPath: 'M 1060,595 L 1140,595 L 1145,670 L 1065,670 Z',
    neighborIds: ['prov_levant', 'prov_tripoli', 'prov_alexandria', 'prov_arabia'],
    supplyLimit: 45000
  },
  'prov_alexandria': {
    id: 'prov_alexandria', name: 'Александрия и Суэц', capital: false,
    population: 1600000, taxBase: 36, productionBase: 38, resource: 'tar', terrain: 'coastal',
    center: [1060, 615], svgPath: 'M 1035,590 L 1085,590 L 1085,650 L 1035,650 Z',
    neighborIds: ['prov_cairo', 'prov_tripoli'],
    supplyLimit: 40000
  },
  'prov_tripoli': {
    id: 'prov_tripoli', name: 'Ливия и Триполи', capital: false,
    population: 850000, taxBase: 22, productionBase: 35, resource: 'tar', terrain: 'coastal',
    center: [960, 670], svgPath: 'M 915,635 L 1005,635 L 1010,710 L 920,710 Z',
    neighborIds: ['prov_sicily', 'prov_alexandria', 'prov_algiers', 'prov_tunis'],
    supplyLimit: 28000
  },
  'prov_tunis': {
    id: 'prov_tunis', name: 'Тунис и Карфаген', capital: false,
    population: 950000, taxBase: 24, productionBase: 24, resource: 'grain', terrain: 'coastal',
    center: [870, 595], svgPath: 'M 845,565 L 895,565 L 895,625 L 845,625 Z',
    neighborIds: ['prov_sicily', 'prov_algiers', 'prov_tripoli'],
    supplyLimit: 30000
  },
  'prov_algiers': {
    id: 'prov_algiers', name: 'Алжир и Магриб', capital: false,
    population: 1200000, taxBase: 26, productionBase: 32, resource: 'tar', terrain: 'coastal',
    center: [790, 605], svgPath: 'M 745,570 L 835,570 L 840,645 L 750,645 Z',
    neighborIds: ['prov_andalusia', 'prov_tunis', 'prov_morocco', 'prov_west_africa'],
    supplyLimit: 34000
  },
  'prov_morocco': {
    id: 'prov_morocco', name: 'Марокко и Фес', capital: true,
    population: 1150000, taxBase: 26, productionBase: 26, resource: 'grain', terrain: 'hills',
    center: [705, 610], svgPath: 'M 670,575 L 740,575 L 745,645 L 675,645 Z',
    neighborIds: ['prov_andalusia', 'prov_algiers', 'prov_west_africa'],
    supplyLimit: 32000
  },
  'prov_baghdad': {
    id: 'prov_baghdad', name: 'Месопотамия и Багдад', capital: false,
    population: 1650000, taxBase: 34, productionBase: 50, resource: 'tar', terrain: 'plains',
    center: [1205, 570], svgPath: 'M 1170,535 L 1245,535 L 1250,610 L 1175,610 Z',
    neighborIds: ['prov_ankara', 'prov_levant', 'prov_tehran', 'prov_arabia'],
    supplyLimit: 42000
  },
  'prov_arabia': {
    id: 'prov_arabia', name: 'Аравия и Эр-Рияд', capital: false,
    population: 1400000, taxBase: 32, productionBase: 58, resource: 'tar', terrain: 'plains',
    center: [1220, 680], svgPath: 'M 1165,630 L 1275,630 L 1280,735 L 1170,735 Z',
    neighborIds: ['prov_levant', 'prov_baghdad', 'prov_cairo', 'prov_tehran'],
    supplyLimit: 36000
  },
  'prov_tehran': {
    id: 'prov_tehran', name: 'Персия / Иран и Тегеран', capital: true,
    population: 2100000, taxBase: 36, productionBase: 48, resource: 'tar', terrain: 'mountains',
    center: [1280, 525], svgPath: 'M 1240,480 L 1325,480 L 1330,575 L 1245,575 Z',
    neighborIds: ['prov_caucasus', 'prov_baghdad', 'prov_arabia', 'prov_central_asia', 'prov_afghanistan'],
    supplyLimit: 44000
  },
  'prov_afghanistan': {
    id: 'prov_afghanistan', name: 'Афганистан и Кабул', capital: false,
    population: 1200000, taxBase: 22, productionBase: 26, resource: 'stone', terrain: 'mountains',
    center: [1355, 480], svgPath: 'M 1320,440 L 1390,440 L 1395,520 L 1325,520 Z',
    neighborIds: ['prov_tehran', 'prov_central_asia', 'prov_delhi'],
    supplyLimit: 28000
  },

  // ==========================================
  // 11. SUB-SAHARAN AFRICA
  // ==========================================
  'prov_west_africa': {
    id: 'prov_west_africa', name: 'Западная Африка и Нигерия', capital: false,
    population: 2200000, taxBase: 32, productionBase: 36, resource: 'gold', terrain: 'coastal',
    center: [820, 725], svgPath: 'M 740,670 L 900,670 L 905,780 L 745,780 Z',
    neighborIds: ['prov_algiers', 'prov_morocco', 'prov_central_africa'],
    supplyLimit: 35000
  },
  'prov_central_africa': {
    id: 'prov_central_africa', name: 'Конго и Центральная Африка', capital: false,
    population: 1800000, taxBase: 26, productionBase: 34, resource: 'timber', terrain: 'forest',
    center: [990, 760], svgPath: 'M 920,700 L 1060,700 L 1065,820 L 925,820 Z',
    neighborIds: ['prov_west_africa', 'prov_east_africa', 'prov_south_africa'],
    supplyLimit: 32000
  },
  'prov_east_africa': {
    id: 'prov_east_africa', name: 'Восточная Африка и Эфиопия', capital: false,
    population: 1900000, taxBase: 28, productionBase: 30, resource: 'grain', terrain: 'hills',
    center: [1165, 745], svgPath: 'M 1110,680 L 1220,680 L 1225,810 L 1115,810 Z',
    neighborIds: ['prov_cairo', 'prov_central_africa', 'prov_south_africa'],
    supplyLimit: 34000
  },
  'prov_south_africa': {
    id: 'prov_south_africa', name: 'Южная Африка и Кейптаун', capital: true,
    population: 2100000, taxBase: 38, productionBase: 46, resource: 'gold', terrain: 'coastal',
    center: [1035, 880], svgPath: 'M 970,820 L 1100,820 L 1105,940 L 975,940 Z',
    neighborIds: ['prov_central_africa', 'prov_east_africa'],
    supplyLimit: 40000
  },

  // ==========================================
  // 12. SOUTH ASIA & INDIA
  // ==========================================
  'prov_delhi': {
    id: 'prov_delhi', name: 'Северная Индия и Дели', capital: true,
    population: 4200000, taxBase: 48, productionBase: 44, resource: 'grain', terrain: 'plains',
    center: [1410, 525], svgPath: 'M 1370,480 L 1450,480 L 1455,570 L 1375,570 Z',
    neighborIds: ['prov_afghanistan', 'prov_bombay', 'prov_bengal', 'prov_tibet'],
    supplyLimit: 55000
  },
  'prov_bombay': {
    id: 'prov_bombay', name: 'Западная Индия и Мумбаи', capital: false,
    population: 3600000, taxBase: 44, productionBase: 42, resource: 'gold', terrain: 'coastal',
    center: [1410, 635], svgPath: 'M 1370,575 L 1450,575 L 1455,695 L 1375,695 Z',
    neighborIds: ['prov_delhi', 'prov_bengal'],
    supplyLimit: 50000
  },
  'prov_bengal': {
    id: 'prov_bengal', name: 'Бенгалия и Калькутта', capital: false,
    population: 3900000, taxBase: 46, productionBase: 46, resource: 'grain', terrain: 'coastal',
    center: [1475, 550], svgPath: 'M 1440,510 L 1510,510 L 1515,595 L 1445,595 Z',
    neighborIds: ['prov_delhi', 'prov_bombay', 'prov_tibet', 'prov_indochina', 'prov_canton'],
    supplyLimit: 52000
  },
  'prov_tibet': {
    id: 'prov_tibet', name: 'Тибет и Гималаи', capital: false,
    population: 850000, taxBase: 18, productionBase: 20, resource: 'stone', terrain: 'mountains',
    center: [1465, 465], svgPath: 'M 1420,430 L 1510,430 L 1510,500 L 1420,500 Z',
    neighborIds: ['prov_delhi', 'prov_bengal', 'prov_beijing', 'prov_canton'],
    supplyLimit: 22000
  },

  // ==========================================
  // 13. EAST ASIA (CHINA, JAPAN, KOREA)
  // ==========================================
  'prov_beijing': {
    id: 'prov_beijing', name: 'Северный Китай и Пекин', capital: true,
    population: 4800000, taxBase: 52, productionBase: 50, resource: 'iron', terrain: 'plains',
    center: [1565, 380], svgPath: 'M 1520,335 L 1610,335 L 1615,425 L 1525,425 Z',
    neighborIds: ['prov_siberia_east', 'prov_shanghai', 'prov_canton', 'prov_manchuria', 'prov_tibet'],
    supplyLimit: 60000
  },
  'prov_shanghai': {
    id: 'prov_shanghai', name: 'Дельта Янцзы и Шанхай', capital: false,
    population: 4400000, taxBase: 50, productionBase: 48, resource: 'gold', terrain: 'coastal',
    center: [1575, 455], svgPath: 'M 1530,420 L 1620,420 L 1625,490 L 1535,490 Z',
    neighborIds: ['prov_beijing', 'prov_canton', 'prov_korea', 'prov_osaka'],
    supplyLimit: 58000
  },
  'prov_canton': {
    id: 'prov_canton', name: 'Южный Китай и Гуанчжоу', capital: false,
    population: 4100000, taxBase: 46, productionBase: 46, resource: 'grain', terrain: 'coastal',
    center: [1550, 530], svgPath: 'M 1510,490 L 1590,490 L 1595,570 L 1515,570 Z',
    neighborIds: ['prov_bengal', 'prov_beijing', 'prov_shanghai', 'prov_indochina', 'prov_tibet'],
    supplyLimit: 55000
  },
  'prov_manchuria': {
    id: 'prov_manchuria', name: 'Маньчжурия и Харбин', capital: false,
    population: 2100000, taxBase: 36, productionBase: 46, resource: 'coal', terrain: 'forest',
    center: [1655, 320], svgPath: 'M 1610,275 L 1700,275 L 1705,365 L 1615,365 Z',
    neighborIds: ['prov_far_east', 'prov_beijing', 'prov_korea'],
    supplyLimit: 45000
  },
  'prov_korea': {
    id: 'prov_korea', name: 'Корейский полуостров и Сеул', capital: true,
    population: 2300000, taxBase: 38, productionBase: 42, resource: 'iron', terrain: 'hills',
    center: [1650, 400], svgPath: 'M 1630,370 L 1670,370 L 1675,435 L 1630,435 Z',
    neighborIds: ['prov_manchuria', 'prov_shanghai', 'prov_osaka'],
    supplyLimit: 44000
  },
  'prov_tokyo': {
    id: 'prov_tokyo', name: 'Канто и Токио', capital: true,
    population: 3600000, taxBase: 46, productionBase: 48, resource: 'iron', terrain: 'coastal',
    center: [1725, 405], svgPath: 'M 1690,365 L 1760,365 L 1765,445 L 1695,445 Z',
    neighborIds: ['prov_osaka', 'prov_far_east'],
    supplyLimit: 50000
  },
  'prov_osaka': {
    id: 'prov_osaka', name: 'Кансай и Осака', capital: false,
    population: 2600000, taxBase: 40, productionBase: 42, resource: 'tar', terrain: 'coastal',
    center: [1695, 455], svgPath: 'M 1670,425 L 1720,425 L 1725,485 L 1675,485 Z',
    neighborIds: ['prov_tokyo', 'prov_shanghai', 'prov_korea'],
    supplyLimit: 46000
  },

  // ==========================================
  // 14. SOUTHEAST ASIA & OCEANIA
  // ==========================================
  'prov_indochina': {
    id: 'prov_indochina', name: 'Индокитай и Сиам', capital: true,
    population: 2700000, taxBase: 36, productionBase: 38, resource: 'grain', terrain: 'coastal',
    center: [1540, 625], svgPath: 'M 1500,570 L 1580,570 L 1585,680 L 1505,680 Z',
    neighborIds: ['prov_canton', 'prov_bengal', 'prov_indonesia'],
    supplyLimit: 42000
  },
  'prov_indonesia': {
    id: 'prov_indonesia', name: 'Малайя и Индонезия', capital: false,
    population: 3200000, taxBase: 40, productionBase: 46, resource: 'tar', terrain: 'coastal',
    center: [1590, 735], svgPath: 'M 1520,680 L 1660,680 L 1665,790 L 1525,790 Z',
    neighborIds: ['prov_indochina', 'prov_philippines', 'prov_australia'],
    supplyLimit: 44000
  },
  'prov_philippines': {
    id: 'prov_philippines', name: 'Филиппинские острова', capital: false,
    population: 1800000, taxBase: 30, productionBase: 32, resource: 'gold', terrain: 'coastal',
    center: [1660, 625], svgPath: 'M 1630,570 L 1690,570 L 1690,680 L 1630,680 Z',
    neighborIds: ['prov_indonesia', 'prov_shanghai'],
    supplyLimit: 36000
  },
  'prov_australia': {
    id: 'prov_australia', name: 'Австралия и Сидней', capital: true,
    population: 2200000, taxBase: 38, productionBase: 48, resource: 'iron', terrain: 'coastal',
    center: [1715, 850], svgPath: 'M 1640,780 L 1790,780 L 1795,920 L 1645,920 Z',
    neighborIds: ['prov_indonesia'],
    supplyLimit: 45000
  },

  // ==========================================
  // 15. NORTH AMERICA
  // ==========================================
  'prov_canada': {
    id: 'prov_canada', name: 'Канада и Квебек', capital: false,
    population: 1800000, taxBase: 34, productionBase: 42, resource: 'timber', terrain: 'forest',
    center: [390, 190], svgPath: 'M 300,140 L 480,140 L 485,245 L 305,245 Z',
    neighborIds: ['prov_newyork', 'prov_midwest'],
    supplyLimit: 40000
  },
  'prov_newyork': {
    id: 'prov_newyork', name: 'Новая Англия и Нью-Йорк', capital: false,
    population: 3200000, taxBase: 50, productionBase: 46, resource: 'coal', terrain: 'coastal',
    center: [435, 315], svgPath: 'M 390,265 L 480,265 L 485,365 L 395,365 Z',
    neighborIds: ['prov_canada', 'prov_washington', 'prov_midwest'],
    supplyLimit: 55000
  },
  'prov_washington': {
    id: 'prov_washington', name: 'Вашингтон и Вирджиния', capital: true,
    population: 2800000, taxBase: 48, productionBase: 44, resource: 'gold', terrain: 'coastal',
    center: [435, 415], svgPath: 'M 390,365 L 480,365 L 485,465 L 395,465 Z',
    neighborIds: ['prov_newyork', 'prov_midwest', 'prov_texas', 'prov_caribbean'],
    supplyLimit: 52000
  },
  'prov_midwest': {
    id: 'prov_midwest', name: 'Средний Запад и Чикаго', capital: false,
    population: 2900000, taxBase: 44, productionBase: 54, resource: 'iron', terrain: 'plains',
    center: [340, 315], svgPath: 'M 300,265 L 385,265 L 390,365 L 305,365 Z',
    neighborIds: ['prov_canada', 'prov_newyork', 'prov_washington', 'prov_plains', 'prov_texas'],
    supplyLimit: 54000
  },
  'prov_plains': {
    id: 'prov_plains', name: 'Великие Равнины и Скалистые горы', capital: false,
    population: 1400000, taxBase: 28, productionBase: 36, resource: 'grain', terrain: 'plains',
    center: [250, 320], svgPath: 'M 210,270 L 295,270 L 300,370 L 215,370 Z',
    neighborIds: ['prov_midwest', 'prov_california', 'prov_texas'],
    supplyLimit: 36000
  },
  'prov_california': {
    id: 'prov_california', name: 'Калифорния и Тихоокеанский берег', capital: false,
    population: 2800000, taxBase: 46, productionBase: 46, resource: 'gold', terrain: 'coastal',
    center: [175, 320], svgPath: 'M 140,260 L 210,260 L 215,380 L 145,380 Z',
    neighborIds: ['prov_plains', 'prov_texas', 'prov_mexico_north'],
    supplyLimit: 48000
  },
  'prov_texas': {
    id: 'prov_texas', name: 'Техас и Залив', capital: false,
    population: 2500000, taxBase: 42, productionBase: 56, resource: 'tar', terrain: 'plains',
    center: [320, 425], svgPath: 'M 280,375 L 360,375 L 365,475 L 285,475 Z',
    neighborIds: ['prov_midwest', 'prov_washington', 'prov_plains', 'prov_california', 'prov_mexico_north'],
    supplyLimit: 50000
  },
  'prov_mexico_north': {
    id: 'prov_mexico_north', name: 'Северная Мексика', capital: false,
    population: 1300000, taxBase: 26, productionBase: 32, resource: 'stone', terrain: 'mountains',
    center: [255, 465], svgPath: 'M 210,425 L 280,425 L 285,505 L 215,505 Z',
    neighborIds: ['prov_california', 'prov_texas', 'prov_mexico_city'],
    supplyLimit: 32000
  },
  'prov_mexico_city': {
    id: 'prov_mexico_city', name: 'Мексика и Мехико', capital: true,
    population: 2400000, taxBase: 38, productionBase: 38, resource: 'gold', terrain: 'hills',
    center: [255, 535], svgPath: 'M 200,505 L 310,505 L 315,570 L 205,570 Z',
    neighborIds: ['prov_mexico_north', 'prov_colombia', 'prov_caribbean'],
    supplyLimit: 42000
  },
  'prov_caribbean': {
    id: 'prov_caribbean', name: 'Карибы и Куба', capital: false,
    population: 1400000, taxBase: 32, productionBase: 34, resource: 'grain', terrain: 'coastal',
    center: [420, 510], svgPath: 'M 380,480 L 460,480 L 465,540 L 385,540 Z',
    neighborIds: ['prov_washington', 'prov_mexico_city', 'prov_colombia'],
    supplyLimit: 36000
  },

  // ==========================================
  // 16. SOUTH AMERICA
  // ==========================================
  'prov_colombia': {
    id: 'prov_colombia', name: 'Великая Колумбия и Богота', capital: true,
    population: 1700000, taxBase: 30, productionBase: 32, resource: 'tar', terrain: 'mountains',
    center: [400, 590], svgPath: 'M 350,550 L 450,550 L 455,630 L 355,630 Z',
    neighborIds: ['prov_mexico_city', 'prov_caribbean', 'prov_peru', 'prov_brazil'],
    supplyLimit: 36000
  },
  'prov_brazil': {
    id: 'prov_brazil', name: 'Бразилия и Рио-де-Жанейро', capital: true,
    population: 3200000, taxBase: 44, productionBase: 46, resource: 'gold', terrain: 'coastal',
    center: [510, 690], svgPath: 'M 440,620 L 580,620 L 585,760 L 445,760 Z',
    neighborIds: ['prov_colombia', 'prov_peru', 'prov_argentina'],
    supplyLimit: 48000
  },
  'prov_peru': {
    id: 'prov_peru', name: 'Перу и Лима', capital: true,
    population: 1500000, taxBase: 28, productionBase: 36, resource: 'gold', terrain: 'mountains',
    center: [380, 695], svgPath: 'M 340,640 L 420,640 L 425,750 L 345,750 Z',
    neighborIds: ['prov_colombia', 'prov_brazil', 'prov_argentina'],
    supplyLimit: 34000
  },
  'prov_argentina': {
    id: 'prov_argentina', name: 'Аргентина и Буэнос-Айрес', capital: true,
    population: 2100000, taxBase: 36, productionBase: 40, resource: 'horses', terrain: 'plains',
    center: [415, 835], svgPath: 'M 370,760 L 460,760 L 465,910 L 375,910 Z',
    neighborIds: ['prov_peru', 'prov_brazil'],
    supplyLimit: 42000
  }
};

// Generates real Province map state with ownership by Era
export function getProvincesForEra(eraId: EraId): Record<string, Province> {
  const result: Record<string, Province> = {};

  Object.values(BASE_WORLD_PROVINCES).forEach(tmpl => {
    let owner = 'britain_1836';
    let core = 'britain_1836';
    let cap = tmpl.capital;

    if (eraId === 'victorian_1836') {
      if (['prov_london', 'prov_scotland', 'prov_ireland', 'prov_delhi', 'prov_bombay', 'prov_bengal', 'prov_canada', 'prov_australia', 'prov_south_africa'].includes(tmpl.id)) {
        owner = 'britain_1836'; core = 'britain_1836';
      } else if (['prov_stpetersburg', 'prov_moscow', 'prov_novgorod', 'prov_kiev', 'prov_minsk', 'prov_kharkov', 'prov_crimea', 'prov_odessa', 'prov_stalingrad', 'prov_kazan', 'prov_ural', 'prov_siberia_west', 'prov_siberia_east', 'prov_far_east', 'prov_caucasus', 'prov_helsinki', 'prov_warsaw', 'prov_central_asia'].includes(tmpl.id)) {
        owner = 'russia_1836'; core = 'russia_1836';
      } else if (['prov_berlin', 'prov_rhineland', 'prov_silesia'].includes(tmpl.id)) {
        owner = 'prussia_1836'; core = 'prussia_1836';
      } else if (['prov_bavaria'].includes(tmpl.id)) {
        owner = 'prussia_1836'; core = 'prussia_1836';
      } else if (['prov_paris', 'prov_aquitaine', 'prov_marseille', 'prov_algiers'].includes(tmpl.id)) {
        owner = 'france_1836'; core = 'france_1836';
      } else if (['prov_vienna', 'prov_budapest', 'prov_prague', 'prov_milan', 'prov_venice'].includes(tmpl.id)) {
        owner = 'austria_1836'; core = 'austria_1836';
      } else if (['prov_washington', 'prov_newyork', 'prov_midwest', 'prov_plains'].includes(tmpl.id)) {
        owner = 'usa_1836'; core = 'usa_1836';
      } else if (['prov_california', 'prov_texas', 'prov_mexico_north', 'prov_mexico_city'].includes(tmpl.id)) {
        owner = 'mexico_1836'; core = 'mexico_1836';
      } else if (['prov_constantinople', 'prov_ankara', 'prov_levant', 'prov_baghdad', 'prov_athens', 'prov_belgrade', 'prov_bucharest', 'prov_tripoli'].includes(tmpl.id)) {
        owner = 'ottoman_1836'; core = 'ottoman_1836';
      } else if (['prov_cairo', 'prov_alexandria'].includes(tmpl.id)) {
        owner = 'egypt_1836'; core = 'egypt_1836';
      } else if (['prov_madrid', 'prov_barcelona', 'prov_andalusia', 'prov_caribbean', 'prov_philippines'].includes(tmpl.id)) {
        owner = 'spain_1836'; core = 'spain_1836';
      } else if (['prov_lisbon'].includes(tmpl.id)) {
        owner = 'portugal_1836'; core = 'portugal_1836';
      } else if (['prov_amsterdam', 'prov_indonesia'].includes(tmpl.id)) {
        owner = 'netherlands_1836'; core = 'netherlands_1836';
      } else if (['prov_brussels'].includes(tmpl.id)) {
        owner = 'belgium_1836'; core = 'belgium_1836';
      } else if (['prov_stockholm', 'prov_oslo'].includes(tmpl.id)) {
        owner = 'sweden_1836'; core = 'sweden_1836';
      } else if (['prov_copenhagen'].includes(tmpl.id)) {
        owner = 'denmark_1836'; core = 'denmark_1836';
      } else if (['prov_switzerland'].includes(tmpl.id)) {
        owner = 'austria_1836'; core = 'austria_1836';
      } else if (['prov_naples', 'prov_sicily'].includes(tmpl.id)) {
        owner = 'twosicilies_1836'; core = 'twosicilies_1836';
      } else if (['prov_rome'].includes(tmpl.id)) {
        owner = 'twosicilies_1836'; core = 'twosicilies_1836';
      } else if (['prov_beijing', 'prov_shanghai', 'prov_canton', 'prov_manchuria', 'prov_tibet'].includes(tmpl.id)) {
        owner = 'qing_1836'; core = 'qing_1836';
      } else if (['prov_tokyo', 'prov_osaka'].includes(tmpl.id)) {
        owner = 'japan_1836'; core = 'japan_1836';
      } else if (['prov_korea'].includes(tmpl.id)) {
        owner = 'qing_1836'; core = 'qing_1836';
      } else if (['prov_tehran', 'prov_afghanistan'].includes(tmpl.id)) {
        owner = 'persia_1836'; core = 'persia_1836';
      } else if (['prov_arabia'].includes(tmpl.id)) {
        owner = 'ottoman_1836'; core = 'ottoman_1836';
      } else if (['prov_morocco', 'prov_tunis'].includes(tmpl.id)) {
        owner = 'ottoman_1836'; core = 'ottoman_1836';
      } else if (['prov_west_africa', 'prov_central_africa', 'prov_east_africa'].includes(tmpl.id)) {
        owner = 'britain_1836'; core = 'britain_1836';
      } else if (['prov_indochina'].includes(tmpl.id)) {
        owner = 'siam_1836'; core = 'siam_1836';
      } else if (['prov_colombia'].includes(tmpl.id)) {
        owner = 'colombia_1836'; core = 'colombia_1836';
      } else if (['prov_peru'].includes(tmpl.id)) {
        owner = 'peru_1836'; core = 'peru_1836';
      } else if (['prov_brazil'].includes(tmpl.id)) {
        owner = 'brazil_1836'; core = 'brazil_1836';
      } else if (['prov_argentina'].includes(tmpl.id)) {
        owner = 'argentina_1836'; core = 'argentina_1836';
      } else {
        owner = 'britain_1836'; core = 'britain_1836';
      }
    } else if (eraId === 'ww2_1939') {
      if (['prov_moscow', 'prov_stpetersburg', 'prov_novgorod', 'prov_kiev', 'prov_minsk', 'prov_kharkov', 'prov_crimea', 'prov_odessa', 'prov_stalingrad', 'prov_kazan', 'prov_ural', 'prov_siberia_west', 'prov_siberia_east', 'prov_far_east', 'prov_caucasus', 'prov_central_asia'].includes(tmpl.id)) {
        owner = 'ussr_1939'; core = 'ussr_1939';
      } else if (['prov_berlin', 'prov_rhineland', 'prov_bavaria', 'prov_silesia', 'prov_vienna', 'prov_prague', 'prov_warsaw', 'prov_oslo', 'prov_copenhagen', 'prov_amsterdam', 'prov_brussels'].includes(tmpl.id)) {
        owner = 'germany_1939'; core = 'germany_1939';
      } else if (['prov_london', 'prov_scotland', 'prov_ireland', 'prov_delhi', 'prov_bombay', 'prov_bengal', 'prov_cairo', 'prov_alexandria', 'prov_baghdad', 'prov_canada', 'prov_australia', 'prov_south_africa', 'prov_east_africa', 'prov_west_africa'].includes(tmpl.id)) {
        owner = 'britain_1939'; core = 'britain_1939';
      } else if (['prov_washington', 'prov_newyork', 'prov_midwest', 'prov_plains', 'prov_california', 'prov_texas', 'prov_philippines'].includes(tmpl.id)) {
        owner = 'usa_1939'; core = 'usa_1939';
      } else if (['prov_tokyo', 'prov_osaka', 'prov_korea', 'prov_manchuria', 'prov_beijing', 'prov_shanghai'].includes(tmpl.id)) {
        owner = 'japan_1939'; core = 'japan_1939';
      } else if (['prov_paris', 'prov_aquitaine', 'prov_marseille', 'prov_algiers', 'prov_morocco', 'prov_tunis', 'prov_indochina', 'prov_central_africa', 'prov_levant'].includes(tmpl.id)) {
        owner = 'france_1939'; core = 'france_1939';
      } else if (['prov_rome', 'prov_milan', 'prov_venice', 'prov_naples', 'prov_sicily', 'prov_tripoli', 'prov_athens', 'prov_belgrade'].includes(tmpl.id)) {
        owner = 'italy_1939'; core = 'italy_1939';
      } else if (['prov_canton', 'prov_tibet'].includes(tmpl.id)) {
        owner = 'china_1939'; core = 'china_1939';
      } else if (['prov_helsinki'].includes(tmpl.id)) {
        owner = 'finland_1939'; core = 'finland_1939';
      } else if (['prov_stockholm'].includes(tmpl.id)) {
        owner = 'sweden_1939'; core = 'sweden_1939';
      } else if (['prov_madrid', 'prov_barcelona', 'prov_andalusia'].includes(tmpl.id)) {
        owner = 'spain_1939'; core = 'spain_1939';
      } else if (['prov_lisbon'].includes(tmpl.id)) {
        owner = 'france_1939'; core = 'france_1939';
      } else if (['prov_bucharest', 'prov_budapest'].includes(tmpl.id)) {
        owner = 'germany_1939'; core = 'germany_1939';
      } else if (['prov_constantinople', 'prov_ankara'].includes(tmpl.id)) {
        owner = 'turkey_1939'; core = 'turkey_1939';
      } else if (['prov_tehran', 'prov_afghanistan'].includes(tmpl.id)) {
        owner = 'ussr_1939'; core = 'ussr_1939';
      } else if (['prov_arabia'].includes(tmpl.id)) {
        owner = 'britain_1939'; core = 'britain_1939';
      } else if (['prov_indonesia'].includes(tmpl.id)) {
        owner = 'japan_1939'; core = 'japan_1939';
      } else if (['prov_mexico_north', 'prov_mexico_city', 'prov_caribbean'].includes(tmpl.id)) {
        owner = 'mexico_1939'; core = 'mexico_1939';
      } else if (['prov_colombia', 'prov_peru'].includes(tmpl.id)) {
        owner = 'usa_1939'; core = 'usa_1939';
      } else if (['prov_brazil'].includes(tmpl.id)) {
        owner = 'brazil_1939'; core = 'brazil_1939';
      } else if (['prov_argentina'].includes(tmpl.id)) {
        owner = 'argentina_1939'; core = 'argentina_1939';
      } else {
        owner = 'germany_1939'; core = 'germany_1939';
      }
    } else if (eraId === 'modern_2026') {
      if (['prov_moscow', 'prov_stpetersburg', 'prov_novgorod', 'prov_crimea', 'prov_stalingrad', 'prov_kazan', 'prov_ural', 'prov_siberia_west', 'prov_siberia_east', 'prov_far_east', 'prov_caucasus', 'prov_minsk'].includes(tmpl.id)) {
        owner = 'russia_2026'; core = 'russia_2026';
      } else if (['prov_washington', 'prov_newyork', 'prov_midwest', 'prov_plains', 'prov_california', 'prov_texas'].includes(tmpl.id)) {
        owner = 'usa_2026'; core = 'usa_2026';
      } else if (['prov_beijing', 'prov_shanghai', 'prov_canton', 'prov_manchuria', 'prov_tibet'].includes(tmpl.id)) {
        owner = 'china_2026'; core = 'china_2026';
      } else if (['prov_berlin', 'prov_rhineland', 'prov_bavaria', 'prov_silesia', 'prov_vienna', 'prov_prague', 'prov_switzerland', 'prov_amsterdam', 'prov_copenhagen', 'prov_stockholm', 'prov_oslo', 'prov_helsinki'].includes(tmpl.id)) {
        owner = 'germany_2026'; core = 'germany_2026';
      } else if (['prov_london', 'prov_scotland', 'prov_ireland'].includes(tmpl.id)) {
        owner = 'britain_2026'; core = 'britain_2026';
      } else if (['prov_delhi', 'prov_bombay', 'prov_bengal'].includes(tmpl.id)) {
        owner = 'india_2026'; core = 'india_2026';
      } else if (['prov_paris', 'prov_aquitaine', 'prov_marseille', 'prov_brussels', 'prov_madrid', 'prov_barcelona', 'prov_andalusia', 'prov_lisbon'].includes(tmpl.id)) {
        owner = 'france_2026'; core = 'france_2026';
      } else if (['prov_rome', 'prov_milan', 'prov_venice', 'prov_naples', 'prov_sicily'].includes(tmpl.id)) {
        owner = 'italy_2026'; core = 'italy_2026';
      } else if (['prov_tokyo', 'prov_osaka'].includes(tmpl.id)) {
        owner = 'japan_2026'; core = 'japan_2026';
      } else if (['prov_korea'].includes(tmpl.id)) {
        owner = 'korea_2026'; core = 'korea_2026';
      } else if (['prov_warsaw'].includes(tmpl.id)) {
        owner = 'poland_2026'; core = 'poland_2026';
      } else if (['prov_kiev', 'prov_kharkov', 'prov_odessa'].includes(tmpl.id)) {
        owner = 'ukraine_2026'; core = 'ukraine_2026';
      } else if (['prov_constantinople', 'prov_ankara'].includes(tmpl.id)) {
        owner = 'turkey_2026'; core = 'turkey_2026';
      } else if (['prov_tehran', 'prov_baghdad', 'prov_afghanistan', 'prov_central_asia'].includes(tmpl.id)) {
        owner = 'iran_2026'; core = 'iran_2026';
      } else if (['prov_arabia', 'prov_levant'].includes(tmpl.id)) {
        owner = 'saudi_2026'; core = 'saudi_2026';
      } else if (['prov_cairo', 'prov_alexandria', 'prov_tripoli'].includes(tmpl.id)) {
        owner = 'egypt_2026'; core = 'egypt_2026';
      } else if (['prov_morocco', 'prov_algiers', 'prov_tunis'].includes(tmpl.id)) {
        owner = 'france_2026'; core = 'france_2026';
      } else if (['prov_south_africa', 'prov_central_africa', 'prov_east_africa', 'prov_west_africa'].includes(tmpl.id)) {
        owner = 'southafrica_2026'; core = 'southafrica_2026';
      } else if (['prov_indonesia', 'prov_indochina', 'prov_philippines'].includes(tmpl.id)) {
        owner = 'indonesia_2026'; core = 'indonesia_2026';
      } else if (['prov_australia'].includes(tmpl.id)) {
        owner = 'australia_2026'; core = 'australia_2026';
      } else if (['prov_canada'].includes(tmpl.id)) {
        owner = 'canada_2026'; core = 'canada_2026';
      } else if (['prov_mexico_north', 'prov_mexico_city', 'prov_caribbean'].includes(tmpl.id)) {
        owner = 'mexico_2026'; core = 'mexico_2026';
      } else if (['prov_brazil', 'prov_colombia', 'prov_peru', 'prov_argentina'].includes(tmpl.id)) {
        owner = 'brazil_2026'; core = 'brazil_2026';
      } else {
        owner = 'usa_2026'; core = 'usa_2026';
      }
    } else {
      // Renaissance 1500
      if (['prov_stpetersburg', 'prov_moscow', 'prov_novgorod', 'prov_kazan', 'prov_ural', 'prov_stalingrad'].includes(tmpl.id)) {
        owner = 'yarogor'; core = 'yarogor';
      } else if (['prov_madrid', 'prov_andalusia', 'prov_barcelona', 'prov_naples', 'prov_sicily', 'prov_caribbean'].includes(tmpl.id)) {
        owner = 'castelia'; core = 'castelia';
      } else if (['prov_paris', 'prov_aquitaine', 'prov_marseille', 'prov_brussels'].includes(tmpl.id)) {
        owner = 'valerion'; core = 'valerion';
      } else if (['prov_london', 'prov_scotland', 'prov_ireland'].includes(tmpl.id)) {
        owner = 'england_1500'; core = 'england_1500';
      } else if (['prov_lisbon', 'prov_brazil'].includes(tmpl.id)) {
        owner = 'portugal_1500'; core = 'portugal_1500';
      } else if (['prov_constantinople', 'prov_ankara', 'prov_levant', 'prov_cairo', 'prov_alexandria', 'prov_baghdad', 'prov_athens', 'prov_belgrade'].includes(tmpl.id)) {
        owner = 'al_zahir'; core = 'al_zahir';
      } else if (['prov_berlin', 'prov_rhineland', 'prov_bavaria', 'prov_vienna', 'prov_prague', 'prov_switzerland'].includes(tmpl.id)) {
        owner = 'bergland'; core = 'bergland';
      } else if (['prov_milan', 'prov_venice', 'prov_rome'].includes(tmpl.id)) {
        owner = 'serenissima'; core = 'serenissima';
      } else if (['prov_warsaw', 'prov_kiev', 'prov_minsk'].includes(tmpl.id)) {
        owner = 'poland_1500'; core = 'poland_1500';
      } else if (['prov_stockholm', 'prov_oslo', 'prov_copenhagen', 'prov_helsinki'].includes(tmpl.id)) {
        owner = 'sweden_1500'; core = 'sweden_1500';
      } else if (['prov_tehran', 'prov_caucasus', 'prov_central_asia'].includes(tmpl.id)) {
        owner = 'safavid_1500'; core = 'safavid_1500';
      } else if (['prov_beijing', 'prov_shanghai', 'prov_canton', 'prov_manchuria'].includes(tmpl.id)) {
        owner = 'minghai'; core = 'minghai';
      } else if (['prov_tokyo', 'prov_osaka'].includes(tmpl.id)) {
        owner = 'japan_1500'; core = 'japan_1500';
      } else if (['prov_delhi', 'prov_bombay', 'prov_bengal'].includes(tmpl.id)) {
        owner = 'al_zahir'; core = 'al_zahir';
      } else {
        owner = 'valerion'; core = 'valerion';
      }
    }

    result[tmpl.id] = {
      id: tmpl.id,
      name: tmpl.name,
      ownerNationId: owner,
      coreNationId: core,
      capital: cap,
      population: tmpl.population,
      taxBase: tmpl.taxBase,
      productionBase: tmpl.productionBase,
      resource: tmpl.resource,
      terrain: tmpl.terrain,
      developmentLevel: cap ? 8 : 5,
      fortLevel: cap ? 3 : 1,
      barracksLevel: cap ? 2 : 1,
      buildings: cap ? ['market', 'workshop', 'fort', 'academy'] : ['market', 'workshop'],
      unrest: 4,
      center: tmpl.center,
      svgPath: tmpl.svgPath,
      neighborIds: tmpl.neighborIds,
      supplyLimit: tmpl.supplyLimit,
      claimsBy: []
    };
  });

  return result;
}
