import { Technology } from '../types/game';
import { TECHNOLOGIES_DATA } from './technologies';

export const VICTORIAN_TECH: Record<string, Technology> = {
  'tech_steam_engine': {
    id: 'tech_steam_engine',
    name: 'Паровой двигатель',
    category: 'economy',
    tier: 1,
    cost: 120,
    description: 'Внедрение паровых машин на шахтах, ткацких мануфактурах и мельницах.',
    effects: '+25% к добыче угля и железа, +20% к доходу фабрик',
    modifier: { productionEfficiency: 0.25 }
  },
  'tech_railways': {
    id: 'tech_railways',
    name: 'Чугунные железные дороги',
    category: 'economy',
    tier: 1,
    cost: 150,
    description: 'Строительство первых магистральных рельсовых путей между промышленными центрами.',
    effects: '+30% к скорости перемещения армий и торговому обороту',
    modifier: { tradeEfficiency: 0.30 }
  },
  'tech_rifled_guns': {
    id: 'tech_rifled_guns',
    name: 'Нарезные штуцеры и винтовки',
    category: 'military',
    tier: 2,
    cost: 160,
    description: 'Винтовые нарезы в стволе обеспечивают прицельную стрельбу на сотни шагов.',
    effects: '+25% к урону пехоты, эффективная контрбатарейная борьба',
    modifier: { infantryAttack: 0.25 }
  },
  'tech_telegraph': {
    id: 'tech_telegraph',
    name: 'Электрический телеграф Морзе',
    category: 'administration',
    tier: 2,
    cost: 140,
    description: 'Мгновенная передача депеш и военных приказов по проводам на тысячи километров.',
    effects: '+20% к скорости реакции армии, +2 к дипломатическим очкам',
    modifier: { stabilityCostReduction: 0.20 }
  },
  'tech_iron_mines': {
    id: 'tech_iron_mines',
    name: 'Бессемеровский процесс выплавки стали',
    category: 'science',
    tier: 2,
    cost: 180,
    description: 'Продувка жидкого чугуна воздухом для массового производства дешевой высокопрочной стали.',
    effects: '+35% к производству оружия и артиллерии',
    modifier: { productionEfficiency: 0.35, artilleryAttack: 0.20 }
  },
  'tech_dreadnought': {
    id: 'tech_dreadnought',
    name: 'Броненосцы и паровой флот',
    category: 'military',
    tier: 3,
    cost: 260,
    description: 'Цельнометаллические боевые корабли с паровыми котлами и башенной артиллерией.',
    effects: '+40% к мощи флота, блокада морских путей врага',
    modifier: { fortDefense: 0.30, tradeEfficiency: 0.25 }
  }
};

export const WW2_TECH: Record<string, Technology> = {
  'tech_tank_corps': {
    id: 'tech_tank_corps',
    name: 'Средние и тяжелые танки',
    category: 'military',
    tier: 1,
    cost: 160,
    description: 'Массовое производство дизельных средних танков с наклонной броней.',
    effects: '+35% к ударной мощи прорыва и кавалерийских дивизий',
    modifier: { cavalryAttack: 0.35, infantryAttack: 0.15 }
  },
  'tech_blitzkrieg': {
    id: 'tech_blitzkrieg',
    name: 'Доктрина глубокой наступательной операции',
    category: 'military',
    tier: 2,
    cost: 220,
    description: 'Координация танковых клиньев, штурмовой авиации и мотопехоты для окружения врага.',
    effects: '+40% к скорости марша, сокрушение линий обороны',
    modifier: { moraleBonus: 15, infantryAttack: 0.20 }
  },
  'tech_radar': {
    id: 'tech_radar',
    name: 'Радиолокационные станции и ПВО',
    category: 'science',
    tier: 1,
    cost: 150,
    description: 'Раннее обнаружение вражеских эскадрилий и кораблей в тумане и ночью.',
    effects: '+30% к защите крепостей и городов от бомбардировок',
    modifier: { fortDefense: 0.30 }
  },
  'tech_heavy_artillery': {
    id: 'tech_heavy_artillery',
    name: 'Реактивные минометы («Катюша»)',
    category: 'military',
    tier: 2,
    cost: 200,
    description: 'Залповый ракетный огонь, сметающий целые полки противника за секунды.',
    effects: '+40% к артиллерийскому урону, подавление морали врага',
    modifier: { artilleryAttack: 0.40 }
  },
  'tech_aircraft_carriers': {
    id: 'tech_aircraft_carriers',
    name: 'Ударные авианосные группы',
    category: 'military',
    tier: 3,
    cost: 280,
    description: 'Плавающие аэродромы с торпедоносцами и пикировщиками для господства на океанах.',
    effects: '+35% к контролю побережий и блокаде портов',
    modifier: { tradeEfficiency: 0.30 }
  },
  'tech_nuclear_program': {
    id: 'tech_nuclear_program',
    name: 'Атомный проект',
    category: 'science',
    tier: 3,
    cost: 400,
    description: 'Расщепление атома урана и плутония. Создание оружия колоссальной разрушительной силы.',
    effects: '+50 к престижу державы, безоговорочная капитуляция противников',
    modifier: { moraleBonus: 30, fortDefense: 0.50 }
  }
};

export const MODERN_TECH: Record<string, Technology> = {
  'tech_cyber_warfare': {
    id: 'tech_cyber_warfare',
    name: 'Киберкомандование и защита энергосетей',
    category: 'science',
    tier: 1,
    cost: 180,
    description: 'Автоматизированный мониторинг сетей, отражение атак на банковские системы и спутники.',
    effects: '+25% к защите казны от кризисов, нейтрализация вражеских радаров',
    modifier: { taxEfficiency: 0.25 }
  },
  'tech_drone_swarms': {
    id: 'tech_drone_swarms',
    name: 'Рои FPV-дронов и барражирующие припасы',
    category: 'military',
    tier: 1,
    cost: 200,
    description: 'Высокоточное поражение бронетехники и живой силы противника с воздуха.',
    effects: '+30% к урону всех сухопутных войск, минимальные потери операторов',
    modifier: { infantryAttack: 0.30, artilleryAttack: 0.25 }
  },
  'tech_ai_systems': {
    id: 'tech_ai_systems',
    name: 'Нейросетевое планирование и логистика',
    category: 'administration',
    tier: 2,
    cost: 250,
    description: 'Оптимизация цепочек поставок, распределения ресурсов и налогового надзора через ИИ.',
    effects: '+35% к скорости исследований и сбору налогов',
    modifier: { researchSpeed: 0.35, taxEfficiency: 0.20 }
  },
  'tech_hypersonic': {
    id: 'tech_hypersonic',
    name: 'Гиперзвуковые ракетные комплексы',
    category: 'military',
    tier: 2,
    cost: 300,
    description: 'Полет со скоростью свыше 8 Махов по непредсказуемой траектории в атмосфере.',
    effects: '+50% к разрушению вражеских бастионов и штабов',
    modifier: { artilleryAttack: 0.50 }
  },
  'tech_green_energy': {
    id: 'tech_green_energy',
    name: 'Возобновляемая энергия и термояд',
    category: 'economy',
    tier: 2,
    cost: 280,
    description: 'Солнечные, ветровые и опытные термоядерные реакторы для энергонезависимости.',
    effects: '+30% к экологической стабильности и снижению расходов',
    modifier: { productionEfficiency: 0.30 }
  },
  'tech_quantum_net': {
    id: 'tech_quantum_net',
    name: 'Квантовый спутниковый интернет',
    category: 'science',
    tier: 3,
    cost: 380,
    description: 'Глобальная группировка низкоорбитальных спутников с неперехватываемым квантовым ключом.',
    effects: '+40% к очкам науки и абсолютная устойчивость дипломатии',
    modifier: { researchSpeed: 0.40, tradeEfficiency: 0.35 }
  }
};

export function getTechnologiesForEra(eraId: string): Record<string, Technology> {
  if (eraId === 'victorian_1836') return VICTORIAN_TECH;
  if (eraId === 'ww2_1939') return WW2_TECH;
  if (eraId === 'modern_2026') return MODERN_TECH;
  return TECHNOLOGIES_DATA;
}
