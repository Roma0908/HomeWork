import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell } from "@/components/layout/shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardDesc, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/cn";
import { EXAM_QUESTIONS } from "@/lib/course/curriculum";
import { useProgress } from "@/lib/course/progress";

export const Route = createFileRoute("/exam")({ component: ExamPage });

function ExamPage() {
  const studentName = useProgress((s) => s.studentName);
  const examScore = useProgress((s) => s.examScore);
  const setExamScore = useProgress((s) => s.setExamScore);
  const [picks, setPicks] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(examScore !== null);

  const score = useMemo(() => {
    return EXAM_QUESTIONS.reduce((acc, q) => acc + (picks[q.id] === q.correct ? 1 : 0), 0);
  }, [picks]);

  const shown = submitted ? (examScore ?? score) : null;
  const passed = shown !== null && shown >= 7;
  const honors = shown !== null && shown >= 10;

  return (
    <Shell>
      <div className="mx-auto max-w-2xl">
        <p className="text-xs font-medium tracking-wide text-muted">Лекция 12 · зачёт</p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight sm:text-4xl">Журнал кафедры</h1>
        <p className="mt-3 font-display text-lg text-muted">
          Двенадцать вопросов. Семь — зачёт, десять — отличие. Можно пересдать.
        </p>

        {submitted && shown !== null ? (
          <Card className="mt-8 rounded-2xl p-6">
            <p className="text-[11px] tracking-[0.18em] text-faint uppercase">Diploma</p>
            <CardTitle className="mt-2 text-2xl">
              {honors ? "С отличием" : passed ? "Зачёт" : "Пока без зачёта"}
            </CardTitle>
            <CardDesc>
              {studentName || "Слушатель"} · {shown}/12 · инженерия ИИ, боты → агенты
            </CardDesc>
            <Button
              className="mt-5"
              variant="outline"
              onClick={() => {
                setSubmitted(false);
                setPicks({});
              }}
            >
              Пересдать
            </Button>
          </Card>
        ) : null}

        <ol className="mt-10 space-y-8">
          {EXAM_QUESTIONS.map((q, i) => (
            <li key={q.id}>
              <p className="font-mono text-xs text-faint">{String(i + 1).padStart(2, "0")}</p>
              <p className="mt-1 font-display text-lg font-medium leading-snug">{q.q}</p>
              <div className="mt-3 grid gap-2">
                {q.options.map((opt, oi) => {
                  const selected = picks[q.id] === oi;
                  const reveal = submitted;
                  const good = oi === q.correct;
                  return (
                    <button
                      key={opt}
                      type="button"
                      disabled={submitted}
                      onClick={() => setPicks((p) => ({ ...p, [q.id]: oi }))}
                      className={cn(
                        "min-h-11 rounded-lg px-3 py-2.5 text-left text-sm leading-snug",
                        selected ? "bg-paper-2 shadow-border" : "bg-card shadow-border",
                        reveal && good && "bg-ok/10",
                        reveal && selected && !good && "bg-danger/10",
                      )}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
              {submitted ? <p className="mt-2 text-sm text-muted">{q.explain}</p> : null}
            </li>
          ))}
        </ol>

        {!submitted ? (
          <Button
            className="mt-10"
            disabled={Object.keys(picks).length < EXAM_QUESTIONS.length}
            onClick={() => {
              setExamScore(score);
              setSubmitted(true);
            }}
          >
            Сдать журнал
          </Button>
        ) : (
          <Badge className="mt-10" variant={honors ? "forest" : passed ? "ok" : "warn"}>
            {shown}/12
          </Badge>
        )}
      </div>
    </Shell>
  );
}
