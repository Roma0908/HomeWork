import { createFileRoute, notFound } from "@tanstack/react-router";
import { AgentLab, BotLab, PromptLab, ToolsLab } from "@/components/labs/labs";
import { Shell } from "@/components/layout/shell";
import { Badge } from "@/components/ui/badge";
import { LABS } from "@/lib/course/curriculum";

export const Route = createFileRoute("/lab/$labId")({
  component: LabPage,
});

function LabPage() {
  const { labId } = Route.useParams();
  const lab = LABS.find((l) => l.id === labId);
  if (!lab) throw notFound();

  return (
    <Shell>
      <div className="mx-auto max-w-5xl">
        <Badge variant="chalk">{lab.kicker}</Badge>
        <h1 className="mt-3 text-3xl font-medium tracking-tight sm:text-4xl">{lab.title}</h1>
        <p className="mt-3 max-w-2xl font-display text-lg text-muted">{lab.summary}</p>
        <div className="mt-8">
          {lab.id === "prompt" ? <PromptLab /> : null}
          {lab.id === "bot" ? <BotLab /> : null}
          {lab.id === "tools" ? <ToolsLab /> : null}
          {lab.id === "agent" ? <AgentLab /> : null}
        </div>
      </div>
    </Shell>
  );
}
