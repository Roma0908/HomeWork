import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { useState } from "react";
import { Shell } from "@/components/layout/shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardDesc, CardTitle } from "@/components/ui/card";
import { Input, Label } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { LESSONS, TRACKS, lessonsFor } from "@/lib/course/curriculum";
import { useProgress } from "@/lib/course/progress";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const studentName = useProgress((s) => s.studentName);
  const setName = useProgress((s) => s.setName);
  const onboarded = useProgress((s) => s.onboarded);
  const setOnboarded = useProgress((s) => s.setOnboarded);
  const completed = useProgress((s) => s.completed);
  const lastLessonId = useProgress((s) => s.lastLessonId);
  const examScore = useProgress((s) => s.examScore);
  const [draft, setDraft] = useState(studentName);
  const done = LESSONS.filter((l) => completed[l.id]).length;
  const last = LESSONS.find((l) => l.id === lastLessonId) ?? LESSONS[0];

  return (
    <Shell>
      <div className="mx-auto max-w-4xl stagger-in">
        <p className="text-xs font-medium tracking-[0.18em] text-muted uppercase">Facultas · MMXXVI</p>
        <h1 className="mt-3 max-w-xl text-4xl font-medium tracking-tight text-ink sm:text-5xl">
          От ботов к настоящим агентам
        </h1>
        <p className="mt-4 max-w-xl font-display text-lg leading-relaxed text-muted">
          Семестр кафедры инженерии ИИ. Двенадцать лекций, четыре лаборатории с живой моделью, зачёт.
          Сначала учимся называть вещи своими именами — потом собираем системы.
        </p>

        {!onboarded ? (
          <form
            className="mt-8 max-w-md rounded-2xl bg-card p-5 shadow-border"
            onSubmit={(e) => {
              e.preventDefault();
              setName(draft.trim().slice(0, 40));
              setOnboarded();
            }}
          >
            <Label htmlFor="name">Как записать тебя в журнал</Label>
            <Input
              id="name"
              className="mt-2"
              value={draft}
              placeholder="Имя или псевдоним"
              onChange={(e) => setDraft(e.target.value.slice(0, 40))}
            />
            <div className="mt-4 flex flex-wrap gap-2">
              <Button type="submit">Начать семестр</Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setName("");
                  setOnboarded();
                }}
              >
                Остаться слушателем
              </Button>
            </div>
          </form>
        ) : (
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Button asChild>
              <Link to="/lesson/$lessonId" params={{ lessonId: last.id }}>
                {done === 0 ? "Первая лекция" : "Продолжить"}
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <p className="text-sm text-muted">
              {studentName ? `${studentName} · ` : null}
              лекция {last.number}. {last.title}
            </p>
          </div>
        )}

        <div className="mt-10 max-w-md">
          <div className="flex items-center justify-between text-xs text-muted">
            <span>Прогресс семестра</span>
            <span className="font-mono tabular-nums">
              {done}/{LESSONS.length}
            </span>
          </div>
          <Progress value={(done / LESSONS.length) * 100} className="mt-2" />
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2">
          {TRACKS.map((track) => {
            const list = lessonsFor(track.id);
            const n = list.filter((l) => completed[l.id]).length;
            return (
              <Card key={track.id} className="rounded-2xl p-5">
                <p className="text-[11px] tracking-[0.16em] text-faint uppercase">{track.latin}</p>
                <CardTitle className="mt-2">{track.title}</CardTitle>
                <CardDesc>{track.blurb}</CardDesc>
                <div className="mt-4 flex flex-wrap gap-2">
                  {list.map((l) => (
                    <Link key={l.id} to="/lesson/$lessonId" params={{ lessonId: l.id }}>
                      <Badge variant={completed[l.id] ? "forest" : "default"}>{l.number}</Badge>
                    </Link>
                  ))}
                </div>
                <p className="mt-4 font-mono text-xs tabular-nums text-faint">
                  {n}/{list.length}
                </p>
              </Card>
            );
          })}
        </div>

        {examScore !== null ? (
          <Card className="mt-8 rounded-2xl">
            <CardTitle>Зачёт сдан</CardTitle>
            <CardDesc>
              {examScore}/12
              {examScore >= 10 ? " · отличие" : examScore >= 7 ? " · зачёт" : " · стоит пересдать"}
            </CardDesc>
          </Card>
        ) : null}
      </div>
    </Shell>
  );
}
