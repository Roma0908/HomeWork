import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { useEffect } from "react";
import { LessonBody } from "@/components/course/lesson-body";
import { Shell } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { lessonById, neighbors } from "@/lib/course/curriculum";
import { useProgress } from "@/lib/course/progress";

export const Route = createFileRoute("/lesson/$lessonId")({
  component: LessonPage,
});

function LessonPage() {
  const { lessonId } = Route.useParams();
  const lesson = lessonById(lessonId);
  if (!lesson) throw notFound();
  const { prev, next } = neighbors(lesson.id);
  const markLesson = useProgress((s) => s.markLesson);
  const setLast = useProgress((s) => s.setLast);
  const completed = useProgress((s) => s.completed);
  useEffect(() => {
    setLast(lesson.id);
  }, [lesson.id, setLast]);
  const isExam = lesson.id === "exam";

  return (
    <Shell>
      <LessonBody lesson={lesson} />
      {isExam ? (
        <div className="mx-auto mt-10 max-w-2xl">
          <Button asChild>
            <Link to="/exam">
              Открыть зачёт
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      ) : null}
      <footer className="mx-auto mt-12 flex max-w-2xl flex-col gap-3 border-t border-rule pt-6 sm:flex-row sm:items-center">
        {prev ? (
          <Button asChild variant="outline">
            <Link to="/lesson/$lessonId" params={{ lessonId: prev.id }}>
              <ArrowLeft className="size-4" />
              {prev.number}
            </Link>
          </Button>
        ) : (
          <span />
        )}
        <div className="flex flex-1 flex-wrap items-center justify-end gap-2">
          <Button
            variant={completed[lesson.id] ? "forest" : "outline"}
            onClick={() => markLesson(lesson.id)}
          >
            <Check className="size-4" />
            {completed[lesson.id] ? "В журнале" : "Отметить прочитанным"}
          </Button>
          {next ? (
            <Button asChild>
              <Link to="/lesson/$lessonId" params={{ lessonId: next.id }}>
                Дальше
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          ) : (
            <Button asChild>
              <Link to="/exam">
                К зачёту
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          )}
        </div>
      </footer>
    </Shell>
  );
}
