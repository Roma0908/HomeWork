import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/layout/shell";
import { GLOSSARY } from "@/lib/course/curriculum";

export const Route = createFileRoute("/glossary")({ component: GlossaryPage });

function GlossaryPage() {
  return (
    <Shell>
      <div className="mx-auto max-w-2xl">
        <p className="text-xs font-medium tracking-wide text-muted">Словарь кафедры</p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight sm:text-4xl">Глоссарий</h1>
        <p className="mt-3 font-display text-lg text-muted">
          Короткие определения. Если термин в лекции кажется чужим — вернись сюда.
        </p>
        <dl className="mt-10 divide-y divide-rule">
          {GLOSSARY.map((g) => (
            <div key={g.term} className="grid gap-1 py-5 sm:grid-cols-[180px_minmax(0,1fr)] sm:gap-6">
              <dt className="font-medium text-ink">{g.term}</dt>
              <dd className="text-sm leading-relaxed text-muted sm:text-base">{g.def}</dd>
            </div>
          ))}
        </dl>
      </div>
    </Shell>
  );
}
