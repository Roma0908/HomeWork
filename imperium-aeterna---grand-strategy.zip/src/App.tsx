/**
 * Imperium Aeterna - Grand Strategy Game
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameProvider, useGame } from './context/GameContext';
import { WorldMap } from './components/Map/WorldMap';
import { TopBar } from './components/TopBar/TopBar';
import { LeftSidebar } from './components/LeftPanel/LeftSidebar';
import { BottomPanel } from './components/BottomPanel/BottomPanel';
import { RightNotificationFeed } from './components/RightPanel/RightNotificationFeed';
import { EventModal } from './components/Modals/EventModal';
import { BattleModal } from './components/Modals/BattleModal';
import { PeaceDealModal } from './components/Modals/PeaceDealModal';
import { TutorialModal } from './components/Modals/TutorialModal';
import { MainMenu } from './components/Menu/MainMenu';

const GameViewport: React.FC = () => {
  const { state, togglePause, setSpeed, selectProvince, selectArmy } = useGame();
  const [hasStartedGame, setHasStartedGame] = useState(false);
  const [showMainMenu, setShowMainMenu] = useState(true);
  const [showTutorial, setShowTutorial] = useState(false);
  const [activePeaceWarId, setActivePeaceWarId] = useState<string | null>(null);

  // Show tutorial on very first launch
  useEffect(() => {
    const hasSeen = localStorage.getItem('imperium_seen_tutorial');
    if (!hasSeen) {
      setShowTutorial(true);
      localStorage.setItem('imperium_seen_tutorial', 'true');
    }
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if typing in an input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        togglePause();
      } else if (e.key === '1') {
        setSpeed(1);
      } else if (e.key === '2') {
        setSpeed(2);
      } else if (e.key === '3') {
        setSpeed(5);
      } else if (e.key === '4') {
        setSpeed(10);
      } else if (e.key === '5') {
        setSpeed(20);
      } else if (e.key === 'Escape') {
        if (state.selectedArmyId) {
          selectArmy(null);
        } else if (state.selectedProvinceId) {
          selectProvince(null);
        } else {
          setShowMainMenu(prev => !prev);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePause, setSpeed, state.selectedArmyId, state.selectedProvinceId, selectArmy, selectProvince]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#0a0e17] text-slate-100 flex flex-col font-sans select-none">
      {/* Top HUD */}
      <TopBar
        onOpenMenu={() => setShowMainMenu(true)}
        onOpenTutorial={() => setShowTutorial(true)}
      />

      {/* Main Interactive Stage */}
      <main className="relative flex-1 w-full h-[calc(100vh-3.5rem)] overflow-hidden">
        {/* SVG World Map */}
        <WorldMap />

        {/* Collapsible Left Strategy Panels */}
        <LeftSidebar />

        {/* Selected Province / Army Bottom Controls */}
        <BottomPanel />

        {/* Event / War Right Feed */}
        <RightNotificationFeed />

        {/* Interactive Modals */}
        <EventModal />
        <BattleModal />
        {activePeaceWarId && (
          <PeaceDealModal
            warId={activePeaceWarId}
            onClose={() => setActivePeaceWarId(null)}
          />
        )}
        {showTutorial && <TutorialModal onClose={() => setShowTutorial(false)} />}
      </main>

      {/* Main Menu Overlay */}
      {showMainMenu && (
        <MainMenu
          onCloseMenu={() => {
            setHasStartedGame(true);
            setShowMainMenu(false);
          }}
          isIngame={hasStartedGame}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <GameProvider>
      <GameViewport />
    </GameProvider>
  );
}
