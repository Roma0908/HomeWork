import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import {
  GameState,
  Nation,
  Province,
  Army,
  War,
  Battle,
  MapMode,
  GameEvent,
  GameNotification,
  UnitCounts,
  DiplomaticRelation,
  EraId
} from '../types/game';
import { getEraSetup } from '../data/eraLoader';
import { ERA_SPECIFIC_EVENTS } from '../data/historicalEras';
import { GAME_EVENTS } from '../data/events';
import { soundManager } from '../utils/audio';
import { resolveCombatRound, applyCasualties, getTotalTroopCount, calculateSupplyAttrition } from '../utils/combat';
import { runNationAIMonthly } from '../utils/ai';

interface GameContextType {
  state: GameState;
  startNewGame: (nationId: string, eraId?: EraId) => void;
  selectScenario: (eraId: EraId) => void;
  loadGame: () => boolean;
  saveGame: () => void;
  setSpeed: (speed: number) => void;
  togglePause: () => void;
  setMapMode: (mode: MapMode) => void;
  selectProvince: (id: string | null) => void;
  selectArmy: (id: string | null) => void;
  moveArmy: (armyId: string, targetProvinceId: string) => void;
  recruitUnits: (provinceId: string, unitType: keyof UnitCounts, amount: number) => boolean;
  buildBuilding: (provinceId: string, buildingType: 'market' | 'workshop' | 'barracks' | 'fort' | 'academy') => boolean;
  upgradeDevelopment: (provinceId: string) => boolean;
  declareWar: (targetNationId: string) => boolean;
  proposePeace: (warId: string, demandedProvinceIds: string[]) => boolean;
  formAlliance: (targetNationId: string) => boolean;
  signNonAggression: (targetNationId: string) => boolean;
  signTradeDeal: (targetNationId: string) => boolean;
  improveRelations: (targetNationId: string) => boolean;
  worsenRelations: (targetNationId: string) => boolean;
  imposeSanctions: (targetNationId: string) => boolean;
  createVassal: (targetNationId: string) => boolean;
  declareRival: (targetNationId: string) => boolean;
  removeRival: (targetNationId: string) => boolean;
  sendGift: (targetNationId: string, amount: number) => boolean;
  fabricateClaim: (targetProvinceId: string) => boolean;
  guaranteeIndependence: (targetNationId: string) => boolean;
  sendMilitaryAid: (targetNationId: string) => boolean;
  switchPlayerNation: (nationId: string) => void;
  startTechResearch: (techId: string) => boolean;
  handleEventOption: (actionId: string) => void;
  interactEstate: (estateId: string, action: 'grant_privilege' | 'curtail_power' | 'subsidize') => void;
  takeLoan: () => void;
  repayLoan: () => void;
  adjustTaxRate: (delta: number) => void;
  dismissNotification: (id: string) => void;
  closeActiveBattleModal: () => void;
  toggleAudio: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

function createInitialState(playerNationId?: string, eraId: EraId = 'victorian_1836'): GameState {
  const setup = getEraSetup(eraId);
  const effectivePlayerId = playerNationId && setup.nations[playerNationId] ? playerNationId : setup.defaultPlayerId;
  const nations = setup.nations;
  if (nations[effectivePlayerId]) {
    nations[effectivePlayerId].isPlayer = true;
  }

  return {
    currentEra: eraId,
    currentDate: {
      day: setup.startDate.day,
      month: setup.startDate.month,
      year: setup.startDate.year
    },
    gameSpeed: 1,
    isPaused: false,
    playerNationId: effectivePlayerId,
    nations,
    provinces: setup.provinces,
    armies: setup.armies,
    wars: [],
    battles: [],
    diplomacy: setup.diplomacy,
    technologies: setup.technologies,
    notifications: [
      {
        id: 'notif_welcome',
        date: `${setup.startDate.day} ${setup.startDate.month} ${setup.startDate.year}`,
        title: 'Начало Эпохи Власти',
        message: `Вы возглавили державу ${nations[effectivePlayerId]?.name}. Проведите нацию сквозь бури эпохи к мировому величию!`,
        type: 'event'
      }
    ],
    activeEvent: null,
    activeBattle: null,
    selectedProvinceId: nations[effectivePlayerId]?.capitalProvinceId || 'prov_london',
    selectedArmyId: null,
    mapMode: 'political',
    audioEnabled: true,
    volume: 0.5
  };
}

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<GameState>(() => createInitialState(undefined, 'victorian_1836'));
  const stateRef = useRef(state);
  stateRef.current = state;

  const logNotification = useCallback((
    title: string,
    message: string,
    type: 'war' | 'peace' | 'diplomacy' | 'tech' | 'event' | 'economy'
  ) => {
    const cur = stateRef.current.currentDate;
    const dateStr = `${cur.day} ${getMonthName(cur.month)} ${cur.year}`;
    setState(prev => ({
      ...prev,
      notifications: [
        {
          id: `notif_${Date.now()}_${Math.random()}`,
          date: dateStr,
          title,
          message,
          type
        },
        ...prev.notifications.slice(0, 24)
      ]
    }));
  }, []);

  // --- Game Loop Engine ---
  useEffect(() => {
    if (state.isPaused || state.gameSpeed === 0) return;

    // Milliseconds per game day: speed 1=1000ms, 2=500ms, 5=200ms, 10=100ms, 20=50ms
    const intervalMs = Math.max(50, Math.round(1000 / state.gameSpeed));

    const timer = setInterval(() => {
      tickDay();
    }, intervalMs);

    return () => clearInterval(timer);
  }, [state.isPaused, state.gameSpeed]);

  const tickDay = () => {
    setState(prevState => {
      // If modal event is active, auto-pause or halt day progress
      if (prevState.activeEvent) {
        return prevState;
      }

      let { day, month, year } = prevState.currentDate;
      day += 1;
      let monthChanged = false;
      if (day > 30) {
        day = 1;
        month += 1;
        monthChanged = true;
      }
      if (month > 12) {
        month = 1;
        year += 1;
      }

      const nextDate = { day, month, year };
      const nextNations = { ...prevState.nations };
      const nextProvinces = { ...prevState.provinces };
      const nextArmies = { ...prevState.armies };
      const nextDiplomacy = { ...prevState.diplomacy };
      let nextWars = [...prevState.wars];
      let nextBattles = [...prevState.battles];
      let nextActiveEvent: GameEvent | null = prevState.activeEvent;
      let nextActiveBattle: Battle | null = prevState.activeBattle;

      // 1. Army Movement
      Object.values(nextArmies).forEach(army => {
        if (army.isMoving && army.targetProvinceId) {
          // Increase progress by 10-15% per day based on terrain / maneuver
          const maneuverBonus = army.general ? army.general.maneuver * 2 : 0;
          army.movementProgress += (12 + maneuverBonus);

          if (army.movementProgress >= 100) {
            army.provinceId = army.targetProvinceId;
            army.targetProvinceId = undefined;
            army.path = [];
            army.movementProgress = 0;
            army.isMoving = false;
            army.status = 'idle';

            // Check if entered hostile province
            const prov = nextProvinces[army.provinceId];
            if (prov) {
              const diplo = nextDiplomacy[army.nationId]?.[prov.ownerNationId];
              const isHostile = diplo?.isAtWar;

              // Check if enemy army present in province
              const enemyArmy = Object.values(nextArmies).find(
                a => a.provinceId === prov.id && a.nationId !== army.nationId && nextDiplomacy[army.nationId]?.[a.nationId]?.isAtWar
              );

              if (enemyArmy) {
                // Trigger Battle!
                soundManager.playWarHorn();
                army.status = 'fighting';
                enemyArmy.status = 'fighting';

                const newBattle: Battle = {
                  id: `battle_${Date.now()}_${Math.random()}`,
                  provinceId: prov.id,
                  attackerArmyId: army.id,
                  defenderArmyId: enemyArmy.id,
                  attackerNationId: army.nationId,
                  defenderNationId: enemyArmy.nationId,
                  attackerLosses: 0,
                  defenderLosses: 0,
                  attackerMorale: army.morale,
                  defenderMorale: enemyArmy.morale,
                  day: 1,
                  terrain: prov.terrain,
                  resolved: false
                };
                nextBattles.push(newBattle);
                if (army.nationId === prevState.playerNationId || enemyArmy.nationId === prevState.playerNationId) {
                  nextActiveBattle = newBattle;
                }
              } else if (isHostile && prov.ownerNationId !== army.nationId && prov.occupiedBy !== army.nationId) {
                // Start besieging
                army.status = 'besieging';
                prov.siegeProgress = (prov.siegeProgress || 0) + 15;
              }
            }
          }
        } else if (army.status === 'besieging') {
          const prov = nextProvinces[army.provinceId];
          if (prov && prov.occupiedBy !== army.nationId) {
            const fortLevel = prov.fortLevel || 0;
            const siegePower = (army.units.siege * 2) + (army.units.artillery * 0.5) + (army.general ? army.general.attack : 0);
            const progressGain = Math.max(5, Math.round(15 + siegePower * 0.1 - (fortLevel * 3)));
            prov.siegeProgress = (prov.siegeProgress || 0) + progressGain;

            if (prov.siegeProgress >= 100) {
              prov.occupiedBy = army.nationId;
              prov.siegeProgress = 0;
              army.status = 'idle';
              soundManager.playCoins();

              // Update war score
              const activeWar = nextWars.find(w =>
                (w.attackers.includes(army.nationId) && w.defenders.includes(prov.ownerNationId)) ||
                (w.defenders.includes(army.nationId) && w.attackers.includes(prov.ownerNationId))
              );
              if (activeWar) {
                const deltaScore = prov.capital ? 25 : 10;
                if (activeWar.attackers.includes(army.nationId)) {
                  activeWar.warScore = Math.min(100, activeWar.warScore + deltaScore);
                } else {
                  activeWar.warScore = Math.max(-100, activeWar.warScore - deltaScore);
                }
              }
            }
          }
        }
      });

      // 2. Battle Resolutions
      nextBattles = nextBattles.filter(battle => {
        if (battle.resolved) return false;

        const attArmy = nextArmies[battle.attackerArmyId];
        const defArmy = nextArmies[battle.defenderArmyId];
        const prov = nextProvinces[battle.provinceId];

        if (!attArmy || !defArmy || !prov) {
          battle.resolved = true;
          return false;
        }

        const round = resolveCombatRound(attArmy, defArmy, prov);
        applyCasualties(attArmy, round.attackerCasualties);
        applyCasualties(defArmy, round.defenderCasualties);

        battle.attackerLosses += round.attackerCasualties;
        battle.defenderLosses += round.defenderCasualties;
        battle.attackerMorale = Math.max(0, attArmy.morale + round.attackerMoraleChange);
        battle.defenderMorale = Math.max(0, defArmy.morale + round.defenderMoraleChange);
        attArmy.morale = battle.attackerMorale;
        defArmy.morale = battle.defenderMorale;
        battle.day += 1;

        if (round.isOver) {
          battle.resolved = true;
          battle.victorNationId = round.victorNationId;

          // Victor and loser cleanup
          const victorArmy = round.victorNationId === attArmy.nationId ? attArmy : defArmy;
          const defeatedArmy = round.victorNationId === attArmy.nationId ? defArmy : attArmy;

          victorArmy.status = 'idle';
          victorArmy.morale = Math.min(100, victorArmy.morale + 20);

          // Defeated army retreats or gets wiped
          if (getTotalTroopCount(defeatedArmy) <= 100) {
            delete nextArmies[defeatedArmy.id];
          } else {
            defeatedArmy.status = 'idle';
            defeatedArmy.morale = 25;
            // Retreat to adjacent friendly or neighbor province
            const currentProv = nextProvinces[defeatedArmy.provinceId];
            if (currentProv && currentProv.neighborIds.length > 0) {
              defeatedArmy.provinceId = currentProv.neighborIds[0];
            }
          }

          if (battle.attackerNationId === prevState.playerNationId || battle.defenderNationId === prevState.playerNationId) {
            if (round.victorNationId === prevState.playerNationId) {
              soundManager.playVictoryFanfare();
            }
          }

          // Update war score
          const activeWar = nextWars.find(w =>
            (w.attackers.includes(battle.attackerNationId) && w.defenders.includes(battle.defenderNationId)) ||
            (w.defenders.includes(battle.attackerNationId) && w.attackers.includes(battle.defenderNationId))
          );
          if (activeWar) {
            const warDelta = round.victorNationId === activeWar.attackers[0] ? 15 : -15;
            activeWar.warScore = Math.max(-100, Math.min(100, activeWar.warScore + warDelta));
            activeWar.battlesCount = (activeWar.battlesCount || 0) + 1;
          }
        }
        return !battle.resolved;
      });

      // 3. Monthly Economy, Manpower, Tech, AI & Events
      if (monthChanged) {
        // Collect taxes, pay maintenance, recover manpower
        Object.values(nextNations).forEach(nation => {
          const ownProvs = Object.values(nextProvinces).filter(p => p.ownerNationId === nation.id);
          const taxSum = ownProvs.reduce((sum, p) => {
            const bldBonus = p.buildings.includes('market') ? 1.25 : 1.0;
            return sum + (p.taxBase * nation.taxRate * bldBonus);
          }, 0);

          const tradeSum = ownProvs.reduce((sum, p) => {
            return sum + (p.productionBase * 0.8);
          }, 0);

          // Army upkeep
          const ownArmiesList = Object.values(nextArmies).filter(a => a.nationId === nation.id);
          const troopTotal = ownArmiesList.reduce((sum, a) => sum + getTotalTroopCount(a), 0);
          const armyUpkeep = Math.round(troopTotal * 0.005);
          const loanInterest = nation.loans * 15;

          const totalMonthlyIncome = Math.round(taxSum + tradeSum);
          const totalMonthlyExpense = armyUpkeep + loanInterest + 10;
          const netIncome = totalMonthlyIncome - totalMonthlyExpense;

          nation.treasury = Math.max(0, nation.treasury + netIncome);

          // Manpower replenishment
          const monthlyManpower = Math.round(ownProvs.length * 120 + (nation.stability * 2));
          nation.manpower = Math.min(nation.maxManpower, nation.manpower + Math.max(50, monthlyManpower));

          // Tech points gain based on ruler admin and intellectuals loyalty
          const rulerBonus = nation.ruler ? nation.ruler.adminSkill * 3 : 10;
          nation.techPoints += 15 + rulerBonus;
          nation.diplomaticPoints = Math.min(100, nation.diplomaticPoints + (nation.ruler ? nation.ruler.diploSkill : 3));

          // Gradually recover army morale if idle
          ownArmiesList.forEach(a => {
            if (a.status === 'idle') {
              a.morale = Math.min(a.maxMorale, a.morale + 10);
            }
          });

          // Run AI for non-player nations
          if (!nation.isPlayer) {
            const aiResult = runNationAIMonthly(nation.id, {
              ...prevState,
              nations: nextNations,
              provinces: nextProvinces,
              armies: nextArmies,
              diplomacy: nextDiplomacy,
              wars: nextWars
            }, logNotification);

            if (aiResult.nations) Object.assign(nextNations, aiResult.nations);
            if (aiResult.provinces) Object.assign(nextProvinces, aiResult.provinces);
            if (aiResult.armies) Object.assign(nextArmies, aiResult.armies);
            if (aiResult.diplomacy) Object.assign(nextDiplomacy, aiResult.diplomacy);
            if (aiResult.wars) nextWars = aiResult.wars;
          }

          // Infamy monthly decay
          if (nation.infamy > 0) {
            nation.infamy = Math.max(0, nation.infamy - 0.5);
          }

          // Unrest check based on negative stability and war exhaustion
          if (nation.stability < 0 || (nation.warExhaustion || 0) > 10) {
            ownProvs.forEach(p => {
              p.unrest = Math.min(100, (p.unrest || 0) + (nation.stability < -20 ? 3 : 1));
            });
          }
        });

        // 4. Monthly Supply Attrition on Armies exceeding province supply limit or harsh terrain
        Object.values(nextArmies).forEach(army => {
          const prov = nextProvinces[army.provinceId];
          if (prov) {
            const attrition = calculateSupplyAttrition(army, prov);
            army.attritionRate = attrition;
            if (attrition > 0) {
              const totalTroops = getTotalTroopCount(army);
              const casualties = Math.round(totalTroops * (attrition / 100));
              if (casualties > 0) {
                applyCasualties(army, casualties);
              }
              army.morale = Math.max(10, army.morale - Math.round(attrition * 0.5));
            }
          }
        });

        // Trigger random event for player with 28% chance each month
        if (!nextActiveEvent && Math.random() < 0.28) {
          const eraEvents = ERA_SPECIFIC_EVENTS[prevState.currentEra] || [];
          const allPool = [...eraEvents, ...GAME_EVENTS];
          const randomEvt = allPool[Math.floor(Math.random() * allPool.length)];
          nextActiveEvent = randomEvt;
          soundManager.playParchment();
        }
      }

      return {
        ...prevState,
        currentDate: nextDate,
        nations: nextNations,
        provinces: nextProvinces,
        armies: nextArmies,
        diplomacy: nextDiplomacy,
        wars: nextWars,
        battles: nextBattles,
        activeEvent: nextActiveEvent,
        activeBattle: nextActiveBattle
      };
    });
  };

  // Helper date function
  function getMonthName(m: number): string {
    const names = ['янв.', 'февр.', 'март', 'апр.', 'май', 'июнь', 'июль', 'авг.', 'сент.', 'окт.', 'нояб.', 'дек.'];
    return names[m - 1] || 'янв.';
  }

  // --- Player Action Handlers ---
  const startNewGame = useCallback((nationId: string, eraId?: EraId) => {
    soundManager.playWarHorn();
    const effectiveEra = eraId || stateRef.current.currentEra || 'victorian_1836';
    const newState = createInitialState(nationId, effectiveEra);
    setState(newState);
  }, []);

  const selectScenario = useCallback((eraId: EraId) => {
    soundManager.playClick();
    const newState = createInitialState(undefined, eraId);
    setState(newState);
  }, []);

  const saveGame = useCallback(() => {
    try {
      localStorage.setItem('imperium_aeterna_save', JSON.stringify(stateRef.current));
      soundManager.playCoins();
      logNotification('Сохранение игры', 'Игра успешно сохранена в памяти браузера.', 'economy');
    } catch {
      // storage full or disabled
    }
  }, [logNotification]);

  const loadGame = useCallback((): boolean => {
    try {
      const data = localStorage.getItem('imperium_aeterna_save');
      if (data) {
        const parsed = JSON.parse(data) as GameState;
        setState(parsed);
        soundManager.playVictoryFanfare();
        return true;
      }
    } catch {
      // ignore
    }
    return false;
  }, []);

  const setSpeed = useCallback((speed: number) => {
    soundManager.playClick();
    setState(prev => ({
      ...prev,
      gameSpeed: speed,
      isPaused: speed === 0
    }));
  }, []);

  const togglePause = useCallback(() => {
    soundManager.playClick();
    setState(prev => ({
      ...prev,
      isPaused: !prev.isPaused
    }));
  }, []);

  const setMapMode = useCallback((mode: MapMode) => {
    soundManager.playClick();
    setState(prev => ({ ...prev, mapMode: mode }));
  }, []);

  const selectProvince = useCallback((id: string | null) => {
    soundManager.playClick();
    setState(prev => ({ ...prev, selectedProvinceId: id, selectedArmyId: null }));
  }, []);

  const selectArmy = useCallback((id: string | null) => {
    soundManager.playClick();
    setState(prev => ({ ...prev, selectedArmyId: id }));
  }, []);

  const moveArmy = useCallback((armyId: string, targetProvinceId: string) => {
    soundManager.playMarch();
    setState(prev => {
      const army = prev.armies[armyId];
      if (!army) return prev;
      return {
        ...prev,
        armies: {
          ...prev.armies,
          [armyId]: {
            ...army,
            targetProvinceId,
            path: [targetProvinceId],
            isMoving: true,
            status: 'moving',
            movementProgress: 0
          }
        }
      };
    });
  }, []);

  const recruitUnits = useCallback((provinceId: string, unitType: keyof UnitCounts, amount: number): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    const prov = s.provinces[provinceId];
    if (!player || !prov || prov.ownerNationId !== s.playerNationId) return false;

    const costs: Record<keyof UnitCounts, { gold: number, manpower: number }> = {
      infantry: { gold: 20, manpower: 1000 },
      cavalry: { gold: 45, manpower: 1000 },
      artillery: { gold: 60, manpower: 500 },
      siege: { gold: 75, manpower: 300 },
      elite: { gold: 90, manpower: 1000 }
    };

    const cost = costs[unitType];
    const totalGold = cost.gold * amount;
    const totalManpower = cost.manpower * amount;

    if (player.treasury < totalGold || player.manpower < totalManpower) {
      return false;
    }

    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= totalGold;
      updatedPlayer.manpower -= totalManpower;

      // Find existing army in province or create new one
      const existingArmy = Object.values(prev.armies).find(a => a.provinceId === provinceId && a.nationId === prev.playerNationId);
      const updatedArmies = { ...prev.armies };

      if (existingArmy) {
        existingArmy.units[unitType] += (unitType === 'infantry' || unitType === 'cavalry' || unitType === 'elite' ? 1000 : 50) * amount;
      } else {
        const newArmyId = `army_${prev.playerNationId}_${Date.now()}`;
        const newUnits: UnitCounts = { infantry: 0, cavalry: 0, artillery: 0, siege: 0, elite: 0 };
        newUnits[unitType] = (unitType === 'infantry' || unitType === 'cavalry' || unitType === 'elite' ? 1000 : 50) * amount;
        updatedArmies[newArmyId] = {
          id: newArmyId,
          name: `Полк провинции ${prov.name}`,
          nationId: prev.playerNationId,
          provinceId,
          path: [],
          movementProgress: 0,
          units: newUnits,
          morale: 85,
          maxMorale: 100,
          general: { name: 'Командующий гарнизона', attack: 3, defense: 3, maneuver: 2, moraleBuff: 5 },
          isMoving: false,
          status: 'idle'
        };
      }

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        armies: updatedArmies
      };
    });
    return true;
  }, []);

  const buildBuilding = useCallback((provinceId: string, buildingType: 'market' | 'workshop' | 'barracks' | 'fort' | 'academy'): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    const prov = s.provinces[provinceId];
    if (!player || !prov || prov.ownerNationId !== s.playerNationId) return false;
    if (prov.buildings.includes(buildingType)) return false;

    const costs: Record<string, number> = {
      market: 100,
      workshop: 130,
      barracks: 120,
      fort: 180,
      academy: 200
    };

    const goldCost = costs[buildingType];
    if (player.treasury < goldCost) return false;

    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= goldCost;
      const updatedProv = { ...prev.provinces[provinceId] };
      updatedProv.buildings = [...updatedProv.buildings, buildingType];
      if (buildingType === 'fort') updatedProv.fortLevel = Math.min(4, updatedProv.fortLevel + 1);
      if (buildingType === 'barracks') updatedProv.barracksLevel = Math.min(3, updatedProv.barracksLevel + 1);

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        provinces: { ...prev.provinces, [provinceId]: updatedProv }
      };
    });
    return true;
  }, []);

  const upgradeDevelopment = useCallback((provinceId: string): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    const prov = s.provinces[provinceId];
    if (!player || !prov || prov.ownerNationId !== s.playerNationId) return false;

    const cost = prov.developmentLevel * 40;
    if (player.treasury < cost) return false;

    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= cost;
      const updatedProv = { ...prev.provinces[provinceId] };
      updatedProv.developmentLevel = Math.min(10, updatedProv.developmentLevel + 1);
      updatedProv.taxBase += 4;
      updatedProv.productionBase += 3;
      updatedProv.population = Math.round(updatedProv.population * 1.15);

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        provinces: { ...prev.provinces, [provinceId]: updatedProv }
      };
    });
    return true;
  }, []);

  // --- Diplomacy Actions ---
  const declareWar = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    if (targetNationId === s.playerNationId) return false;
    soundManager.playWarHorn();

    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      if (!updatedDiplomacy[prev.playerNationId]) updatedDiplomacy[prev.playerNationId] = {};
      if (!updatedDiplomacy[targetNationId]) updatedDiplomacy[targetNationId] = {};

      updatedDiplomacy[prev.playerNationId][targetNationId] = {
        ...updatedDiplomacy[prev.playerNationId][targetNationId],
        isAtWar: true,
        isAllied: false,
        hasNonAggression: false,
        hasTradeAgreement: false,
        opinion: -100
      };

      updatedDiplomacy[targetNationId][prev.playerNationId] = {
        ...updatedDiplomacy[targetNationId][prev.playerNationId],
        isAtWar: true,
        isAllied: false,
        hasNonAggression: false,
        hasTradeAgreement: false,
        opinion: -100
      };

      const newWar: War = {
        id: `war_${prev.playerNationId}_${targetNationId}_${Date.now()}`,
        name: `Война за господство: ${prev.nations[prev.playerNationId]?.name} против ${prev.nations[targetNationId]?.name}`,
        attackers: [prev.playerNationId],
        defenders: [targetNationId],
        warGoal: 'Территориальная экспансия',
        warScore: 0,
        startDate: `${prev.currentDate.day} ${prev.currentDate.month} ${prev.currentDate.year}`,
        casualties: { [prev.playerNationId]: 0, [targetNationId]: 0 }
      };

      return {
        ...prev,
        diplomacy: updatedDiplomacy,
        wars: [...prev.wars, newWar]
      };
    });

    logNotification('Объявление войны!', `Ваша держава объявила войну государству ${s.nations[targetNationId]?.name}. Мобилизуйте полки!`, 'war');
    return true;
  }, [logNotification]);

  const proposePeace = useCallback((warId: string, demandedProvinceIds: string[]): boolean => {
    const s = stateRef.current;
    const war = s.wars.find(w => w.id === warId);
    if (!war) return false;

    const enemyId = war.attackers.includes(s.playerNationId) ? war.defenders[0] : war.attackers[0];
    soundManager.playVictoryFanfare();

    setState(prev => {
      // Transfer provinces
      const updatedProvinces = { ...prev.provinces };
      demandedProvinceIds.forEach(pid => {
        if (updatedProvinces[pid]) {
          updatedProvinces[pid] = {
            ...updatedProvinces[pid],
            ownerNationId: prev.playerNationId,
            occupiedBy: undefined,
            siegeProgress: 0
          };
        }
      });

      // Clear occupied status on all provinces
      Object.values(updatedProvinces).forEach(p => {
        p.occupiedBy = undefined;
        p.siegeProgress = 0;
      });

      // Update player infamy, claims, and war exhaustion
      const updatedNations = { ...prev.nations };
      const player = updatedNations[prev.playerNationId];
      if (player) {
        demandedProvinceIds.forEach(pid => {
          const hasClaim = player.claims.includes(pid);
          player.infamy = Math.min(100, player.infamy + (hasClaim ? 3 : 8));
          player.claims = player.claims.filter(id => id !== pid);
        });
        player.prestige += demandedProvinceIds.length * 5;
        player.warExhaustion = Math.max(0, player.warExhaustion - 5);
      }

      // Reset diplomatic war status
      const updatedDiplomacy = { ...prev.diplomacy };
      if (updatedDiplomacy[prev.playerNationId]?.[enemyId]) {
        updatedDiplomacy[prev.playerNationId][enemyId].isAtWar = false;
        updatedDiplomacy[prev.playerNationId][enemyId].truceDaysRemaining = 365;
      }
      if (updatedDiplomacy[enemyId]?.[prev.playerNationId]) {
        updatedDiplomacy[enemyId][prev.playerNationId].isAtWar = false;
        updatedDiplomacy[enemyId][prev.playerNationId].truceDaysRemaining = 365;
      }

      return {
        ...prev,
        provinces: updatedProvinces,
        diplomacy: updatedDiplomacy,
        wars: prev.wars.filter(w => w.id !== warId)
      };
    });

    logNotification('Мирный договор подписан', `Война завершена. Подписан мирный трактат. Присоединены провинции: ${demandedProvinceIds.length}`, 'peace');
    return true;
  }, [logNotification]);

  const formAlliance = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    const rel = s.diplomacy[s.playerNationId]?.[targetNationId];
    if (!rel || rel.opinion < 25) return false;

    soundManager.playVictoryFanfare();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      updatedDiplomacy[prev.playerNationId][targetNationId].isAllied = true;
      updatedDiplomacy[prev.playerNationId][targetNationId].hasNonAggression = true;
      updatedDiplomacy[targetNationId][prev.playerNationId].isAllied = true;
      updatedDiplomacy[targetNationId][prev.playerNationId].hasNonAggression = true;
      return { ...prev, diplomacy: updatedDiplomacy };
    });

    logNotification('Военный союз заключен', `Держава ${s.nations[targetNationId]?.name} приняла наше предложение о вечном военном союзе!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const signNonAggression = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    soundManager.playCoins();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      updatedDiplomacy[prev.playerNationId][targetNationId].hasNonAggression = true;
      updatedDiplomacy[targetNationId][prev.playerNationId].hasNonAggression = true;
      return { ...prev, diplomacy: updatedDiplomacy };
    });
    logNotification('Пакт о ненападении', `Заключен пакт о взаимном ненападении с державой ${s.nations[targetNationId]?.name}.`, 'diplomacy');
    return true;
  }, [logNotification]);

  const signTradeDeal = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    soundManager.playCoins();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      updatedDiplomacy[prev.playerNationId][targetNationId].hasTradeAgreement = true;
      updatedDiplomacy[targetNationId][prev.playerNationId].hasTradeAgreement = true;
      return { ...prev, diplomacy: updatedDiplomacy };
    });
    logNotification('Торговый договор', `Открыты торговые фактории и взаимные ярмарки с державой ${s.nations[targetNationId]?.name}.`, 'diplomacy');
    return true;
  }, [logNotification]);

  const improveRelations = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    if (player.treasury < 60) return false;

    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= 60;
      const updatedDiplomacy = { ...prev.diplomacy };
      const curOp = updatedDiplomacy[prev.playerNationId][targetNationId]?.opinion || 0;
      const newOp = Math.min(100, curOp + 25);
      updatedDiplomacy[prev.playerNationId][targetNationId].opinion = newOp;
      updatedDiplomacy[targetNationId][prev.playerNationId].opinion = newOp;

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        diplomacy: updatedDiplomacy
      };
    });
    logNotification('Посольство отправлено', `Дары доставлены ко двору ${s.nations[targetNationId]?.name}. Отношения улучшены на +25.`, 'diplomacy');
    return true;
  }, [logNotification]);

  const worsenRelations = useCallback((targetNationId: string): boolean => {
    soundManager.playClick();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      const curOp = updatedDiplomacy[prev.playerNationId][targetNationId]?.opinion || 0;
      const newOp = Math.max(-100, curOp - 30);
      updatedDiplomacy[prev.playerNationId][targetNationId].opinion = newOp;
      updatedDiplomacy[targetNationId][prev.playerNationId].opinion = newOp;
      return { ...prev, diplomacy: updatedDiplomacy };
    });
    return true;
  }, []);

  const imposeSanctions = useCallback((targetNationId: string): boolean => {
    soundManager.playClick();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      updatedDiplomacy[prev.playerNationId][targetNationId].hasSanctions = true;
      updatedDiplomacy[prev.playerNationId][targetNationId].hasTradeAgreement = false;
      return { ...prev, diplomacy: updatedDiplomacy };
    });
    return true;
  }, []);

  const createVassal = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    soundManager.playVictoryFanfare();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      updatedDiplomacy[prev.playerNationId][targetNationId].isVassal = true;
      return { ...prev, diplomacy: updatedDiplomacy };
    });
    logNotification('Вассалитет признан', `Держава ${s.nations[targetNationId]?.name} присягнула нам на верность как вассал!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const declareRival = useCallback((targetNationId: string): boolean => {
    soundManager.playWarHorn();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      const updatedDiplomacy = { ...prev.diplomacy };

      if (!updatedPlayer.rivalIds.includes(targetNationId)) {
        updatedPlayer.rivalIds = [...updatedPlayer.rivalIds, targetNationId];
      }
      updatedPlayer.prestige += 10;

      const rel = updatedDiplomacy[prev.playerNationId]?.[targetNationId];
      if (rel) {
        rel.isDeclaredRival = true;
        rel.attitude = 'rival';
        rel.attitudeReason = 'Объявлен официальным соперником (-60)';
        rel.opinion = Math.max(-100, rel.opinion - 60);
      }
      const revRel = updatedDiplomacy[targetNationId]?.[prev.playerNationId];
      if (revRel) {
        revRel.isDeclaredRival = true;
        revRel.attitude = 'rival';
        revRel.attitudeReason = 'Враждебный соперник (-60)';
        revRel.opinion = Math.max(-100, revRel.opinion - 60);
      }

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        diplomacy: updatedDiplomacy
      };
    });
    logNotification('Объявлен Соперник!', `Ваша держава провозгласила ${stateRef.current.nations[targetNationId]?.name} своим заклятым соперником!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const removeRival = useCallback((targetNationId: string): boolean => {
    soundManager.playClick();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      const updatedDiplomacy = { ...prev.diplomacy };
      updatedPlayer.rivalIds = updatedPlayer.rivalIds.filter(id => id !== targetNationId);

      const rel = updatedDiplomacy[prev.playerNationId]?.[targetNationId];
      if (rel) {
        rel.isDeclaredRival = false;
        rel.attitude = 'neutral';
        rel.attitudeReason = 'Нейтральный прагматизм';
      }

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        diplomacy: updatedDiplomacy
      };
    });
    return true;
  }, []);

  const sendGift = useCallback((targetNationId: string, amount: number): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    if (!player || player.treasury < amount) return false;

    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= amount;

      const updatedDiplomacy = { ...prev.diplomacy };
      const bonus = Math.round(amount / 5);
      const rel = updatedDiplomacy[prev.playerNationId]?.[targetNationId];
      if (rel) {
        rel.opinion = Math.min(100, rel.opinion + bonus);
        if (rel.opinion >= 30) {
          rel.attitude = 'friendly';
          rel.attitudeReason = `Щедрый дипломатический дар (+${bonus})`;
        }
      }
      const revRel = updatedDiplomacy[targetNationId]?.[prev.playerNationId];
      if (revRel) {
        revRel.opinion = Math.min(100, revRel.opinion + bonus);
        if (revRel.opinion >= 30) {
          revRel.attitude = 'friendly';
          revRel.attitudeReason = `Щедрый дипломатический дар (+${bonus})`;
        }
      }

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        diplomacy: updatedDiplomacy
      };
    });
    logNotification('Дипломатический Дар', `Отправлен подарок в ${amount} золота ко двору ${s.nations[targetNationId]?.name}. Отношения значительно улучшились!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const fabricateClaim = useCallback((targetProvinceId: string): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    const prov = s.provinces[targetProvinceId];
    if (!player || !prov || player.diplomaticPoints < 40 || player.claims.includes(targetProvinceId)) return false;

    soundManager.playMarch();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.diplomaticPoints -= 40;
      updatedPlayer.claims = [...updatedPlayer.claims, targetProvinceId];

      const updatedProvinces = { ...prev.provinces };
      const p = updatedProvinces[targetProvinceId];
      if (p) {
        p.claimsBy = [...(p.claimsBy || []), prev.playerNationId];
      }

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer },
        provinces: updatedProvinces
      };
    });
    logNotification('Претензия сфабрикована', `Дипломаты подготовили историческое обоснование (Casus Belli) на провинцию ${prov.name}!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const guaranteeIndependence = useCallback((targetNationId: string): boolean => {
    soundManager.playClick();
    setState(prev => {
      const updatedDiplomacy = { ...prev.diplomacy };
      const rel = updatedDiplomacy[prev.playerNationId]?.[targetNationId];
      if (rel) {
        rel.guaranteeIndependence = !rel.guaranteeIndependence;
        rel.opinion = Math.min(100, rel.opinion + (rel.guaranteeIndependence ? 30 : -20));
        rel.attitude = rel.guaranteeIndependence ? 'friendly' : 'neutral';
        rel.attitudeReason = rel.guaranteeIndependence ? 'Гарантия военной защиты (+30)' : 'Снятие гарантий';
      }
      return { ...prev, diplomacy: updatedDiplomacy };
    });
    logNotification('Гарантия Независимости', `Вы гарантировали суверенитет державы ${stateRef.current.nations[targetNationId]?.name}!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const sendMilitaryAid = useCallback((targetNationId: string): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    if (!player || player.treasury < 150) return false;

    soundManager.playMarch();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= 150;

      const updatedNations = { ...prev.nations, [prev.playerNationId]: updatedPlayer };
      const targetNat = updatedNations[targetNationId];
      if (targetNat) {
        targetNat.manpower = Math.min(targetNat.maxManpower, targetNat.manpower + 5000);
      }

      const updatedDiplomacy = { ...prev.diplomacy };
      const rel = updatedDiplomacy[prev.playerNationId]?.[targetNationId];
      if (rel) {
        rel.militaryAidSent = true;
        rel.opinion = Math.min(100, rel.opinion + 40);
        rel.attitude = 'allied';
        rel.attitudeReason = 'Военные поставки и ленд-лиз (+40)';
      }

      return {
        ...prev,
        nations: updatedNations,
        diplomacy: updatedDiplomacy
      };
    });
    logNotification('Военная помощь направлена', `Эшелоны с вооружением и боеприпасами доставлены в ${s.nations[targetNationId]?.name}!`, 'diplomacy');
    return true;
  }, [logNotification]);

  const switchPlayerNation = useCallback((nationId: string) => {
    soundManager.playWarHorn();
    setState(prev => {
      const nextNations = { ...prev.nations };
      if (nextNations[prev.playerNationId]) {
        nextNations[prev.playerNationId].isPlayer = false;
      }
      if (nextNations[nationId]) {
        nextNations[nationId].isPlayer = true;
      }
      return {
        ...prev,
        playerNationId: nationId,
        selectedProvinceId: nextNations[nationId]?.capitalProvinceId || prev.selectedProvinceId,
        selectedArmyId: null
      };
    });
    const nat = stateRef.current.nations[nationId];
    logNotification('Смена Державы', `Вы взяли под личный контроль державу: ${nat?.name || nationId}!`, 'diplomacy');
  }, [logNotification]);

  // --- Tech Research ---
  const startTechResearch = useCallback((techId: string): boolean => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    const tech = s.technologies[techId];
    if (!player || !tech || player.researchedTechs.includes(techId)) return false;
    if (player.techPoints < tech.cost) return false;

    soundManager.playVictoryFanfare();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.techPoints -= tech.cost;
      updatedPlayer.researchedTechs = [...updatedPlayer.researchedTechs, techId];

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer }
      };
    });

    logNotification('Технология изучена!', `Внедрено открытие: ${tech.name}. ${tech.effects}`, 'tech');
    return true;
  }, [logNotification]);

  // --- Event Modal Choices ---
  const handleEventOption = useCallback((actionId: string) => {
    soundManager.playClick();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };

      if (actionId === 'crisis_raise_taxes') {
        updatedPlayer.treasury += 150;
        updatedPlayer.stability = Math.max(-100, updatedPlayer.stability - 15);
      } else if (actionId === 'crisis_cut_expenses') {
        updatedPlayer.treasury += 80;
      } else if (actionId === 'crisis_take_loan') {
        updatedPlayer.treasury += 300;
        updatedPlayer.loans += 1;
      } else if (actionId === 'harvest_export') {
        updatedPlayer.treasury += 220;
        updatedPlayer.diplomaticPoints = Math.min(100, updatedPlayer.diplomaticPoints + 10);
      } else if (actionId === 'harvest_welfare') {
        updatedPlayer.stability = Math.min(100, updatedPlayer.stability + 20);
        updatedPlayer.manpower = Math.min(updatedPlayer.maxManpower, updatedPlayer.manpower + 500);
      } else if (actionId === 'harvest_military') {
        updatedPlayer.manpower = Math.min(updatedPlayer.maxManpower, updatedPlayer.manpower + 1500);
      } else if (actionId === 'revolt_crush') {
        updatedPlayer.manpower = Math.max(0, updatedPlayer.manpower - 300);
        updatedPlayer.stability = Math.max(-100, updatedPlayer.stability - 10);
      } else if (actionId === 'revolt_appease') {
        updatedPlayer.treasury = Math.max(0, updatedPlayer.treasury - 50);
        updatedPlayer.stability = Math.min(100, updatedPlayer.stability + 15);
      } else if (actionId === 'general_hire') {
        updatedPlayer.treasury = Math.max(0, updatedPlayer.treasury - 80);
      } else if (actionId === 'general_doctrine') {
        updatedPlayer.techPoints += 100;
      } else if (actionId === 'monopoly_grant') {
        updatedPlayer.treasury += 250;
      } else if (actionId === 'plague_quarantine') {
        updatedPlayer.treasury = Math.max(0, updatedPlayer.treasury - 100);
      } else if (actionId === 'plot_purge') {
        updatedPlayer.treasury += 200;
        updatedPlayer.prestige = Math.min(100, updatedPlayer.prestige + 15);
      } else if (actionId === 'science_military') {
        updatedPlayer.techPoints += 150;
      } else if (actionId === 'science_publish') {
        updatedPlayer.treasury = Math.max(0, updatedPlayer.treasury - 70);
        updatedPlayer.techPoints += 200;
      }

      return {
        ...prev,
        activeEvent: null,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer }
      };
    });
  }, []);

  // --- Estates Interaction ---
  const interactEstate = useCallback((estateId: string, action: 'grant_privilege' | 'curtail_power' | 'subsidize') => {
    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      const estate = updatedPlayer.estates.find(e => e.id === estateId);
      if (!estate) return prev;

      if (action === 'grant_privilege') {
        estate.loyalty = Math.min(100, estate.loyalty + 20);
        estate.influence = Math.min(100, estate.influence + 15);
        updatedPlayer.stability = Math.min(100, updatedPlayer.stability + 5);
      } else if (action === 'curtail_power') {
        estate.loyalty = Math.max(0, estate.loyalty - 25);
        estate.influence = Math.max(10, estate.influence - 20);
        updatedPlayer.prestige += 5;
      } else if (action === 'subsidize') {
        if (updatedPlayer.treasury >= 100) {
          updatedPlayer.treasury -= 100;
          estate.loyalty = Math.min(100, estate.loyalty + 15);
        }
      }

      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer }
      };
    });
  }, []);

  // --- Financial Actions ---
  const takeLoan = useCallback(() => {
    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury += 250;
      updatedPlayer.loans += 1;
      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer }
      };
    });
  }, []);

  const repayLoan = useCallback(() => {
    const s = stateRef.current;
    const player = s.nations[s.playerNationId];
    if (player.loans <= 0 || player.treasury < 265) return;

    soundManager.playCoins();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      updatedPlayer.treasury -= 265;
      updatedPlayer.loans -= 1;
      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer }
      };
    });
  }, []);

  const adjustTaxRate = useCallback((delta: number) => {
    soundManager.playClick();
    setState(prev => {
      const updatedPlayer = { ...prev.nations[prev.playerNationId] };
      const nextRate = Math.max(0.5, Math.min(1.5, Number((updatedPlayer.taxRate + delta).toFixed(1))));
      updatedPlayer.taxRate = nextRate;
      return {
        ...prev,
        nations: { ...prev.nations, [prev.playerNationId]: updatedPlayer }
      };
    });
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      notifications: prev.notifications.filter(n => n.id !== id)
    }));
  }, []);

  const closeActiveBattleModal = useCallback(() => {
    setState(prev => ({ ...prev, activeBattle: null }));
  }, []);

  const toggleAudio = useCallback(() => {
    soundManager.enabled = !soundManager.enabled;
    setState(prev => ({ ...prev, audioEnabled: soundManager.enabled }));
  }, []);

  return (
    <GameContext.Provider
      value={{
        state,
        startNewGame,
        selectScenario,
        loadGame,
        saveGame,
        setSpeed,
        togglePause,
        setMapMode,
        selectProvince,
        selectArmy,
        moveArmy,
        recruitUnits,
        buildBuilding,
        upgradeDevelopment,
        declareWar,
        proposePeace,
        formAlliance,
        signNonAggression,
        signTradeDeal,
        improveRelations,
        worsenRelations,
        imposeSanctions,
        createVassal,
        declareRival,
        removeRival,
        sendGift,
        fabricateClaim,
        guaranteeIndependence,
        sendMilitaryAid,
        switchPlayerNation,
        startTechResearch,
        handleEventOption,
        interactEstate,
        takeLoan,
        repayLoan,
        adjustTaxRate,
        dismissNotification,
        closeActiveBattleModal,
        toggleAudio
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};
