import { Send } from "lucide-react";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import type { ChatTurn, ToolCallTrace } from "@/lib/ai/api";
import { cn } from "@/lib/cn";

export function ChatPane({
  messages,
  traces,
  busy,
  error,
  onSend,
  placeholder,
}: {
  messages: ChatTurn[];
  traces?: ToolCallTrace[];
  busy?: boolean;
  error?: string | null;
  onSend: (text: string) => void;
  placeholder?: string;
}) {
  const [text, setText] = useState("");
  const scroller = useRef<HTMLDivElement>(null);

  return (
    <div className="flex min-h-[420px] flex-col overflow-hidden rounded-xl bg-card shadow-border">
      <div ref={scroller} className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4">
        {messages.length === 0 ? (
          <p className="text-sm text-muted">Диалог ещё пуст. Напиши первую реплику.</p>
        ) : null}
        {messages.map((m, i) => (
          <div
            key={`${m.role}-${i}`}
            className={cn(
              "max-w-[92%] rounded-lg px-3 py-2 text-sm leading-relaxed whitespace-pre-wrap",
              m.role === "user" ? "ml-auto bg-ink text-paper" : "bg-paper-2 text-ink",
            )}
          >
            {m.content}
          </div>
        ))}
        {traces && traces.length > 0 ? (
          <div className="rounded-lg bg-chalk p-3 font-mono text-xs text-dust">
            {traces.map((t, i) => (
              <div key={`${t.name}-${i}`} className="mb-2 last:mb-0">
                <p className="text-dust-2">{t.name}({t.args})</p>
                <p className="mt-1 text-paper">{t.result}</p>
              </div>
            ))}
          </div>
        ) : null}
        {busy ? <p className="text-sm text-muted">Модель отвечает…</p> : null}
        {error ? <p className="text-sm text-danger">{error}</p> : null}
      </div>
      <form
        className="border-t border-rule p-3"
        onSubmit={(e) => {
          e.preventDefault();
          const v = text.trim();
          if (!v) return;
          setText("");
          onSend(v);
        }}
      >
        <div className="flex gap-2">
          <Textarea
            value={text}
            rows={2}
            className="min-h-11 resize-none"
            placeholder={placeholder ?? "Реплика"}
            onChange={(e) => setText(e.target.value.slice(0, 1200))}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                const v = text.trim();
                if (!v) return;
                setText("");
                onSend(v);
              }
            }}
          />
          <Button type="submit" size="icon" disabled={busy || !text.trim()} aria-label="Отправить">
            <Send className="size-4" />
          </Button>
        </div>
      </form>
    </div>
  );
}
