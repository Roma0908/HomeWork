import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/cn";

function tokenize(s: string): string[] {
  return s.match(/[A-Za-zА-Яа-яЁё]+|[0-9]+|[^\s]/g) ?? [];
}

export function TokenWidget() {
  const [text, setText] = useState("Кафедра учит агентов.");
  const tokens = useMemo(() => tokenize(text), [text]);
  return (
    <div className="my-6 rounded-xl bg-card p-4 shadow-border">
      <p className="text-xs font-medium tracking-wide text-muted">Разбор на токены — учебный, не промышленный BPE</p>
      <Input
        className="mt-3"
        value={text}
        onChange={(e) => setText(e.target.value.slice(0, 120))}
        aria-label="Фраза для разбора"
      />
      <div className="mt-3 flex flex-wrap gap-1.5">
        {tokens.map((t, i) => (
          <span
            key={`${t}-${i}`}
            className="rounded-md bg-paper-2 px-2 py-1 font-mono text-xs text-ink"
          >
            {t}
          </span>
        ))}
      </div>
      <p className="mt-3 font-mono text-xs tabular-nums text-muted">{tokens.length} кусков</p>
    </div>
  );
}

export function TemperatureWidget() {
  const [t, setT] = useState(0.3);
  const samples = t < 0.35 ? ["точный", "сухой", "повторяемый"] : t < 0.75 ? ["живой", "с вариантами", "ещё устойчивый"] : ["размашистый", "непредсказуемый", "легко врёт"];
  return (
    <div className="my-6 rounded-xl bg-card p-4 shadow-border">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-xs font-medium tracking-wide text-muted">Температура</p>
        <p className="font-mono text-sm tabular-nums text-ink">{t.toFixed(1)}</p>
      </div>
      <input
        type="range"
        min={0}
        max={1.2}
        step={0.1}
        value={t}
        onChange={(e) => setT(Number(e.target.value))}
        className="mt-3 h-11 w-full accent-forest"
        aria-label="Температура"
      />
      <div className="mt-2 flex flex-wrap gap-1.5">
        {samples.map((s) => (
          <span key={s} className="rounded-full bg-paper-2 px-2.5 py-1 text-xs text-ink-soft">
            {s}
          </span>
        ))}
      </div>
      <p className="mt-3 text-sm leading-relaxed text-muted">
        Для бота-репетитора обычно 0.2–0.4. Для свободного персонажа — выше. Для агента с инструментами — снова низко.
      </p>
    </div>
  );
}

export function RolesWidget() {
  const rows = [
    { role: "system", who: "Инженер", sample: "Ты репетитор 7 класса. До 5 предложений. Не выдумывай." },
    { role: "user", who: "Человек", sample: "Что такое дробь?" },
    { role: "assistant", who: "Модель", sample: "Дробь — это часть целого. Пример: 1/2 яблока." },
  ];
  const [on, setOn] = useState(0);
  return (
    <div className="my-6 overflow-hidden rounded-xl bg-card shadow-border">
      <div className="flex border-b border-rule">
        {rows.map((r, i) => (
          <button
            key={r.role}
            type="button"
            onClick={() => setOn(i)}
            className={cn(
              "h-11 flex-1 px-2 text-sm font-medium transition-colors duration-150",
              on === i ? "bg-paper text-ink" : "bg-transparent text-muted hover:text-ink",
            )}
          >
            {r.role}
          </button>
        ))}
      </div>
      <div className="p-4">
        <p className="text-xs font-medium tracking-wide text-muted">{rows[on].who}</p>
        <p className="mt-2 font-mono text-sm leading-relaxed text-ink">{rows[on].sample}</p>
      </div>
    </div>
  );
}

export function QuizBlock({
  id,
  question,
  options,
  correct,
  explain,
  passed,
  onPass,
}: {
  id: string;
  question: string;
  options: string[];
  correct: number;
  explain: string;
  passed?: boolean;
  onPass: (id: string, ok: boolean) => void;
}) {
  const [pick, setPick] = useState<number | null>(passed ? correct : null);
  const [checked, setChecked] = useState(Boolean(passed));
  const ok = pick === correct;
  return (
    <div className="my-8 rounded-xl bg-card p-5 shadow-border">
      <p className="text-xs font-medium tracking-wide text-muted">Проверка</p>
      <p className="mt-2 font-display text-lg font-medium leading-snug text-ink">{question}</p>
      <div className="mt-4 grid gap-2">
        {options.map((opt, i) => {
          const selected = pick === i;
          const show = checked && selected;
          return (
            <button
              key={opt}
              type="button"
              onClick={() => {
                setPick(i);
                setChecked(false);
              }}
              className={cn(
                "min-h-11 rounded-lg px-3 py-2.5 text-left text-sm leading-snug transition-[background-color,box-shadow] duration-150",
                selected ? "bg-paper-2 shadow-border" : "bg-paper hover:bg-paper-2",
                show && ok && "bg-ok/10",
                show && !ok && "bg-danger/10",
              )}
            >
              {opt}
            </button>
          );
        })}
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <Button
          size="sm"
          disabled={pick === null}
          onClick={() => {
            if (pick === null) return;
            setChecked(true);
            onPass(id, pick === correct);
          }}
        >
          Проверить
        </Button>
        {checked ? (
          <p className={cn("text-sm", ok ? "text-ok" : "text-danger")}>
            {ok ? "Верно." : "Не то. Прочитай пояснение и попробуй ещё."}
          </p>
        ) : null}
      </div>
      {checked ? <p className="mt-3 text-sm leading-relaxed text-muted">{explain}</p> : null}
    </div>
  );
}
