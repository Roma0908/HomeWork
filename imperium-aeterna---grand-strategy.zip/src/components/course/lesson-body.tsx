import { Link } from "@tanstack/react-router";
import { ArrowUpRight, FlaskConical, Info, Lightbulb, TriangleAlert } from "lucide-react";
import { LoopDiagram, RagDiagram, StackDiagram } from "@/components/course/diagrams";
import { QuizBlock, RolesWidget, TemperatureWidget, TokenWidget } from "@/components/course/widgets";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/cn";
import type { Lesson, LessonBlock } from "@/lib/course/types";
import { useProgress } from "@/lib/course/progress";

function Callout({
  tone,
  title,
  text,
}: {
  tone: "note" | "tip" | "warn";
  title: string;
  text: string;
}) {
  const Icon = tone === "warn" ? TriangleAlert : tone === "tip" ? Lightbulb : Info;
  return (
    <aside
      className={cn(
        "my-6 rounded-xl p-4 shadow-border",
        tone === "warn" ? "bg-danger/5" : tone === "tip" ? "bg-forest/5" : "bg-card",
      )}
    >
      <div className="flex items-center gap-2 text-ink">
        <Icon className="size-4 shrink-0" strokeWidth={1.75} />
        <p className="text-sm font-medium">{title}</p>
      </div>
      <p className="mt-2 text-sm leading-relaxed text-ink-soft">{text}</p>
    </aside>
  );
}

function BlockView({ block }: { block: LessonBlock }) {
  const markQuiz = useProgress((s) => s.markQuiz);
  const quizzes = useProgress((s) => s.quizzes);

  switch (block.type) {
    case "p":
      return <p className="my-4 font-display text-base leading-relaxed text-ink-soft sm:text-lg">{block.text}</p>;
    case "h":
      return <h2 className="mt-10 mb-3 text-xl font-medium text-ink">{block.text}</h2>;
    case "callout":
      return <Callout tone={block.tone} title={block.title} text={block.text} />;
    case "code":
      return (
        <figure className="my-6 overflow-hidden rounded-xl bg-chalk shadow-chalk">
          {block.title ? (
            <figcaption className="border-b border-dust/10 px-4 py-2 font-mono text-xs text-dust-2">
              {block.title}
            </figcaption>
          ) : null}
          <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-dust">
            <code>{block.code}</code>
          </pre>
        </figure>
      );
    case "compare":
      return (
        <div className="my-6 grid gap-3 sm:grid-cols-2">
          {[block.left, block.right].map((col) => (
            <div key={col.title} className="rounded-xl bg-card p-4 shadow-border">
              <p className="text-sm font-medium text-ink">{col.title}</p>
              <ul className="mt-3 space-y-2">
                {col.items.map((item) => (
                  <li key={item} className="text-sm leading-relaxed text-muted">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      );
    case "steps":
      return (
        <ol className="my-6 space-y-3">
          {block.items.map((item, i) => (
            <li key={item.title} className="flex gap-3 rounded-xl bg-card p-4 shadow-border">
              <span className="font-mono text-xs tabular-nums text-faint">{String(i + 1).padStart(2, "0")}</span>
              <div>
                <p className="font-medium text-ink">{item.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted">{item.text}</p>
              </div>
            </li>
          ))}
        </ol>
      );
    case "list":
      return (
        <ul className="my-4 space-y-2">
          {block.items.map((item) => (
            <li key={item} className="flex gap-3 text-sm leading-relaxed text-ink-soft sm:text-base">
              <span className="mt-2 size-1.5 shrink-0 rounded-full bg-forest" />
              {item}
            </li>
          ))}
        </ul>
      );
    case "diagram":
      if (block.kind === "stack") return <StackDiagram />;
      if (block.kind === "loop") return <LoopDiagram />;
      return <RagDiagram />;
    case "quiz":
      return (
        <QuizBlock
          id={block.id}
          question={block.question}
          options={block.options}
          correct={block.correct}
          explain={block.explain}
          passed={quizzes[block.id]}
          onPass={markQuiz}
        />
      );
    case "lab":
      return (
        <Link
          to="/lab/$labId"
          params={{ labId: block.labId }}
          className="my-6 flex items-start gap-3 rounded-xl bg-chalk p-4 text-dust shadow-chalk transition-colors duration-150 hover:bg-chalk-2"
        >
          <FlaskConical className="mt-0.5 size-4 shrink-0 text-dust-2" strokeWidth={1.75} />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-2 font-medium text-paper">
              {block.label}
              <ArrowUpRight className="size-4" />
            </p>
            <p className="mt-1 text-sm leading-relaxed text-dust-2">{block.hint}</p>
          </div>
        </Link>
      );
    case "widget":
      if (block.kind === "tokens") return <TokenWidget />;
      if (block.kind === "temperature") return <TemperatureWidget />;
      return <RolesWidget />;
    default:
      return null;
  }
}

export function LessonBody({ lesson }: { lesson: Lesson }) {
  return (
    <article className="mx-auto max-w-2xl">
      <p className="text-xs font-medium tracking-wide text-muted">
        Лекция {lesson.number} · {lesson.minutes} мин
      </p>
      <h1 className="mt-2 text-3xl font-medium tracking-tight text-ink sm:text-4xl">{lesson.title}</h1>
      <p className="mt-3 font-display text-lg leading-relaxed text-muted">{lesson.summary}</p>
      <div className="mt-4">
        <Badge variant="forest">{lesson.kicker}</Badge>
      </div>
      <div className="mt-8">
        {lesson.blocks.map((block, i) => (
          <BlockView key={i} block={block} />
        ))}
      </div>
    </article>
  );
}
