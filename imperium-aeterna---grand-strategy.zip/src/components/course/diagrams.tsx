import { ArrowDown, ArrowRight, BookOpen, Bot, Goal, PenLine, Search, Wrench } from "lucide-react";
import { cn } from "@/lib/cn";

function Floor({
  icon: Icon,
  title,
  text,
  className,
}: {
  icon: typeof Bot;
  title: string;
  text: string;
  className?: string;
}) {
  return (
    <div className={cn("flex gap-3 rounded-lg bg-chalk-2 p-3", className)}>
      <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-chalk-3 text-dust">
        <Icon className="size-4" strokeWidth={1.75} />
      </span>
      <div>
        <p className="font-medium text-paper">{title}</p>
        <p className="mt-0.5 text-sm leading-relaxed text-dust-2">{text}</p>
      </div>
    </div>
  );
}

export function StackDiagram() {
  return (
    <div className="my-6 grid gap-2 rounded-xl bg-chalk p-3">
      <Floor icon={Goal} title="Агент" text="Цель + цикл действий. Смотрит на результат и идёт дальше." />
      <div className="flex justify-center text-dust-2">
        <ArrowDown className="size-4" />
      </div>
      <Floor icon={Wrench} title="Ассистент" text="Диалог + инструменты. Человек ставит очередной запрос." />
      <div className="flex justify-center text-dust-2">
        <ArrowDown className="size-4" />
      </div>
      <Floor icon={Bot} title="Бот" text="Только разговор. Характер и правила, без рук в мире." />
    </div>
  );
}

export function LoopDiagram() {
  const steps = [
    { t: "Цель", d: "Что должно получиться" },
    { t: "Мысль", d: "Какой шаг сейчас" },
    { t: "Действие", d: "Вызов инструмента" },
    { t: "Наблюдение", d: "Факт от программы" },
  ];
  return (
    <div className="my-6 rounded-xl bg-chalk p-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {steps.map((s, i) => (
          <div key={s.t} className="rounded-lg bg-chalk-2 p-3">
            <p className="font-mono text-xs text-dust-2">{String(i + 1).padStart(2, "0")}</p>
            <p className="mt-1 font-medium text-paper">{s.t}</p>
            <p className="mt-0.5 text-sm text-dust-2">{s.d}</p>
          </div>
        ))}
      </div>
      <p className="mt-3 text-center text-sm text-dust-2">
        Пока нет стопа: цель закрыта, лимит шагов, ошибка или вопрос человеку.
      </p>
    </div>
  );
}

export function RagDiagram() {
  const cells = [
    { icon: Search, t: "Запрос", d: "Вопрос человека" },
    { icon: BookOpen, t: "Поиск", d: "Куски из вашей базы" },
    { icon: PenLine, t: "Промпт", d: "Устав + фрагменты" },
    { icon: Bot, t: "Ответ", d: "Только по источникам" },
  ];
  return (
    <div className="my-6 flex flex-col gap-2 rounded-xl bg-chalk p-3 sm:flex-row sm:items-stretch">
      {cells.map((c, i) => (
        <div key={c.t} className="flex flex-1 items-center gap-2">
          <div className="flex-1 rounded-lg bg-chalk-2 p-3">
            <c.icon className="size-4 text-dust" strokeWidth={1.75} />
            <p className="mt-2 font-medium text-paper">{c.t}</p>
            <p className="text-sm text-dust-2">{c.d}</p>
          </div>
          {i < cells.length - 1 ? (
            <ArrowRight className="hidden size-4 shrink-0 text-dust-2 sm:block" />
          ) : null}
        </div>
      ))}
    </div>
  );
}
