import { MessageCircle, Send, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { chatLab, type ChatTurn } from "@/lib/ai/api";
import { cn } from "@/lib/cn";
import { useProgress } from "@/lib/course/progress";

const SYSTEM =
  "Ты заведующий кафедрой инженерии ИИ. Объясняй курс: боты, ассистенты, агенты, промпты, инструменты, RAG, цикл ReAct, безопасность. Короткие абзацы, один пример. Не пиши длинные трактаты.";

export function OfficeHours() {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatTurn[]>([
    {
      role: "assistant",
      content: "Приёмные часы. Спроси про лекцию, промпт или почему агент — это цикл, а не «умный чат».",
    },
  ]);
  const name = useProgress((s) => s.studentName);

  async function send() {
    const content = text.trim();
    if (!content || busy) return;
    setText("");
    setError(null);
    const next: ChatTurn[] = [...messages, { role: "user", content }];
    setMessages(next);
    setBusy(true);
    try {
      const res = await chatLab({
        data: {
          kind: "tutor",
          system: SYSTEM + (name ? ` Студента зовут ${name}.` : ""),
          messages: next.filter((m, i) => i > 0 || m.role === "user"),
          temperature: 0.3,
        },
      });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      setMessages([...next, { role: "assistant", content: res.text }]);
    } catch {
      setError("Связь с кафедрой не прошла. Попробуй ещё раз.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "pressable fixed right-4 bottom-4 z-40 flex h-12 items-center gap-2 rounded-full bg-ink px-4 text-sm font-medium text-paper shadow-border",
          open && "hidden",
        )}
      >
        <MessageCircle className="size-4" strokeWidth={1.75} />
        Приёмные
      </button>

      {open ? (
        <div className="fixed right-0 bottom-0 z-40 flex h-[min(560px,100dvh)] w-full flex-col bg-card shadow-border sm:right-4 sm:bottom-4 sm:w-[380px] sm:rounded-2xl">
          <div className="flex h-14 items-center justify-between border-b border-rule px-4">
            <div>
              <p className="font-display text-base">Приёмные часы</p>
              <p className="text-xs text-muted">Вопросы по курсу</p>
            </div>
            <Button variant="ghost" size="icon" aria-label="Закрыть" onClick={() => setOpen(false)}>
              <X className="size-4" />
            </Button>
          </div>
          <div className="min-h-0 flex-1 space-y-3 overflow-y-auto p-4">
            {messages.map((m, i) => (
              <div
                key={`${m.role}-${i}`}
                className={cn(
                  "max-w-[90%] rounded-lg px-3 py-2 text-sm leading-relaxed",
                  m.role === "user" ? "ml-auto bg-ink text-paper" : "bg-paper-2 text-ink",
                )}
              >
                {m.content}
              </div>
            ))}
            {busy ? <p className="text-sm text-muted">Думаю…</p> : null}
            {error ? <p className="text-sm text-danger">{error}</p> : null}
          </div>
          <form
            className="border-t border-rule p-3"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <div className="flex gap-2">
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value.slice(0, 800))}
                placeholder="Спросить преподавателя"
                className="min-h-11 resize-none"
                rows={2}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    void send();
                  }
                }}
              />
              <Button type="submit" size="icon" disabled={busy || !text.trim()} aria-label="Отправить">
                <Send className="size-4" />
              </Button>
            </div>
          </form>
        </div>
      ) : null}
    </>
  );
}
