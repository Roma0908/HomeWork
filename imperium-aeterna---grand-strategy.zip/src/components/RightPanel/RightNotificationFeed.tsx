import React from 'react';
import { useGame } from '../../context/GameContext';
import { Bell, Flame, Shield, DollarSign, BookOpen, AlertCircle, X } from 'lucide-react';

export const RightNotificationFeed: React.FC = () => {
  const { state, dismissNotification } = useGame();
  const { notifications, wars, playerNationId } = state;

  const activePlayerWars = wars.filter(
    w => w.attackers.includes(playerNationId) || w.defenders.includes(playerNationId)
  );

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'war': return <Flame className="w-3.5 h-3.5 text-rose-400" />;
      case 'peace': return <Shield className="w-3.5 h-3.5 text-emerald-400" />;
      case 'economy': return <DollarSign className="w-3.5 h-3.5 text-amber-400" />;
      case 'tech': return <BookOpen className="w-3.5 h-3.5 text-indigo-400" />;
      default: return <Bell className="w-3.5 h-3.5 text-sky-400" />;
    }
  };

  return (
    <div className="absolute top-16 right-4 w-72 pointer-events-none flex flex-col gap-2 z-20">
      {/* War Status Pill (if at war) */}
      {activePlayerWars.length > 0 && (
        <div className="bg-rose-950/90 border border-rose-700/80 rounded-lg p-2.5 shadow-xl pointer-events-auto backdrop-blur-md animate-pulse">
          <div className="flex items-center justify-between text-xs font-bold text-rose-200">
            <span className="flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-rose-400" /> Идет война!
            </span>
            <span className="font-mono-num text-[11px]">
              {activePlayerWars[0].warScore > 0 ? `+${activePlayerWars[0].warScore}%` : `${activePlayerWars[0].warScore}%`}
            </span>
          </div>
          <div className="text-[10px] text-rose-300/80 mt-1 truncate">
            {activePlayerWars[0].name}
          </div>
        </div>
      )}

      {/* Notifications list */}
      <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pointer-events-auto pr-1">
        {notifications.slice(0, 7).map(notif => (
          <div
            key={notif.id}
            className="bg-slate-950/90 border border-slate-800 hover:border-slate-700 p-2.5 rounded-lg shadow-xl text-xs backdrop-blur-md transition-all animate-in slide-in-from-right-3 duration-200"
          >
            <div className="flex items-start justify-between gap-1 mb-1">
              <div className="flex items-center gap-1.5 font-bold text-slate-100 text-[11px]">
                {getNotifIcon(notif.type)}
                <span>{notif.title}</span>
              </div>
              <button
                onClick={() => dismissNotification(notif.id)}
                className="text-slate-500 hover:text-slate-200 p-0.5"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">
              {notif.message}
            </p>
            <div className="text-[9px] text-slate-500 font-mono-num mt-1 text-right">
              {notif.date}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
