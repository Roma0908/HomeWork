import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, FlaskConical, GraduationCap, Menu, ScrollText, X } from "lucide-react";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import { OfficeHours } from "@/components/course/office-hours";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/cn";
import { LABS, LESSONS, TRACKS, lessonsFor } from "@/lib/course/curriculum";
import { useProgress } from "@/lib/course/progress";

function Seal({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex size-9 items-center justify-center rounded-full border border-dust/25 font-display text-sm text-dust",
        className,
      )}
      aria-hidden
    >
      К
    </span>
  );
}

function NavList({ onGo }: { onGo?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const completed = useProgress((s) => s.completed);
  const examScore = useProgress((s) => s.examScore);

  return (
    <nav className="flex flex-col gap-6">
      <div>
        <p className="px-3 text-[11px] font-medium tracking-[0.16em] text-dust-2 uppercase">Журнал</p>
        <ul className="mt-2">
          <li>
            <Link
              to="/"
              onClick={onGo}
              className={cn(
                "flex h-11 items-center gap-2 rounded-md px-3 text-sm",
                pathname === "/" ? "bg-chalk-3 text-paper" : "text-dust hover:bg-chalk-2",
              )}
            >
              <GraduationCap className="size-4" strokeWidth={1.75} />
              Двор кафедры
            </Link>
          </li>
          <li>
            <Link
              to="/glossary"
              onClick={onGo}
              className={cn(
                "flex h-11 items-center gap-2 rounded-md px-3 text-sm",
                pathname.startsWith("/glossary") ? "bg-chalk-3 text-paper" : "text-dust hover:bg-chalk-2",
              )}
            >
              <BookOpen className="size-4" strokeWidth={1.75} />
              Глоссарий
            </Link>
          </li>
          <li>
            <Link
              to="/exam"
              onClick={onGo}
              className={cn(
                "flex h-11 items-center gap-2 rounded-md px-3 text-sm",
                pathname.startsWith("/exam") ? "bg-chalk-3 text-paper" : "text-dust hover:bg-chalk-2",
              )}
            >
              <ScrollText className="size-4" strokeWidth={1.75} />
              Зачёт
              {examScore !== null ? (
                <span className="ml-auto font-mono text-xs tabular-nums text-dust-2">{examScore}/12</span>
              ) : null}
            </Link>
          </li>
        </ul>
      </div>

      {TRACKS.map((track) => (
        <div key={track.id}>
          <p className="px-3 text-[11px] font-medium tracking-[0.16em] text-dust-2 uppercase">
            {track.latin}
          </p>
          <ul className="mt-2">
            {lessonsFor(track.id).map((lesson) => {
              const href = `/lesson/${lesson.id}`;
              const active = pathname === href;
              const done = Boolean(completed[lesson.id]);
              return (
                <li key={lesson.id}>
                  <Link
                    to="/lesson/$lessonId"
                    params={{ lessonId: lesson.id }}
                    onClick={onGo}
                    className={cn(
                      "flex min-h-11 items-center gap-2 rounded-md px-3 py-2 text-sm",
                      active ? "bg-chalk-3 text-paper" : "text-dust hover:bg-chalk-2",
                    )}
                  >
                    <span className="w-6 font-mono text-[11px] tabular-nums text-dust-2">{lesson.number}</span>
                    <span className="min-w-0 flex-1 leading-snug">{lesson.title}</span>
                    {done ? <span className="size-1.5 shrink-0 rounded-full bg-dust-2" /> : null}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}

      <div>
        <p className="px-3 text-[11px] font-medium tracking-[0.16em] text-dust-2 uppercase">Лаборатории</p>
        <ul className="mt-2">
          {LABS.map((lab) => {
            const href = `/lab/${lab.id}`;
            const active = pathname === href;
            return (
              <li key={lab.id}>
                <Link
                  to="/lab/$labId"
                  params={{ labId: lab.id }}
                  onClick={onGo}
                  className={cn(
                    "flex h-11 items-center gap-2 rounded-md px-3 text-sm",
                    active ? "bg-chalk-3 text-paper" : "text-dust hover:bg-chalk-2",
                  )}
                >
                  <FlaskConical className="size-4" strokeWidth={1.75} />
                  {lab.title}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const completed = useProgress((s) => s.completed);
  const doneCount = useMemo(
    () => LESSONS.filter((l) => completed[l.id]).length,
    [completed],
  );
  const pct = Math.round((doneCount / LESSONS.length) * 100);

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:h-11 focus:w-auto focus:rounded-md focus:bg-ink focus:px-3 focus:py-2 focus:text-paper"
      >
        К содержанию
      </a>
      <div className="lg:flex">
        <aside className="chalk-grain hidden w-[280px] shrink-0 flex-col text-dust lg:flex">
          <div className="flex items-center gap-3 px-5 py-5">
            <Seal />
            <div>
              <p className="font-display text-lg leading-none text-paper">Кафедра</p>
              <p className="mt-1 text-[11px] tracking-wide text-dust-2">Инженерия ИИ</p>
            </div>
          </div>
          <div className="px-4 pb-3">
            <div className="flex items-center justify-between text-[11px] text-dust-2">
              <span>Семестр</span>
              <span className="font-mono tabular-nums">
                {doneCount}/{LESSONS.length}
              </span>
            </div>
            <Progress value={pct} className="mt-2 bg-chalk-3" />
          </div>
          <div className="flex-1 overflow-y-auto px-2 pb-8">
            <NavList />
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-rule bg-paper/90 px-4 backdrop-blur-sm lg:hidden">
            <Button
              variant="ghost"
              size="icon"
              aria-label={open ? "Закрыть меню" : "Открыть меню"}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </Button>
            <p className="font-display text-lg">Кафедра</p>
            <span className="ml-auto font-mono text-xs tabular-nums text-muted">
              {doneCount}/{LESSONS.length}
            </span>
          </header>

          {open ? (
            <div className="chalk-grain fixed inset-0 z-40 overflow-y-auto p-4 pt-16 lg:hidden">
              <NavList onGo={() => setOpen(false)} />
            </div>
          ) : null}

          <main id="content" className="paper-grain min-h-[calc(100dvh-56px)] px-4 py-8 pb-24 sm:px-8 lg:min-h-dvh lg:px-12 lg:py-12 lg:pb-24">
            {children}
          </main>
        </div>
      </div>
      <OfficeHours />
    </div>
  );
}
