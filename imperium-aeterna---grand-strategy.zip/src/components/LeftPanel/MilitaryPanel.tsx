import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { UnitCounts } from '../../types/game';
import { Shield, Swords, UserCheck, Flame, PlusCircle, ArrowRight } from 'lucide-react';
import { getTotalTroopCount, calculateArmyPower } from '../../utils/combat';

export const MilitaryPanel: React.FC = () => {
  const { state, selectArmy, recruitUnits, selectProvince } = useGame();
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const playerArmies = Object.values(state.armies).filter(a => a.nationId === state.playerNationId);
  const activeWars = state.wars.filter(
    w => w.attackers.includes(state.playerNationId) || w.defenders.includes(state.playerNationId)
  );

  const [selectedRecruitType, setSelectedRecruitType] = useState<keyof UnitCounts>('infantry');

  const unitTypeData: Record<keyof UnitCounts, { name: string; costGold: number; costManpower: number; desc: string }> = {
    infantry: { name: 'Линейная пехота (1,000)', costGold: 20, costManpower: 1000, desc: 'Костяк армии, держит строй и принимает удар' },
    cavalry: { name: 'Тяжелая кавалерия (1,000)', costGold: 45, costManpower: 1000, desc: 'Фланговые удары, преследование отступающих' },
    artillery: { name: 'Полевая артиллерия (50 пушек)', costGold: 60, costManpower: 500, desc: 'Огневая мощь из задней линии и поддержка осад' },
    siege: { name: 'Осадные машины (50)', costGold: 75, costManpower: 300, desc: 'Быстрое сокрушение каменных бастионов и стен' },
    elite: { name: 'Гвардейские полки (1,000)', costGold: 90, costManpower: 1000, desc: 'Отборные ветераны с высочайшим боевым духом' }
  };

  return (
    <div className="p-4 space-y-5 text-xs text-slate-300">
      {/* Active Wars Banner */}
      {activeWars.length > 0 && (
        <div className="bg-rose-950/50 border border-rose-800 rounded-lg p-3 space-y-2">
          <div className="font-bold text-rose-300 flex items-center gap-1.5 text-sm">
            <Flame className="w-4 h-4 text-rose-400" /> Активные военные конфликты ({activeWars.length})
          </div>
          {activeWars.map(war => {
            const isAttacker = war.attackers.includes(state.playerNationId);
            const enemyId = isAttacker ? war.defenders[0] : war.attackers[0];
            const enemy = state.nations[enemyId];

            return (
              <div key={war.id} className="bg-slate-900/80 p-2.5 rounded border border-rose-900/60 space-y-1.5 font-mono-num">
                <div className="flex justify-between items-center font-sans font-semibold text-slate-100">
                  <span>против {enemy?.name}</span>
                  <span className={`text-xs ${war.warScore >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    Счет войны: {war.warScore > 0 ? `+${war.warScore}%` : `${war.warScore}%`}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 flex justify-between">
                  <span>Цель: {war.warGoal}</span>
                  <span>Боев: {war.battlesCount || 0}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Recruitment Station */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2.5">
        <div className="font-bold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-1.5">
          <span className="flex items-center gap-1.5">
            <PlusCircle className="w-4 h-4 text-amber-400" /> Набор новых полков в столице
          </span>
          <span className="font-mono-num text-[11px] text-sky-400">
            Рекруты: {player.manpower.toLocaleString()}
          </span>
        </div>

        <div className="space-y-1.5">
          {(Object.keys(unitTypeData) as (keyof UnitCounts)[]).map(typeKey => {
            const info = unitTypeData[typeKey];
            const canAfford = player.treasury >= info.costGold && player.manpower >= info.costManpower;

            return (
              <div
                key={typeKey}
                className="bg-slate-950/60 p-2 rounded border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="font-medium text-slate-200">{info.name}</div>
                  <div className="text-[10px] text-slate-400">{info.desc}</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-right text-[10px] font-mono-num">
                    <span className="text-amber-400">{info.costGold} 🪙</span>
                    <span className="text-slate-400 block">{info.costManpower} 👤</span>
                  </div>
                  <button
                    onClick={() => recruitUnits(player.capitalProvinceId, typeKey, 1)}
                    disabled={!canAfford}
                    className="bg-amber-600/30 hover:bg-amber-600/50 border border-amber-600/60 disabled:opacity-30 text-amber-200 px-2.5 py-1 rounded font-semibold transition-colors"
                  >
                    Нанять
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Standing Armies List */}
      <div className="space-y-2">
        <div className="font-bold text-slate-100 flex items-center justify-between">
          <span>Регулярные корпуса державы ({playerArmies.length})</span>
        </div>

        {playerArmies.length === 0 ? (
          <div className="text-center py-6 text-slate-500">
            У вас нет действующих армий. Наймите полки в столице.
          </div>
        ) : (
          playerArmies.map(army => {
            const prov = state.provinces[army.provinceId];
            const totalTroops = getTotalTroopCount(army);
            const power = calculateArmyPower(army);

            return (
              <div
                key={army.id}
                onClick={() => {
                  selectArmy(army.id);
                  if (prov) selectProvince(prov.id);
                }}
                className={`p-3 rounded-lg border transition-all cursor-pointer space-y-2 ${state.selectedArmyId === army.id ? 'bg-amber-500/15 border-amber-400' : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/60'}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-100 text-xs">{army.name}</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <span>Дислокация: <strong className="text-amber-300">{prov?.name}</strong></span>
                      {army.isMoving && <span className="text-sky-400 font-bold">· Марш...</span>}
                      {army.status === 'besieging' && <span className="text-rose-400 font-bold">· Осада</span>}
                    </div>
                  </div>
                  <div className="text-right font-mono-num">
                    <div className="font-bold text-rose-400 text-sm">{totalTroops.toLocaleString()}</div>
                    <div className="text-[10px] text-slate-400">Мощь: {power}</div>
                  </div>
                </div>

                {/* Morale bar */}
                <div>
                  <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                    <span>Боевой дух:</span>
                    <span className="font-mono-num font-semibold text-slate-200">{army.morale}%</span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all"
                      style={{ width: `${army.morale}%` }}
                    />
                  </div>
                </div>

                {/* General & Breakdown */}
                <div className="flex justify-between items-center text-[10px] text-slate-400 border-t border-slate-800/60 pt-1.5">
                  <span className="flex items-center gap-1 text-slate-300">
                    <UserCheck className="w-3 h-3 text-amber-400" />
                    {army.general?.name || 'Без генерала'}
                  </span>
                  <span className="font-mono-num">
                    П:{army.units.infantry} К:{army.units.cavalry} А:{army.units.artillery}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
