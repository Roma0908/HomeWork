import React from 'react';
import { useGame } from '../../context/GameContext';
import { Crown, Shield, Coins, Hammer, Wheat, BookOpen, Users, AlertCircle } from 'lucide-react';

const ESTATE_ICONS: Record<string, React.FC<{ className?: string }>> = {
  nobility: Crown,
  military: Shield,
  merchants: Coins,
  workers: Hammer,
  peasants: Wheat,
  intellectuals: BookOpen
};

export const EstatesPanel: React.FC = () => {
  const { state, interactEstate } = useGame();
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  return (
    <div className="p-4 space-y-4 text-xs text-slate-300">
      <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800">
        <div className="flex items-center gap-2 font-bold text-slate-100 text-sm mb-1">
          <Users className="w-4 h-4 text-amber-400" />
          Внутренняя политика и сословия
        </div>
        <p className="text-slate-400 text-[11px] leading-relaxed">
          Балансируйте интересы социальных групп. Высокая лояльность дает бонусы державе, низкая лояльность грозит мятежами и падением стабильности.
        </p>
      </div>

      <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
        {player.estates.map(estate => {
          const Icon = ESTATE_ICONS[estate.id] || Users;

          return (
            <div
              key={estate.id}
              className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2.5"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded bg-slate-800 text-amber-400">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-100 text-xs">{estate.name}</span>
                    <div className="text-[10px] text-slate-400">Влияние: <strong className="font-mono-num text-slate-200">{estate.influence}%</strong></div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] text-slate-400">Лояльность</div>
                  <div className={`font-mono-num font-bold text-xs ${estate.loyalty >= 60 ? 'text-emerald-400' : estate.loyalty <= 35 ? 'text-rose-400' : 'text-amber-300'}`}>
                    {estate.loyalty}%
                  </div>
                </div>
              </div>

              {/* Progress bars */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Шкала лояльности:</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${estate.loyalty >= 60 ? 'bg-emerald-500' : estate.loyalty <= 35 ? 'bg-rose-500' : 'bg-amber-500'}`}
                    style={{ width: `${estate.loyalty}%` }}
                  />
                </div>
              </div>

              <div className="text-[11px] text-slate-400">
                <span className="text-slate-500 block text-[10px] uppercase">Требование:</span>
                {estate.demands}
              </div>

              <div className="bg-slate-950/60 p-2 rounded text-[11px] text-emerald-300 font-medium border border-slate-850">
                Бонус: {estate.bonus}
              </div>

              {/* Estate Action Buttons */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                <button
                  onClick={() => interactEstate(estate.id, 'grant_privilege')}
                  className="bg-slate-800 hover:bg-slate-700 p-1.5 rounded text-[10px] font-medium text-slate-200 transition-colors"
                  title="+20% лояльности, +15% влияния"
                >
                  Привилегия
                </button>
                <button
                  onClick={() => interactEstate(estate.id, 'subsidize')}
                  disabled={player.treasury < 100}
                  className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 p-1.5 rounded text-[10px] font-medium text-amber-300 transition-colors"
                  title="Выделить 100 золота (+15% лояльности)"
                >
                  Субсидия (100 🪙)
                </button>
                <button
                  onClick={() => interactEstate(estate.id, 'curtail_power')}
                  className="bg-slate-800 hover:bg-slate-700 p-1.5 rounded text-[10px] font-medium text-rose-300 transition-colors"
                  title="Урезать влияние (-20% влияния, -25% лояльности)"
                >
                  Ограничить
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
