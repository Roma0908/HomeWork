import React from 'react';
import { useGame } from '../../context/GameContext';
import { ResourceType } from '../../types/game';
import { Coins, TrendingUp, TrendingDown, Landmark, Scale, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { getTotalTroopCount } from '../../utils/combat';

const RESOURCE_INFO: Record<ResourceType, { name: string; unit: string; icon: string }> = {
  grain: { name: 'Зерно', unit: 'т.', icon: '🌾' },
  iron: { name: 'Железо', unit: 'слитков', icon: '⛏️' },
  coal: { name: 'Уголь', unit: 'мешков', icon: '⬛' },
  gold: { name: 'Золото', unit: 'фунтов', icon: '🪙' },
  tar: { name: 'Смола и деготь', unit: 'бочек', icon: '🛢️' },
  timber: { name: 'Древесина', unit: 'бревен', icon: '🪵' },
  stone: { name: 'Камень', unit: 'блоков', icon: '🧱' },
  horses: { name: 'Боевые кони', unit: 'голов', icon: '🐎' }
};

export const EconomyPanel: React.FC = () => {
  const { state, takeLoan, repayLoan, adjustTaxRate } = useGame();
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const ownProvinces = Object.values(state.provinces).filter(p => p.ownerNationId === state.playerNationId);
  const taxSum = ownProvinces.reduce((sum, p) => {
    const marketMult = p.buildings.includes('market') ? 1.25 : 1.0;
    return sum + (p.taxBase * player.taxRate * marketMult);
  }, 0);

  const tradeSum = ownProvinces.reduce((sum, p) => sum + (p.productionBase * 0.8), 0);

  const playerArmies = Object.values(state.armies).filter(a => a.nationId === state.playerNationId);
  const troopCount = playerArmies.reduce((sum, a) => sum + getTotalTroopCount(a), 0);
  const armyUpkeep = Math.round(troopCount * 0.005);
  const adminCost = 10 + (ownProvinces.length * 2);
  const loanInterest = player.loans * 15;

  const totalIncome = Math.round(taxSum + tradeSum);
  const totalExpense = Math.round(armyUpkeep + adminCost + loanInterest);
  const netBalance = totalIncome - totalExpense;

  return (
    <div className="p-4 space-y-5 text-xs text-slate-300">
      {/* Treasury Header Card */}
      <div className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 flex items-center justify-between">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400">Государственная Казна</div>
          <div className="text-xl font-bold font-mono-num text-amber-300 flex items-center gap-1.5 mt-0.5">
            <Coins className="w-5 h-5 text-amber-400" />
            {player.treasury.toLocaleString()} золотых
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] text-slate-400">Сальдо в месяц</div>
          <div className={`text-base font-bold font-mono-num flex items-center justify-end gap-1 ${netBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {netBalance >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            {netBalance >= 0 ? `+${netBalance}` : netBalance}
          </div>
        </div>
      </div>

      {/* Monthly Budget Breakdown */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-3">
        <div className="font-bold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-1.5">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <TrendingUp className="w-4 h-4" /> Доходы государства
          </span>
          <span className="font-mono-num text-emerald-300 font-bold">+{totalIncome}</span>
        </div>
        <div className="space-y-1.5 font-mono-num text-[11px]">
          <div className="flex justify-between">
            <span className="text-slate-400">Подушные и земельные налоги:</span>
            <span className="text-slate-200">+{Math.round(taxSum)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Торговля и ярмарочные пошлины:</span>
            <span className="text-slate-200">+{Math.round(tradeSum)}</span>
          </div>
        </div>

        <div className="font-bold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-1.5 pt-2">
          <span className="flex items-center gap-1.5 text-rose-400">
            <TrendingDown className="w-4 h-4" /> Расходы государства
          </span>
          <span className="font-mono-num text-rose-300 font-bold">-{totalExpense}</span>
        </div>
        <div className="space-y-1.5 font-mono-num text-[11px]">
          <div className="flex justify-between">
            <span className="text-slate-400">Содержание армии ({troopCount.toLocaleString()} воинов):</span>
            <span className="text-rose-300">-{armyUpkeep}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Администрация и провинции:</span>
            <span className="text-rose-300">-{adminCost}</span>
          </div>
          {player.loans > 0 && (
            <div className="flex justify-between">
              <span className="text-amber-400">Проценты по займам ({player.loans} займов):</span>
              <span className="text-rose-400">-{loanInterest}</span>
            </div>
          )}
        </div>
      </div>

      {/* Tax Rate Policy */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
        <div className="flex items-center justify-between">
          <span className="font-bold text-slate-200 flex items-center gap-1.5">
            <Scale className="w-4 h-4 text-sky-400" /> Налоговое бремя
          </span>
          <span className="font-mono-num text-amber-300 font-semibold">{Math.round(player.taxRate * 100)}%</span>
        </div>
        <div className="text-[11px] text-slate-400">
          Высокие налоги увеличивают казну, но повышают риск бунтов и снижают лояльность крестьян.
        </div>
        <div className="flex gap-2 pt-1">
          <button
            onClick={() => adjustTaxRate(-0.1)}
            className="flex-1 bg-slate-800 hover:bg-slate-700 py-1.5 rounded text-slate-200 font-medium transition-colors"
          >
            Снизить (-10%)
          </button>
          <button
            onClick={() => adjustTaxRate(0.1)}
            className="flex-1 bg-slate-800 hover:bg-slate-700 py-1.5 rounded text-slate-200 font-medium transition-colors"
          >
            Повысить (+10%)
          </button>
        </div>
      </div>

      {/* Loans & Banking */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
        <div className="flex items-center justify-between">
          <span className="font-bold text-slate-200 flex items-center gap-1.5">
            <Landmark className="w-4 h-4 text-amber-400" /> Банковские займы
          </span>
          <span className="font-mono-num text-slate-300">{player.loans} активных</span>
        </div>
        <div className="text-[11px] text-slate-400">
          Каждый заём даёт 250 золота сразу. Возврат: 265 золота (процент: 15 золота/мес).
        </div>
        <div className="flex gap-2 pt-1">
          <button
            onClick={takeLoan}
            className="flex-1 bg-amber-600/30 hover:bg-amber-600/50 border border-amber-600/60 py-1.5 rounded text-amber-200 font-semibold transition-colors"
          >
            Взять заём (+250)
          </button>
          <button
            onClick={repayLoan}
            disabled={player.loans === 0 || player.treasury < 265}
            className="flex-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 py-1.5 rounded text-slate-200 font-medium transition-colors"
          >
            Погасить (-265)
          </button>
        </div>
      </div>

      {/* Strategic Resources Stockpiles */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2.5">
        <div className="font-bold text-slate-200">Стратегические запасы сырья</div>
        <div className="grid grid-cols-2 gap-2 text-[11px] font-mono-num">
          {(Object.keys(player.resources) as ResourceType[]).map(res => (
            <div key={res} className="bg-slate-950/60 p-2 rounded border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300 flex items-center gap-1.5">
                <span>{RESOURCE_INFO[res].icon}</span>
                <span>{RESOURCE_INFO[res].name}</span>
              </span>
              <span className="font-bold text-slate-100">{player.resources[res]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
