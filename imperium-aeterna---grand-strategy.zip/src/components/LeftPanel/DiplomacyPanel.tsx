import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import {
  Compass,
  Swords,
  ShieldCheck,
  Handshake,
  DollarSign,
  Gift,
  Ban,
  Crown,
  Search,
  Flag,
  Flame,
  ShieldAlert,
  Send,
  UserCheck
} from 'lucide-react';
import { DiplomaticAttitude } from '../../types/game';

const ATTITUDE_LABELS: Record<DiplomaticAttitude, { label: string; color: string; bg: string }> = {
  nemesis: { label: 'Заклятый враг', color: 'text-red-400', bg: 'bg-red-950/60 border-red-800/80' },
  rival: { label: 'Соперник', color: 'text-amber-400', bg: 'bg-amber-950/60 border-amber-800/80' },
  hostile: { label: 'Враждебное', color: 'text-orange-400', bg: 'bg-orange-950/60 border-orange-800/80' },
  distrustful: { label: 'Недоверие', color: 'text-yellow-400', bg: 'bg-yellow-950/60 border-yellow-800/80' },
  neutral: { label: 'Нейтральное', color: 'text-slate-300', bg: 'bg-slate-900 border-slate-800' },
  friendly: { label: 'Дружественное', color: 'text-emerald-400', bg: 'bg-emerald-950/60 border-emerald-800/80' },
  allied: { label: 'Союзническое', color: 'text-sky-400', bg: 'bg-sky-950/60 border-sky-800/80' }
};

export const DiplomacyPanel: React.FC = () => {
  const {
    state,
    declareWar,
    formAlliance,
    signNonAggression,
    signTradeDeal,
    improveRelations,
    worsenRelations,
    imposeSanctions,
    createVassal,
    declareRival,
    removeRival,
    sendGift,
    guaranteeIndependence,
    sendMilitaryAid,
    switchPlayerNation
  } = useGame();

  const [filter, setFilter] = useState<'all' | 'allies' | 'rivals' | 'wars'>('all');
  const [search, setSearch] = useState('');
  const [selectedTargetId, setSelectedTargetId] = useState<string | null>(null);

  const playerNationId = state.playerNationId;
  const player = state.nations[playerNationId];
  if (!player) return null;

  // Filter nations (excluding player)
  const otherNations = Object.values(state.nations).filter(n => n.id !== playerNationId);

  const filteredNations = otherNations.filter(nation => {
    if (search && !nation.name.toLowerCase().includes(search.toLowerCase())) return false;
    const rel = state.diplomacy[playerNationId]?.[nation.id];
    if (filter === 'allies') return rel?.isAllied;
    if (filter === 'wars') return rel?.isAtWar;
    if (filter === 'rivals') return rel?.isDeclaredRival || player.rivalIds?.includes(nation.id);
    return true;
  });

  const selectedNation = selectedTargetId ? state.nations[selectedTargetId] : null;
  const currentRel = selectedTargetId ? state.diplomacy[playerNationId]?.[selectedTargetId] : null;

  const isRival = selectedTargetId ? (currentRel?.isDeclaredRival || player.rivalIds?.includes(selectedTargetId)) : false;

  return (
    <div className="p-4 space-y-4 text-xs text-slate-300">
      {/* Search and Filters */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Поиск державы по названию..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div className="flex gap-1 p-1 bg-slate-900/80 rounded-lg border border-slate-800">
          {[
            { id: 'all', label: 'Все' },
            { id: 'allies', label: 'Союзники' },
            { id: 'rivals', label: 'Соперники' },
            { id: 'wars', label: 'Война' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as 'all' | 'allies' | 'rivals' | 'wars')}
              className={`flex-1 py-1 text-center font-medium rounded transition-colors text-[11px] ${filter === tab.id ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Nation Details & Actions Modal / Section */}
      {selectedNation && currentRel && (
        <div className="bg-slate-900 p-3.5 rounded-lg border border-amber-500/40 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <div
                className="w-7 h-7 rounded flex items-center justify-center font-bold text-xs text-white border border-white/20 shadow"
                style={{ backgroundColor: selectedNation.flagColor }}
              >
                {selectedNation.name.substring(0, 1)}
              </div>
              <div>
                <div className="font-bold text-slate-100 text-sm flex items-center gap-1.5">
                  <span>{selectedNation.name}</span>
                  {selectedNation.isGreatPower && (
                    <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1 py-0.5 rounded font-normal">
                      Великая держава
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-400">Правитель: {selectedNation.ruler.name} ({selectedNation.governmentType})</div>
              </div>
            </div>
            <button
              onClick={() => setSelectedTargetId(null)}
              className="text-slate-400 hover:text-white p-1"
            >
              ✕
            </button>
          </div>

          {/* Attitude Badge */}
          {currentRel.attitude && (
            <div className={`p-2 rounded border text-xs flex items-center justify-between ${ATTITUDE_LABELS[currentRel.attitude]?.bg || 'bg-slate-950/60 border-slate-800'}`}>
              <div>
                <span className="text-[10px] text-slate-400 block">Отношение к нам:</span>
                <span className={`font-bold ${ATTITUDE_LABELS[currentRel.attitude]?.color || 'text-slate-200'}`}>
                  {ATTITUDE_LABELS[currentRel.attitude]?.label || currentRel.attitude}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 text-right max-w-[160px] truncate" title={currentRel.attitudeReason}>
                {currentRel.attitudeReason}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono-num">
            <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Мнение (Отношения)</span>
              <span className={`font-bold ${currentRel.opinion >= 25 ? 'text-emerald-400' : currentRel.opinion < 0 ? 'text-rose-400' : 'text-amber-300'}`}>
                {currentRel.opinion > 0 ? `+${currentRel.opinion}` : currentRel.opinion} / 100
              </span>
            </div>
            <div className="bg-slate-950/60 p-2 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Статус договора</span>
              <span className="font-semibold text-slate-200">
                {currentRel.isAtWar ? '⚔ В состоянии войны' : currentRel.isAllied ? '🛡 Военный союз' : currentRel.hasNonAggression ? '🤝 Пакт ненападения' : 'Нейтралитет'}
              </span>
            </div>
          </div>

          {/* Quick Switch Playable Country Button */}
          <button
            onClick={() => switchPlayerNation(selectedNation.id)}
            className="w-full bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/50 text-indigo-200 font-bold py-1.5 rounded flex items-center justify-center gap-1.5 transition-colors text-[11px]"
            title="Переключиться и играть за эту державу"
          >
            <UserCheck className="w-3.5 h-3.5 text-indigo-400" /> Взять под контроль (Играть за эту державу)
          </button>

          {/* Diplomatic Action Buttons */}
          <div className="space-y-1.5 pt-1">
            <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Дипломатические решения:</div>

            {!currentRel.isAtWar ? (
              <>
                <button
                  onClick={() => declareWar(selectedNation.id)}
                  className="w-full bg-rose-600/30 hover:bg-rose-600/50 border border-rose-600/60 text-rose-200 font-bold py-2 rounded flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Swords className="w-4 h-4 text-rose-400" /> Объявить войну
                </button>

                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => improveRelations(selectedNation.id)}
                    disabled={player.treasury < 60}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px]"
                    title="Стоимость: 60 золота, +25 к отношениям"
                  >
                    <Gift className="w-3.5 h-3.5 text-amber-400" /> Улучшить (+25)
                  </button>

                  <button
                    onClick={() => worsenRelations(selectedNation.id)}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px]"
                    title="Дипломатический демарш / оскорбление (-30)"
                  >
                    <Ban className="w-3.5 h-3.5 text-rose-400" /> Оскорбить (-30)
                  </button>

                  <button
                    onClick={() => isRival ? removeRival(selectedNation.id) : declareRival(selectedNation.id)}
                    className={`p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px] font-semibold ${isRival ? 'bg-amber-600/40 border border-amber-500 text-amber-200 hover:bg-amber-600/60' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
                    title={isRival ? 'Снять статус соперника' : 'Провозгласить официальным соперником (-60 к отношениям, +10 престижа)'}
                  >
                    <Flame className={`w-3.5 h-3.5 ${isRival ? 'text-amber-400' : 'text-slate-400'}`} />
                    {isRival ? 'Снять соперника' : 'Объявить соперником'}
                  </button>

                  <button
                    onClick={() => sendGift(selectedNation.id, 100)}
                    disabled={player.treasury < 100}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px]"
                    title="Отправить щедрый дар 100 золота (+20 к отношениям, делает державу дружелюбной)"
                  >
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Дар (100 зол.)
                  </button>

                  <button
                    onClick={() => formAlliance(selectedNation.id)}
                    disabled={currentRel.isAllied || currentRel.opinion < 25}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px]"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-sky-400" /> Союз
                  </button>

                  <button
                    onClick={() => signTradeDeal(selectedNation.id)}
                    disabled={currentRel.hasTradeAgreement}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px]"
                  >
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" /> Торговля
                  </button>

                  <button
                    onClick={() => signNonAggression(selectedNation.id)}
                    disabled={currentRel.hasNonAggression}
                    className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px]"
                  >
                    <Handshake className="w-3.5 h-3.5 text-indigo-400" /> Ненападение
                  </button>

                  <button
                    onClick={() => guaranteeIndependence(selectedNation.id)}
                    className={`p-2 rounded flex items-center justify-center gap-1 transition-colors text-[11px] ${currentRel.guaranteeIndependence ? 'bg-sky-600/40 border border-sky-500 text-sky-200' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
                    title="Гарантировать независимость державы (+30 к отношениям, защита от агрессоров)"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-sky-400" />
                    {currentRel.guaranteeIndependence ? 'Гарантия акт.' : 'Гарантировать'}
                  </button>
                </div>
              </>
            ) : (
              <div className="bg-rose-950/40 border border-rose-800/80 p-2 rounded text-rose-300 text-center font-medium">
                Мы находимся в состоянии открытой войны! Направляйте дивизии на штурм вражеских провинций.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Nations List */}
      <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-1">
        {filteredNations.map(nation => {
          const rel = state.diplomacy[playerNationId]?.[nation.id];
          const isSelected = selectedTargetId === nation.id;
          const isNationRival = rel?.isDeclaredRival || player.rivalIds?.includes(nation.id);

          return (
            <div
              key={nation.id}
              onClick={() => setSelectedTargetId(nation.id)}
              className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${isSelected ? 'bg-amber-500/15 border-amber-400/80' : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/60 hover:border-slate-700'}`}
            >
              <div className="flex items-center gap-2.5">
                <div
                  className="w-5 h-5 rounded flex items-center justify-center font-bold text-[10px] text-white flex-shrink-0 border border-white/20"
                  style={{ backgroundColor: nation.flagColor }}
                >
                  {nation.name.substring(0, 1)}
                </div>
                <div>
                  <div className="font-semibold text-slate-200 text-xs flex items-center gap-1.5">
                    <span>{nation.name}</span>
                    {isNationRival && <Flame className="w-3 h-3 text-amber-400" title="Соперник" />}
                  </div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
                    <span>{nation.governmentType}</span>
                    {rel?.isAtWar && <span className="text-rose-400 font-bold">· Война</span>}
                    {rel?.isAllied && <span className="text-sky-400 font-semibold">· Союз</span>}
                    {rel?.attitude && (
                      <span className={`font-medium ${ATTITUDE_LABELS[rel.attitude]?.color || 'text-slate-400'}`}>
                        · {ATTITUDE_LABELS[rel.attitude]?.label || rel.attitude}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="font-mono-num font-bold text-xs text-right">
                <span className={rel && rel.opinion >= 25 ? 'text-emerald-400' : rel && rel.opinion < 0 ? 'text-rose-400' : 'text-amber-300'}>
                  {rel && rel.opinion > 0 ? `+${rel.opinion}` : rel?.opinion}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
