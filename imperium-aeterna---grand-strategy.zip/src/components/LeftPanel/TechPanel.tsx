import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { BookOpen, Shield, TrendingUp, Landmark, Atom, CheckCircle2 } from 'lucide-react';

export const TechPanel: React.FC = () => {
  const { state, startTechResearch } = useGame();
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const [activeCategory, setActiveCategory] = useState<'military' | 'economy' | 'administration' | 'science'>('military');

  const categories = [
    { id: 'military', label: 'Военные', icon: Shield },
    { id: 'economy', label: 'Экономика', icon: TrendingUp },
    { id: 'administration', label: 'Управление', icon: Landmark },
    { id: 'science', label: 'Наука', icon: Atom }
  ] as const;

  const techs = Object.values(state.technologies).filter(t => t.category === activeCategory);

  return (
    <div className="p-4 space-y-4 text-xs text-slate-300">
      {/* Tech Points Header */}
      <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 flex items-center justify-between">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400">Очки исследований</div>
          <div className="text-xl font-bold font-mono-num text-indigo-300 flex items-center gap-1.5 mt-0.5">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            {player.techPoints} очков
          </div>
        </div>
        <div className="text-right text-[11px] text-slate-400">
          Прирост: <strong className="text-emerald-400 font-mono-num">+{(15 + player.ruler.adminSkill * 3)}</strong> / мес
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-1 p-1 bg-slate-900/80 rounded-lg border border-slate-800">
        {categories.map(cat => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex-1 py-1.5 flex flex-col items-center gap-1 rounded transition-colors text-[11px] ${isActive ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Technologies List */}
      <div className="space-y-2.5 max-h-[480px] overflow-y-auto pr-1">
        {techs.map(tech => {
          const isResearched = player.researchedTechs.includes(tech.id);
          const canAfford = player.techPoints >= tech.cost;

          return (
            <div
              key={tech.id}
              className={`p-3 rounded-lg border transition-all space-y-2 ${isResearched ? 'bg-emerald-950/20 border-emerald-800/60' : 'bg-slate-900/60 border-slate-800'}`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-slate-100 text-sm">
                    {isResearched && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                    <span>{tech.name}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">Уровень {tech.tier}</div>
                </div>

                {!isResearched && (
                  <button
                    onClick={() => startTechResearch(tech.id)}
                    disabled={!canAfford}
                    className="bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/60 disabled:opacity-35 text-indigo-200 px-3 py-1 rounded font-semibold font-mono-num transition-colors"
                  >
                    Изучить ({tech.cost} 📜)
                  </button>
                )}
                {isResearched && (
                  <span className="text-emerald-400 font-semibold text-[11px]">Изучено</span>
                )}
              </div>

              <p className="text-slate-400 text-[11px] leading-relaxed">
                {tech.description}
              </p>

              <div className="bg-slate-950/60 p-2 rounded border border-slate-800/80 text-[11px] text-amber-300 font-medium">
                Эффект: {tech.effects}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
