import React from 'react';
import { useGame } from '../../context/GameContext';
import { Crown, Sparkles, Shield, Landmark, Book, Award } from 'lucide-react';

export const NationPanel: React.FC = () => {
  const { state } = useGame();
  const player = state.nations[state.playerNationId];
  if (!player) return null;

  const ruler = player.ruler;

  return (
    <div className="p-4 space-y-5 text-xs text-slate-300">
      {/* Nation Header */}
      <div className="flex items-center gap-3 bg-slate-900/80 p-3 rounded-lg border border-slate-800">
        <div
          className="w-12 h-12 rounded-lg flex items-center justify-center font-serif-title font-bold text-xl text-white shadow-lg border border-amber-400/40"
          style={{ backgroundColor: player.flagColor }}
        >
          {player.name.substring(0, 1)}
        </div>
        <div>
          <h2 className="text-base font-bold font-serif-title text-slate-100">{player.name}</h2>
          <div className="text-slate-400 text-[11px] flex items-center gap-2">
            <span>{player.governmentType}</span>
            <span>·</span>
            <span className="text-amber-300">{player.religion}</span>
          </div>
        </div>
      </div>

      {/* Ruler Section */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-1.5 font-bold text-slate-100">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>Государь: {ruler.name}</span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono-num">{ruler.age} лет</span>
        </div>

        <div className="text-[11px] text-slate-400">
          Династия: <span className="text-slate-200 font-medium">{ruler.dynasty}</span>
        </div>

        {/* Ruler Skills: Admin, Diplo, Mil (1-6) */}
        <div className="grid grid-cols-3 gap-2 pt-1 text-center font-mono-num">
          <div className="bg-slate-950/70 p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Управление</div>
            <div className="text-base font-bold text-emerald-400">{ruler.adminSkill} / 6</div>
          </div>
          <div className="bg-slate-950/70 p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Дипломатия</div>
            <div className="text-base font-bold text-sky-400">{ruler.diploSkill} / 6</div>
          </div>
          <div className="bg-slate-950/70 p-2 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Военное дело</div>
            <div className="text-base font-bold text-rose-400">{ruler.milSkill} / 6</div>
          </div>
        </div>

        {/* Traits */}
        <div className="pt-1">
          <div className="text-[10px] uppercase tracking-wider text-slate-500 mb-1">Особенности характера:</div>
          <div className="flex flex-wrap gap-1">
            {ruler.traits.map(t => (
              <span key={t} className="bg-amber-950/40 text-amber-300 border border-amber-800/60 px-2 py-0.5 rounded text-[11px]">
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* National Idea & Heritage */}
      <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
        <div className="flex items-center gap-1.5 font-bold text-amber-300">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Национальная идея: {player.nationalIdea}</span>
        </div>
        <p className="text-slate-300 leading-relaxed text-[11px]">
          {player.nationalIdeaDesc}
        </p>
      </div>

      {/* Key State Metrics */}
      <div className="grid grid-cols-2 gap-2 text-[11px] font-mono-num">
        <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">Престиж державы</span>
          <span className="text-sm font-bold text-amber-400">{player.prestige} / 100</span>
        </div>
        <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">Стабильность</span>
          <span className={`text-sm font-bold ${player.stability >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {player.stability > 0 ? `+${player.stability}` : player.stability}%
          </span>
        </div>
        <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">Культурная группа</span>
          <span className="text-slate-200 font-sans font-medium">{player.culture}</span>
        </div>
        <div className="bg-slate-900/60 p-2.5 rounded border border-slate-800">
          <span className="text-slate-400 block text-[10px]">Столичный град</span>
          <span className="text-slate-200 font-sans font-medium">{state.provinces[player.capitalProvinceId]?.name}</span>
        </div>
      </div>
    </div>
  );
};
