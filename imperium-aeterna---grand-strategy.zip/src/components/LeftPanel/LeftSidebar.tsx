import React, { useState } from 'react';
import { Crown, Coins, Compass, Shield, BookOpen, Users, ChevronLeft, ChevronRight } from 'lucide-react';
import { NationPanel } from './NationPanel';
import { EconomyPanel } from './EconomyPanel';
import { DiplomacyPanel } from './DiplomacyPanel';
import { MilitaryPanel } from './MilitaryPanel';
import { TechPanel } from './TechPanel';
import { EstatesPanel } from './EstatesPanel';

export type LeftTabId = 'nation' | 'economy' | 'diplomacy' | 'military' | 'tech' | 'estates';

export const LeftSidebar: React.FC = () => {
  const [activeTab, setActiveTab] = useState<LeftTabId | null>('nation');
  const [isOpen, setIsOpen] = useState(true);

  const tabs: Array<{ id: LeftTabId; label: string; icon: React.FC<{ className?: string }> }> = [
    { id: 'nation', label: 'Держава', icon: Crown },
    { id: 'economy', label: 'Экономика', icon: Coins },
    { id: 'diplomacy', label: 'Дипломатия', icon: Compass },
    { id: 'military', label: 'Армия', icon: Shield },
    { id: 'tech', label: 'Технологии', icon: BookOpen },
    { id: 'estates', label: 'Политика', icon: Users }
  ];

  const handleTabClick = (tabId: LeftTabId) => {
    if (activeTab === tabId && isOpen) {
      setIsOpen(false);
    } else {
      setActiveTab(tabId);
      setIsOpen(true);
    }
  };

  return (
    <div className="absolute left-0 top-14 bottom-0 z-30 flex pointer-events-none">
      {/* Icon Navigation Column */}
      <div className="w-13 bg-slate-950/95 border-r border-slate-800/80 flex flex-col items-center py-3 gap-2 shadow-2xl pointer-events-auto backdrop-blur-md">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = isOpen && activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              title={tab.label}
              className={`w-10 h-10 rounded-lg flex flex-col items-center justify-center transition-all ${isActive ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-inner' : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70'}`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[9px] font-medium mt-0.5 tracking-tight leading-none">
                {tab.label.substring(0, 3)}
              </span>
            </button>
          );
        })}

        <div className="mt-auto">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title={isOpen ? 'Свернуть панель' : 'Развернуть панель'}
          >
            {isOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Content Drawer */}
      {isOpen && activeTab && (
        <div className="w-84 md:w-96 bg-slate-950/95 border-r border-slate-800 shadow-2xl flex flex-col overflow-hidden pointer-events-auto backdrop-blur-md animate-in slide-in-from-left-2 duration-150">
          <div className="h-10 border-b border-slate-800 flex items-center justify-between px-4 bg-slate-900/50">
            <span className="font-bold text-xs font-serif-title uppercase tracking-wider text-slate-200">
              {tabs.find(t => t.id === activeTab)?.label}
            </span>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white text-xs p-1"
            >
              ✕
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {activeTab === 'nation' && <NationPanel />}
            {activeTab === 'economy' && <EconomyPanel />}
            {activeTab === 'diplomacy' && <DiplomacyPanel />}
            {activeTab === 'military' && <MilitaryPanel />}
            {activeTab === 'tech' && <TechPanel />}
            {activeTab === 'estates' && <EstatesPanel />}
          </div>
        </div>
      )}
    </div>
  );
};
