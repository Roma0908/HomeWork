import { cn } from "@/lib/cn";

function Input({ className, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-md bg-paper px-3 text-sm text-ink shadow-border outline-none transition-[box-shadow] duration-150 placeholder:text-faint focus-visible:ring-2 focus-visible:ring-ink/15",
        className,
      )}
      {...props}
    />
  );
}

function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "min-h-28 w-full rounded-lg bg-paper px-3 py-2.5 text-sm leading-relaxed text-ink shadow-border outline-none transition-[box-shadow] duration-150 placeholder:text-faint focus-visible:ring-2 focus-visible:ring-ink/15",
        className,
      )}
      {...props}
    />
  );
}

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return (
    <label
      className={cn("text-xs font-medium tracking-wide text-muted", className)}
      {...props}
    />
  );
}

export { Input, Textarea, Label };
