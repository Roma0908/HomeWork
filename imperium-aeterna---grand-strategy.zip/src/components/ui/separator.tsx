import { cn } from "@/lib/cn";

function Separator({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      role="separator"
      className={cn("h-px w-full bg-rule", className)}
      {...props}
    />
  );
}

export { Separator };
