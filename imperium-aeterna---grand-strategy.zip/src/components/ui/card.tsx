import type { ComponentProps } from "react";
import { cn } from "@/lib/cn";

function Card({ className, ...props }: ComponentProps<"div">) {
  return (
    <div
      className={cn("rounded-xl bg-card p-5 text-ink shadow-border", className)}
      {...props}
    />
  );
}

function CardTitle({ className, ...props }: ComponentProps<"h3">) {
  return (
    <h3
      className={cn("font-display text-lg font-medium tracking-tight text-ink", className)}
      {...props}
    />
  );
}

function CardDesc({ className, ...props }: ComponentProps<"p">) {
  return <p className={cn("mt-1 text-sm leading-relaxed text-muted", className)} {...props} />;
}

export { Card, CardTitle, CardDesc };
