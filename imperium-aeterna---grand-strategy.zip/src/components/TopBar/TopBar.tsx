import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { MapMode } from '../../types/game';
import { HISTORICAL_ERAS } from '../../data/historicalEras';
import {
  Coins,
  Users,
  Shield,
  BookOpen,
  Award,
  Compass,
  Play,
  Pause,
  FastForward,
  Layers,
  Volume2,
  VolumeX,
  Menu,
  HelpCircle,
  Flame,
  Sparkles,
  ChevronDown,
  UserCheck
} from 'lucide-react';
import { getTotalTroopCount } from '../../utils/combat';

interface TopBarProps {
  onOpenMenu: () => void;
  onOpenTutorial: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onOpenMenu, onOpenTutorial }) => {
  const { state, setSpeed, togglePause, setMapMode, toggleAudio, switchPlayerNation } = useGame();
  const {
    currentDate,
    gameSpeed,
    isPaused,
    playerNationId,
    nations,
    provinces,
    armies,
    mapMode,
    audioEnabled
  } = state;

  const [showNationPicker, setShowNationPicker] = useState(false);
  const player = nations[playerNationId];

  // Calculate player monthly stats
  const ownProvinces = Object.values(provinces).filter(p => p.ownerNationId === playerNationId);
  const taxSum = ownProvinces.reduce((sum, p) => sum + (p.taxBase * (player?.taxRate || 1.0)), 0);
  const tradeSum = ownProvinces.reduce((sum, p) => sum + (p.productionBase * 0.8), 0);
  const playerArmies = Object.values(armies).filter(a => a.nationId === playerNationId);
  const troopCount = playerArmies.reduce((sum, a) => sum + getTotalTroopCount(a), 0);
  const armyUpkeep = Math.round(troopCount * 0.005);
  const netMonthlyIncome = Math.round(taxSum + tradeSum - armyUpkeep - ((player?.loans || 0) * 15) - 10);

  const monthNames = [
    'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
    'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
  ];

  const mapModes: Array<{ id: MapMode; label: string }> = [
    { id: 'political', label: 'Политика' },
    { id: 'diplomatic', label: 'Дипломатия' },
    { id: 'resources', label: 'Ресурсы' },
    { id: 'population', label: 'Население' },
    { id: 'military', label: 'Военная' },
    { id: 'stability', label: 'Стабильность' }
  ];

  const allNationsList = Object.values(nations);

  return (
    <header className="h-14 bg-slate-950/95 border-b border-slate-800 flex items-center justify-between px-4 z-40 select-none shadow-lg">
      {/* Zone 1: Flag, Nation Name & Primary Indicators */}
      <div className="flex items-center gap-4">
        {/* Nation Emblem & Name with Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowNationPicker(!showNationPicker)}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-all text-left group"
            title="Нажмите, чтобы сменить державу"
          >
            <div
              className="w-7 h-7 rounded border border-amber-400/50 shadow flex items-center justify-center font-bold text-xs text-white"
              style={{ backgroundColor: player?.flagColor || '#7c2d12' }}
            >
              {player?.name?.substring(0, 1) || 'V'}
            </div>
            <div className="hidden lg:block">
              <div className="text-xs font-bold tracking-wide text-slate-100 font-serif-title uppercase flex items-center gap-1 group-hover:text-amber-300">
                <span>{player?.name || 'Государство'}</span>
                <ChevronDown className="w-3 h-3 text-slate-400 group-hover:text-amber-300" />
              </div>
              <div className="text-[10px] text-slate-400 font-medium leading-none">
                {player?.ruler?.name}
              </div>
            </div>
          </button>

          {/* Nation Switcher Popup Dropdown */}
          {showNationPicker && (
            <div className="absolute left-0 top-12 w-72 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl p-2 z-50 max-h-96 overflow-y-auto space-y-1">
              <div className="text-[11px] font-bold text-slate-400 px-2 py-1 border-b border-slate-800 flex items-center justify-between">
                <span>Сменить державу (Играть за):</span>
                <span className="text-amber-400 font-mono-num">{allNationsList.length}</span>
              </div>
              {allNationsList.map(n => (
                <div
                  key={n.id}
                  onClick={() => {
                    switchPlayerNation(n.id);
                    setShowNationPicker(false);
                  }}
                  className={`p-2 rounded-lg cursor-pointer flex items-center justify-between transition-colors ${n.id === playerNationId ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40' : 'hover:bg-slate-900 text-slate-300'}`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className="w-5 h-5 rounded flex items-center justify-center font-bold text-[10px] text-white"
                      style={{ backgroundColor: n.flagColor }}
                    >
                      {n.name.substring(0, 1)}
                    </div>
                    <span className="text-xs truncate max-w-[170px]">{n.name}</span>
                  </div>
                  {n.isGreatPower && (
                    <span className="text-[9px] bg-amber-500/10 text-amber-400 px-1 py-0.5 rounded">
                      ★
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="h-6 w-px bg-slate-800 hidden sm:block" />

        {/* Resources & Economy Bar */}
        <div className="flex items-center gap-3 text-xs">
          {/* Treasury */}
          <div className="flex items-center gap-1.5" title="Казна и ежемесячный чистый доход">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="font-mono-num font-semibold text-amber-200">
              {player?.treasury.toLocaleString()}
            </span>
            <span className={`text-[10px] font-mono-num ${netMonthlyIncome >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              ({netMonthlyIncome >= 0 ? `+${netMonthlyIncome}` : netMonthlyIncome})
            </span>
          </div>

          {/* Manpower */}
          <div className="flex items-center gap-1.5" title="Рекрутский резерв">
            <Users className="w-4 h-4 text-sky-400" />
            <span className="font-mono-num font-semibold text-slate-200">
              {player?.manpower.toLocaleString()}
            </span>
            <span className="text-[10px] text-slate-500 font-mono-num hidden md:inline">
              / {player?.maxManpower.toLocaleString()}
            </span>
          </div>

          {/* Standing Army Count */}
          <div className="flex items-center gap-1.5" title="Численность регулярной армии">
            <Shield className="w-4 h-4 text-rose-400" />
            <span className="font-mono-num font-semibold text-slate-200">
              {troopCount.toLocaleString()}
            </span>
          </div>

          {/* Prestige */}
          <div className="flex items-center gap-1.5 hidden xl:flex" title="Престиж державы">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="font-mono-num font-semibold text-amber-300">
              {player?.prestige || 50}
            </span>
          </div>

          {/* Stability */}
          <div className="flex items-center gap-1.5 hidden xl:flex" title="Стабильность державы (-100 до +100)">
            <Award className="w-4 h-4 text-violet-400" />
            <span className={`font-mono-num font-semibold ${(player?.stability || 0) >= 20 ? 'text-emerald-400' : (player?.stability || 0) < 0 ? 'text-rose-400' : 'text-amber-300'}`}>
              {player?.stability > 0 ? `+${player.stability}` : player?.stability}%
            </span>
          </div>

          {/* Infamy / Aggressive Expansion */}
          {(player?.infamy || 0) > 0 && (
            <div className="flex items-center gap-1 hidden 2xl:flex" title="Дурная слава / Агрессивная экспансия (если > 25, соседи могут объединиться в коалицию против вас!)">
              <Flame className="w-4 h-4 text-rose-500" />
              <span className="font-mono-num font-bold text-rose-400 text-[11px]">
                {player?.infamy}
              </span>
            </div>
          )}

          {/* Technology Points */}
          <div className="flex items-center gap-1.5 hidden sm:flex" title="Очки научных и военных исследований">
            <BookOpen className="w-4 h-4 text-indigo-400" />
            <span className="font-mono-num font-semibold text-indigo-200">
              {player?.techPoints}
            </span>
          </div>

          {/* Diplomatic Points */}
          <div className="flex items-center gap-1.5 hidden md:flex" title="Дипломатическое влияние">
            <Compass className="w-4 h-4 text-teal-400" />
            <span className="font-mono-num font-semibold text-teal-200">
              {player?.diplomaticPoints}
            </span>
          </div>
        </div>
      </div>

      {/* Zone 2: Date & Time Speed Controls */}
      <div className="flex items-center gap-3 bg-slate-900/90 border border-slate-800 rounded-lg px-3 py-1 shadow-inner">
        <div className="flex items-center gap-2">
          <span className="hidden xl:inline text-[10px] font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
            {HISTORICAL_ERAS.find(e => e.id === state.currentEra)?.name.split(' (')[0] || 'Эпоха'}
          </span>
          <div className="text-xs font-serif-title tracking-wider text-slate-200 whitespace-nowrap">
            {currentDate.day} {monthNames[currentDate.month - 1]} {currentDate.year}
          </div>
        </div>

        <div className="h-4 w-px bg-slate-800" />

        {/* Speed buttons */}
        <div className="flex items-center gap-0.5">
          <button
            onClick={togglePause}
            className={`p-1 rounded transition-colors ${isPaused ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'hover:bg-slate-800 text-slate-400 hover:text-white'}`}
            title="Пауза (Пробел)"
          >
            {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5 fill-current" />}
          </button>

          {[1, 2, 5, 10, 20].map(spd => (
            <button
              key={spd}
              onClick={() => setSpeed(spd)}
              className={`px-1.5 py-0.5 text-[11px] font-mono-num font-semibold rounded transition-colors ${!isPaused && gameSpeed === spd ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'hover:bg-slate-800 text-slate-400 hover:text-white'}`}
              title={`Скорость x${spd}`}
            >
              {spd}x
            </button>
          ))}
        </div>
      </div>

      {/* Zone 3: Map Modes & Main Navigation */}
      <div className="flex items-center gap-2">
        {/* Map Mode Buttons */}
        <div className="hidden lg:flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5">
          {mapModes.map(mode => (
            <button
              key={mode.id}
              onClick={() => setMapMode(mode.id)}
              className={`px-2.5 py-1 text-[11px] font-medium rounded transition-all whitespace-nowrap ${mapMode === mode.id ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* Audio Toggle */}
        <button
          onClick={toggleAudio}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          title={audioEnabled ? 'Отключить звук' : 'Включить звук'}
        >
          {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Tutorial Button */}
        <button
          onClick={onOpenTutorial}
          className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors"
          title="Справка и обучение"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* Menu Button */}
        <button
          onClick={onOpenMenu}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold border border-slate-700 transition-colors"
        >
          <Menu className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Меню</span>
        </button>
      </div>
    </header>
  );
};
