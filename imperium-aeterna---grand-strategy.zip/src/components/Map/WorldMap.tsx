import React, { useState, useRef, useEffect } from 'react';
import { useGame } from '../../context/GameContext';
import { Province, ResourceType } from '../../types/game';
import { getTotalTroopCount } from '../../utils/combat';
import { Shield, Swords, Star, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

const RESOURCE_COLORS: Record<ResourceType, string> = {
  grain: '#eab308',
  iron: '#64748b',
  coal: '#334155',
  gold: '#fbbf24',
  tar: '#0891b2',
  timber: '#15803d',
  stone: '#94a3b8',
  horses: '#b45309'
};

const RESOURCE_LABELS: Record<ResourceType, string> = {
  grain: 'Зерно',
  iron: 'Железо',
  coal: 'Уголь',
  gold: 'Золото',
  tar: 'Смола и деготь',
  timber: 'Древесина',
  stone: 'Камень',
  horses: 'Кони'
};

const TERRAIN_LABELS: Record<string, string> = {
  plains: 'Равнины',
  mountains: 'Горы',
  hills: 'Холмы',
  forest: 'Леса',
  marsh: 'Болота',
  coastal: 'Побережье'
};

export const WorldMap: React.FC = () => {
  const { state, selectProvince, selectArmy, moveArmy } = useGame();
  const { provinces, nations, armies, battles, selectedProvinceId, selectedArmyId, mapMode } = state;

  const [scale, setScale] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredProv, setHoveredProv] = useState<Province | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const containerRef = useRef<HTMLDivElement>(null);

  // Wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    setScale(prev => Math.min(3.2, Math.max(0.65, prev * zoomFactor)));
  };

  // Drag pan
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) { // left button for pan if clicking empty area or drag
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
    if (isDragging) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleProvinceClick = (prov: Province) => {
    // If an army is selected and belong to player, move it to this province if neighbor
    if (selectedArmyId) {
      const selectedArmy = armies[selectedArmyId];
      if (selectedArmy && selectedArmy.nationId === state.playerNationId) {
        const currentProv = provinces[selectedArmy.provinceId];
        if (currentProv && (currentProv.neighborIds.includes(prov.id) || currentProv.id === prov.id)) {
          moveArmy(selectedArmyId, prov.id);
          return;
        }
      }
    }
    selectProvince(prov.id);
  };

  // Province Color Calculator based on MapMode
  const getProvinceFill = (prov: Province): string => {
    if (prov.occupiedBy) {
      const occNation = nations[prov.occupiedBy];
      return occNation ? occNation.flagColor : '#78716c';
    }

    if (mapMode === 'political') {
      const owner = nations[prov.ownerNationId];
      return owner ? owner.flagColor : '#334155';
    }

    if (mapMode === 'resources') {
      return RESOURCE_COLORS[prov.resource] || '#64748b';
    }

    if (mapMode === 'population') {
      // Heatmap 100k -> 400k
      const t = Math.min(1, Math.max(0, (prov.population - 80000) / 320000));
      const r = Math.round(30 + t * 200);
      const g = Math.round(90 + (1 - t) * 80);
      const b = Math.round(180 - t * 140);
      return `rgb(${r}, ${g}, ${b})`;
    }

    if (mapMode === 'military') {
      if (prov.fortLevel > 0) return '#b91c1c';
      if (prov.barracksLevel > 0) return '#c2410c';
      return '#334155';
    }

    if (mapMode === 'stability') {
      const owner = nations[prov.ownerNationId];
      if (!owner) return '#334155';
      if (owner.stability >= 30) return '#15803d';
      if (owner.stability >= 0) return '#ca8a04';
      return '#991b1b';
    }

    if (mapMode === 'diplomatic') {
      if (prov.ownerNationId === state.playerNationId) return '#2563eb'; // Blue for player
      const diplo = state.diplomacy[state.playerNationId]?.[prov.ownerNationId];
      if (!diplo) return '#475569';
      if (diplo.isAtWar) return '#dc2626'; // Red
      if (diplo.isDeclaredRival) return '#ea580c'; // Orange rival
      if (diplo.isAllied) return '#16a34a'; // Green ally
      if (diplo.hasNonAggression || diplo.hasTradeAgreement) return '#0284c7'; // Sky
      if (diplo.opinion > 30) return '#65a30d'; // Lime
      if (diplo.opinion < -30) return '#991b1b'; // Dark red
      return '#64748b'; // Slate neutral
    }

    return '#334155';
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden bg-[#0a0e17] cursor-grab active:cursor-grabbing select-none"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Background Cartographic Grid & Water */}
      <svg
        className="w-full h-full block"
        viewBox="0 0 1900 950"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
          transformOrigin: '0 0',
          transition: isDragging ? 'none' : 'transform 0.08s ease-out'
        }}
      >
        <defs>
          {/* Subtle parchment / water texture filter */}
          <radialGradient id="waterGrad" cx="50%" cy="50%" r="70%">
            <stop offset="0%" stopColor="#0b1322" />
            <stop offset="100%" stopColor="#060911" />
          </radialGradient>

          {/* Occupied striped pattern */}
          <pattern id="occupiedStripe" width="8" height="8" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
            <line x1="0" y1="0" x2="0" y2="8" stroke="#ef4444" strokeWidth="2.5" />
          </pattern>
        </defs>

        {/* Ocean Background */}
        <rect x="0" y="0" width="1900" height="950" fill="url(#waterGrad)" />

        {/* Ocean Cartographic Typography */}
        <g fill="rgba(255,255,255,0.06)" className="font-serif-title uppercase select-none pointer-events-none" fontWeight="700">
          <text x="1050" y="80" fontSize="16" letterSpacing="0.4em">Северный Ледовитый Океан</text>
          <text x="560" y="470" fontSize="18" letterSpacing="0.45em">Атлантический Океан</text>
          <text x="100" y="580" fontSize="18" letterSpacing="0.45em">Тихий Океан</text>
          <text x="1750" y="580" fontSize="18" letterSpacing="0.45em">Тихий Океан</text>
          <text x="1350" y="770" fontSize="18" letterSpacing="0.4em">Индийский Океан</text>
          <text x="890" y="530" fontSize="11" letterSpacing="0.3em">Средиземное Море</text>
          <text x="960" y="235" fontSize="10" letterSpacing="0.25em">Балтийское Море</text>
          <text x="1135" y="445" fontSize="10" letterSpacing="0.25em">Черное Море</text>
          <text x="410" y="525" fontSize="11" letterSpacing="0.3em">Карибское Море</text>
        </g>

        {/* Latitude and Longitude Grid Lines */}
        <g stroke="rgba(255,255,255,0.03)" strokeWidth="1">
          <line x1="0" y1="190" x2="1900" y2="190" />
          <line x1="0" y1="380" x2="1900" y2="380" />
          <line x1="0" y1="570" x2="1900" y2="570" />
          <line x1="0" y1="760" x2="1900" y2="760" />
          <line x1="300" y1="0" x2="300" y2="950" />
          <line x1="600" y1="0" x2="600" y2="950" />
          <line x1="900" y1="0" x2="900" y2="950" />
          <line x1="1200" y1="0" x2="1200" y2="950" />
          <line x1="1500" y1="0" x2="1500" y2="950" />
        </g>

        {/* Province Polygons */}
        <g className="provinces-layer">
          {Object.values(provinces).map(prov => {
            const isSelected = prov.id === selectedProvinceId;
            const isHovered = hoveredProv?.id === prov.id;
            const fill = getProvinceFill(prov);

            return (
              <g key={prov.id}>
                <path
                  d={prov.svgPath}
                  fill={fill}
                  fillOpacity={isSelected ? 0.95 : isHovered ? 0.88 : 0.72}
                  stroke={isSelected ? '#fbbf24' : isHovered ? '#f1f5f9' : 'rgba(15, 23, 42, 0.95)'}
                  strokeWidth={isSelected ? 2.5 : isHovered ? 1.8 : 1.2}
                  className="transition-all duration-150 cursor-pointer"
                  onMouseEnter={() => setHoveredProv(prov)}
                  onMouseLeave={() => setHoveredProv(null)}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleProvinceClick(prov);
                  }}
                />

                {/* Occupied overlay stripes */}
                {prov.occupiedBy && (
                  <path
                    d={prov.svgPath}
                    fill="url(#occupiedStripe)"
                    fillOpacity="0.45"
                    pointerEvents="none"
                  />
                )}
              </g>
            );
          })}
        </g>

        {/* Capital Stars and City Dots */}
        <g className="cities-layer" pointerEvents="none">
          {Object.values(provinces).map(prov => {
            const [cx, cy] = prov.center;
            return (
              <g key={`city_${prov.id}`}>
                {prov.capital ? (
                  <g transform={`translate(${cx - 7}, ${cy - 14})`}>
                    <polygon
                      points="7,0 9,5 14,5 10,8 12,13 7,10 2,13 4,8 0,5 5,5"
                      fill="#fbbf24"
                      stroke="#451a03"
                      strokeWidth="1"
                    />
                  </g>
                ) : (
                  <circle
                    cx={cx}
                    cy={cy - 5}
                    r="2.5"
                    fill="#f8fafc"
                    stroke="#0f172a"
                    strokeWidth="0.8"
                  />
                )}

                {/* Province Name Label */}
                <text
                  x={cx}
                  y={cy + 10}
                  textAnchor="middle"
                  fontSize={prov.capital ? "10" : "8"}
                  fontWeight={prov.capital ? "700" : "500"}
                  fill={prov.capital ? "#fef08a" : "#e2e8f0"}
                  stroke="#020617"
                  strokeWidth="2.5"
                  paintOrder="stroke"
                  className="font-serif-title tracking-wide pointer-events-none select-none"
                >
                  {prov.name}
                </text>
              </g>
            );
          })}
        </g>

        {/* Armies on Map */}
        <g className="armies-layer">
          {Object.values(armies).map(army => {
            const prov = provinces[army.provinceId];
            if (!prov) return null;

            const isSelected = army.id === selectedArmyId;
            const nation = nations[army.nationId];
            const [cx, cy] = prov.center;
            const troopCount = getTotalTroopCount(army);

            // If army is moving, show arrow to target
            let movementLine = null;
            if (army.isMoving && army.targetProvinceId) {
              const targetProv = provinces[army.targetProvinceId];
              if (targetProv) {
                movementLine = (
                  <line
                    x1={cx}
                    y1={cy - 12}
                    x2={targetProv.center[0]}
                    y2={targetProv.center[1] - 12}
                    stroke="#fbbf24"
                    strokeWidth="2"
                    strokeDasharray="4 3"
                  />
                );
              }
            }

            return (
              <g key={army.id}>
                {movementLine}
                <g
                  transform={`translate(${cx - 16}, ${cy - 30})`}
                  className="cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    selectArmy(army.id);
                  }}
                >
                  {/* Army badge box */}
                  <rect
                    x="0"
                    y="0"
                    width="32"
                    height="18"
                    rx="3"
                    fill={nation ? nation.flagColor : '#1e293b'}
                    stroke={isSelected ? '#fbbf24' : '#ffffff'}
                    strokeWidth={isSelected ? 2 : 1}
                  />
                  {/* Unit icon + Count */}
                  <text
                    x="16"
                    y="13"
                    textAnchor="middle"
                    fontSize="9"
                    fontWeight="700"
                    fill="#ffffff"
                    className="font-mono-num"
                  >
                    {troopCount >= 1000 ? `${(troopCount / 1000).toFixed(1)}k` : troopCount}
                  </text>
                </g>
              </g>
            );
          })}
        </g>

        {/* Active Battle Crossed Swords */}
        <g className="battles-layer">
          {battles.map(battle => {
            const prov = provinces[battle.provinceId];
            if (!prov) return null;
            const [cx, cy] = prov.center;

            return (
              <g key={battle.id} transform={`translate(${cx - 12}, ${cy - 26})`} className="animate-pulse">
                <circle cx="12" cy="12" r="14" fill="#dc2626" fillOpacity="0.8" stroke="#ffffff" strokeWidth="1.5" />
                <text x="12" y="16" textAnchor="middle" fontSize="12" fill="#ffffff">⚔</text>
              </g>
            );
          })}
        </g>
      </svg>

      {/* Map Control Buttons (Zoom / Reset) */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2 bg-slate-900/90 border border-slate-700/80 rounded-lg p-1.5 shadow-xl backdrop-blur-md z-20">
        <button
          onClick={() => setScale(prev => Math.min(3.2, prev * 1.25))}
          title="Приблизить карту"
          className="p-2 hover:bg-slate-800 text-slate-300 hover:text-white rounded transition-colors"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={() => setScale(prev => Math.max(0.65, prev * 0.8))}
          title="Отдалить карту"
          className="p-2 hover:bg-slate-800 text-slate-300 hover:text-white rounded transition-colors"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={() => { setScale(1); setPan({ x: 0, y: 0 }); }}
          title="Сбросить масштаб"
          className="p-2 hover:bg-slate-800 text-slate-300 hover:text-white rounded transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Floating Hover Tooltip */}
      {hoveredProv && (
        <div
          className="fixed pointer-events-none z-50 bg-slate-900/95 border border-slate-700 rounded-lg shadow-2xl p-3 text-xs w-64 backdrop-blur-md"
          style={{
            left: `${Math.min(window.innerWidth - 270, mousePos.x + 16)}px`,
            top: `${Math.min(window.innerHeight - 200, mousePos.y + 16)}px`
          }}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-100 text-sm">
              {hoveredProv.capital && <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />}
              <span>{hoveredProv.name}</span>
            </div>
            <span
              className="text-[10px] font-semibold px-1.5 py-0.5 rounded text-white"
              style={{ backgroundColor: nations[hoveredProv.ownerNationId]?.flagColor || '#475569' }}
            >
              {nations[hoveredProv.ownerNationId]?.name || 'Ничейная'}
            </span>
          </div>

          <div className="space-y-1 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">Население:</span>
              <span className="font-mono-num font-semibold text-slate-100">
                {hoveredProv.population.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Ресурс:</span>
              <span className="font-medium text-amber-300">
                {RESOURCE_LABELS[hoveredProv.resource]}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Ландшафт:</span>
              <span>{TERRAIN_LABELS[hoveredProv.terrain] || hoveredProv.terrain}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Налоги / Производство:</span>
              <span className="font-mono-num text-slate-100">
                {hoveredProv.taxBase} / {hoveredProv.productionBase}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Уровень крепости:</span>
              <span className="text-red-400 font-semibold">Ур. {hoveredProv.fortLevel}</span>
            </div>
            {hoveredProv.occupiedBy && (
              <div className="pt-1 text-amber-400 font-semibold flex items-center gap-1">
                <Shield className="w-3 h-3 text-red-500" />
                Оккупировано: {nations[hoveredProv.occupiedBy]?.name}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
