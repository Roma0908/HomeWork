import React, { useState, useEffect } from 'react';
import { useGame } from '../../context/GameContext';
import { EraId, HistoricalEra } from '../../types/game';
import { HISTORICAL_ERAS } from '../../data/historicalEras';
import { getEraSetup } from '../../data/eraLoader';
import { CountrySelect } from './CountrySelect';
import { SettingsModal } from './SettingsModal';
import { TutorialModal } from '../Modals/TutorialModal';
import { soundManager } from '../../utils/audio';
import {
  Crown,
  Play,
  FolderDown,
  Settings,
  HelpCircle,
  Save,
  ArrowRight,
  Landmark,
  Swords,
  Radio,
  Sparkles,
  Compass,
  CheckCircle2,
  Shield,
  Coins
} from 'lucide-react';

interface MainMenuProps {
  onCloseMenu?: () => void;
  isIngame?: boolean;
}

const ERA_ICONS: Record<string, React.FC<{ className?: string }>> = {
  Landmark,
  Swords,
  Radio,
  Crown
};

export const MainMenu: React.FC<MainMenuProps> = ({ onCloseMenu, isIngame = false }) => {
  const { startNewGame, selectScenario, loadGame, saveGame, state } = useGame();

  const [selectedEraId, setSelectedEraId] = useState<EraId>(state.currentEra || 'victorian_1836');
  const [view, setView] = useState<'main' | 'country_select' | 'settings' | 'tutorial'>('main');
  const [loadNotice, setLoadNotice] = useState<string | null>(null);

  // Transition state
  const [isLaunching, setIsLaunching] = useState(false);
  const [launchMessage, setLaunchMessage] = useState('');

  const currentEra = HISTORICAL_ERAS.find(e => e.id === selectedEraId) || HISTORICAL_ERAS[0];
  const eraSetup = getEraSetup(selectedEraId);

  const handleSelectScenario = (eraId: EraId) => {
    setSelectedEraId(eraId);
    selectScenario(eraId);
  };

  const handleStartCountry = (nationId: string, eraId: EraId) => {
    const nation = eraSetup.nations[nationId] || Object.values(eraSetup.nations)[0];
    soundManager.playWarHorn();

    // Cinematic launch transition sequence
    setIsLaunching(true);
    setLaunchMessage(`Мобилизация вооруженных сил державы ${nation?.name || ''}...`);

    setTimeout(() => {
      setLaunchMessage(`${currentEra.year} год. Указы кабинета министров вступают в силу.`);
    }, 700);

    setTimeout(() => {
      startNewGame(nationId, eraId);
      setIsLaunching(false);
      if (onCloseMenu) onCloseMenu();
    }, 1400);
  };

  const handleLoad = () => {
    const success = loadGame();
    if (success) {
      setLoadNotice('Кампания успешно загружена!');
      setTimeout(() => {
        if (onCloseMenu) onCloseMenu();
      }, 700);
    } else {
      setLoadNotice('Сохранений не найдено в памяти браузера.');
      setTimeout(() => setLoadNotice(null), 2500);
    }
  };

  const handleSave = () => {
    saveGame();
    setLoadNotice('Прогресс кампании сохранен в памяти браузера!');
    setTimeout(() => setLoadNotice(null), 2500);
  };

  if (view === 'country_select') {
    return <CountrySelect initialEraId={selectedEraId} onStart={handleStartCountry} onBack={() => setView('main')} />;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#060911] text-slate-100 select-none overflow-hidden">
      {/* 1. Atmospheric Ambient World Map Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-40">
        <svg
          className="w-full h-full object-cover"
          viewBox="0 0 1600 850"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <radialGradient id="menuMapGlow" cx="50%" cy="50%" r="65%">
              <stop offset="0%" stopColor="#1e293b" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#020617" stopOpacity="0.95" />
            </radialGradient>
          </defs>

          {/* Grid lines */}
          <g stroke="rgba(251,191,36,0.06)" strokeWidth="1">
            <line x1="0" y1="170" x2="1600" y2="170" />
            <line x1="0" y1="340" x2="1600" y2="340" />
            <line x1="0" y1="510" x2="1600" y2="510" />
            <line x1="0" y1="680" x2="1600" y2="680" />
            <line x1="300" y1="0" x2="300" y2="850" />
            <line x1="600" y1="0" x2="600" y2="850" />
            <line x1="900" y1="0" x2="900" y2="850" />
            <line x1="1200" y1="0" x2="1200" y2="850" />
          </g>

          {/* World landmasses silhouette preview */}
          {Object.values(eraSetup.provinces).map(prov => (
            <path
              key={prov.id}
              d={prov.svgPath}
              fill="rgba(15, 23, 42, 0.85)"
              stroke="rgba(251, 191, 36, 0.18)"
              strokeWidth="1"
            />
          ))}

          {/* Capital Nodes glow */}
          {Object.values(eraSetup.provinces).filter(p => p.capital).map(prov => (
            <g key={`node_${prov.id}`} transform={`translate(${prov.center[0]}, ${prov.center[1]})`}>
              <circle r="4" fill="#fbbf24" fillOpacity="0.8" className="animate-ping" />
              <circle r="3" fill="#fbbf24" />
            </g>
          ))}

          {/* Dark Scrim overlay */}
          <rect x="0" y="0" width="1600" height="850" fill="url(#menuMapGlow)" />
        </svg>
      </div>

      {/* Dark Vignette & Atmospheric Radial Glow */}
      <div className="absolute inset-0 bg-radial from-transparent via-[#060911]/70 to-[#030508] pointer-events-none" />

      {/* 2. Main Startup Stage Layout */}
      <div className="relative z-10 w-full h-full max-w-7xl mx-auto flex flex-col justify-between p-6 md:p-10">
        {/* Top Header Bar */}
        <header className="flex items-center justify-between border-b border-slate-800/80 pb-4 backdrop-blur-md">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-amber-500/20 via-amber-600/10 to-transparent border border-amber-500/40 shadow-xl">
              <Crown className="w-7 h-7 text-amber-400" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black font-serif-title tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500">
                IMPERIUM AETERNA
              </h1>
              <div className="text-[11px] text-amber-300/70 tracking-widest uppercase font-semibold flex items-center gap-2">
                <span>Grand Strategy Engine</span>
                <span>·</span>
                <span className="text-slate-400">1836 · 1936 · 2024 · 1500</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isIngame && onCloseMenu && (
              <button
                onClick={onCloseMenu}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold rounded-xl shadow-lg transition-all text-xs font-serif-title tracking-wide"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Вернуться в игру</span>
              </button>
            )}

            {isIngame && (
              <button
                onClick={handleSave}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-medium text-slate-200 transition-colors"
                title="Сохранить текущее состояние игры"
              >
                <Save className="w-3.5 h-3.5 text-emerald-400" />
                <span>Сохранить</span>
              </button>
            )}

            <button
              onClick={handleLoad}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-medium text-slate-200 transition-colors"
              title="Загрузить игру из памяти браузера"
            >
              <FolderDown className="w-3.5 h-3.5 text-sky-400" />
              <span>Загрузить</span>
            </button>

            <button
              onClick={() => setView('tutorial')}
              className="p-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-slate-300 hover:text-white transition-colors"
              title="Обучение и тактика"
            >
              <HelpCircle className="w-4 h-4 text-amber-400" />
            </button>

            <button
              onClick={() => setView('settings')}
              className="p-2 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-slate-300 hover:text-white transition-colors"
              title="Настройки"
            >
              <Settings className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </header>

        {/* Notice Toast */}
        {loadNotice && (
          <div className="self-center bg-amber-950/80 border border-amber-500/80 text-amber-300 text-xs px-5 py-2.5 rounded-xl shadow-2xl font-medium animate-in fade-in slide-in-from-top-2">
            {loadNotice}
          </div>
        )}

        {/* Center: Scenario Selection Showcases */}
        <div className="my-auto py-6 space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-3">
            <div>
              <div className="text-[11px] font-bold text-amber-400 tracking-wider uppercase flex items-center gap-1.5">
                <Compass className="w-4 h-4" /> Исторические кампании и сценарии
              </div>
              <h2 className="text-xl md:text-2xl font-bold font-serif-title text-slate-100">
                Выберите Эпоху для Правления
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-md">
              Каждый сценарий инициализирует исторические границы, технологии, формы правления, монархов и геополитические альянсы.
            </p>
          </div>

          {/* Scenario Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {HISTORICAL_ERAS.map(era => {
              const Icon = ERA_ICONS[era.bannerIcon] || Crown;
              const isSelected = selectedEraId === era.id;
              const eraData = getEraSetup(era.id);
              const nationCount = Object.keys(eraData.nations).length;

              return (
                <div
                  key={era.id}
                  onClick={() => handleSelectScenario(era.id)}
                  className={`relative rounded-2xl border transition-all duration-200 cursor-pointer overflow-hidden p-5 flex flex-col justify-between group backdrop-blur-md ${isSelected ? 'bg-gradient-to-b from-amber-950/40 via-slate-900/90 to-slate-950 border-amber-400/80 shadow-2xl ring-1 ring-amber-400/30' : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/70 shadow-lg'}`}
                >
                  {/* Top Badge */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className={`p-2 rounded-xl border ${isSelected ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' : 'bg-slate-900 text-slate-400 border-slate-800'}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="font-mono-num font-bold text-xs px-2.5 py-0.5 rounded-full bg-slate-900/90 border border-slate-700/80 text-amber-300">
                        {era.year} г.
                      </span>
                    </div>

                    <h3 className="font-bold font-serif-title text-base text-slate-100 group-hover:text-amber-300 transition-colors">
                      {era.name}
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-1 leading-snug line-clamp-3">
                      {era.subtitle}
                    </p>
                  </div>

                  {/* Nations Chips */}
                  <div className="pt-4 space-y-3">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {Object.values(eraData.nations).slice(0, 4).map(nat => (
                        <div
                          key={nat.id}
                          className="w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-bold text-white shadow border border-white/20"
                          style={{ backgroundColor: nat.flagColor }}
                          title={nat.name}
                        >
                          {nat.name.substring(0, 1)}
                        </div>
                      ))}
                      <span className="text-[10px] text-slate-400 font-mono-num">
                        +{nationCount - 4} держав
                      </span>
                    </div>

                    <div className="border-t border-slate-800/80 pt-3 flex items-center justify-between text-xs">
                      <span className={`font-semibold transition-colors flex items-center gap-1 text-[11px] ${isSelected ? 'text-amber-400' : 'text-slate-400 group-hover:text-slate-200'}`}>
                        {isSelected ? 'Сценарий активен' : 'Выбрать'}
                      </span>
                      <ArrowRight className={`w-3.5 h-3.5 transition-transform group-hover:translate-x-1 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Scenario Detailed Briefing Bar */}
          <div className="bg-slate-950/90 border border-slate-800/80 rounded-2xl p-5 shadow-2xl backdrop-blur-md flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="space-y-1.5 text-left max-w-2xl">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider font-serif-title">
                  {currentEra.name}
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-xs text-slate-400">{currentEra.subtitle}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {currentEra.description}
              </p>
            </div>

            <div className="flex items-center gap-3 w-full lg:w-auto justify-end">
              <button
                onClick={() => setView('country_select')}
                className="w-full lg:w-auto flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-sm rounded-xl shadow-2xl transition-all font-serif-title tracking-wider group"
              >
                <span>Выбрать державу и начать ({currentEra.year} г.)</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer Bar */}
        <footer className="flex items-center justify-between border-t border-slate-800/80 pt-4 text-[11px] text-slate-500 font-mono-num">
          <div>Imperium Aeterna Engine · Версия 1.2.0</div>
          <div className="hidden sm:block">Полноценная браузерная Grand Strategy</div>
          <div>{state.audioEnabled ? 'Звук: Включен' : 'Звук: Отключен'}</div>
        </footer>
      </div>

      {/* 3. Cinematic Launch Overlay Transition */}
      {isLaunching && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/90 backdrop-blur-md text-slate-100 select-none animate-in fade-in duration-300">
          <div className="p-4 rounded-2xl bg-amber-500/20 border border-amber-500/40 mb-4 animate-pulse">
            <Crown className="w-12 h-12 text-amber-400" />
          </div>
          <h2 className="text-2xl font-bold font-serif-title text-amber-200 tracking-wider">
            IMPERIUM AETERNA
          </h2>
          <div className="mt-3 text-xs text-slate-400 font-mono-num flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>{launchMessage}</span>
          </div>
        </div>
      )}

      {/* Modals */}
      {view === 'settings' && <SettingsModal onClose={() => setView('main')} />}
      {view === 'tutorial' && <TutorialModal onClose={() => setView('main')} />}
    </div>
  );
};
