import React from 'react';
import { useGame } from '../../context/GameContext';
import { Volume2, VolumeX, Shield, RotateCcw, X, Info } from 'lucide-react';
import { soundManager } from '../../utils/audio';

interface SettingsModalProps {
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const { state, toggleAudio } = useGame();

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    soundManager.volume = val;
    soundManager.playClick();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        <div className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between">
          <h2 className="text-base font-bold font-serif-title text-slate-100">Настройки игры</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs">
          {/* Audio Settings */}
          <div className="space-y-3 bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-200 flex items-center gap-2">
                {state.audioEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
                Звуковые эффекты (Web Audio)
              </span>
              <button
                onClick={toggleAudio}
                className={`px-3 py-1 rounded text-xs font-semibold transition-colors ${state.audioEnabled ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-slate-800 text-slate-400'}`}
              >
                {state.audioEnabled ? 'Включен' : 'Отключен'}
              </button>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Громкость:</span>
                <span className="font-mono-num">{Math.round(soundManager.volume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                defaultValue={soundManager.volume}
                onChange={handleVolumeChange}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Game Engine Info */}
          <div className="bg-slate-900/60 p-4 rounded-lg border border-slate-800 space-y-2 text-slate-400 text-[11px]">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-sky-400" /> Информация о движке
            </div>
            <div>Архитектура: Pure Client-Side React + SVG Canvas</div>
            <div>Игровой мир: 22 державы, 60+ детальных провинций</div>
            <div>Сохранения: локальное хранилище браузера (localStorage)</div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={onClose}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-lg text-xs transition-colors"
            >
              Закрыть
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
