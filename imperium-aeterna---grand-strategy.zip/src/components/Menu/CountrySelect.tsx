import React, { useState } from 'react';
import { EraId, HistoricalEra, Nation } from '../../types/game';
import { HISTORICAL_ERAS } from '../../data/historicalEras';
import { getEraSetup } from '../../data/eraLoader';
import {
  Crown,
  Sparkles,
  Shield,
  Coins,
  Users,
  ArrowRight,
  ArrowLeft,
  Landmark,
  Radio,
  Swords,
  Compass,
  Search,
  Flame,
  Globe
} from 'lucide-react';

interface CountrySelectProps {
  initialEraId?: EraId;
  onStart: (nationId: string, eraId: EraId) => void;
  onBack: () => void;
}

const ERA_ICONS: Record<string, React.FC<{ className?: string }>> = {
  Landmark: Landmark,
  Swords: Swords,
  Radio: Radio,
  Crown: Crown
};

export const CountrySelect: React.FC<CountrySelectProps> = ({ initialEraId, onStart, onBack }) => {
  const [selectedEraId, setSelectedEraId] = useState<EraId>(initialEraId || 'victorian_1836');
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'great_powers' | 'europe' | 'asia_americas'>('all');

  // Load era data dynamically
  const eraSetup = getEraSetup(selectedEraId);
  const currentEra = HISTORICAL_ERAS.find(e => e.id === selectedEraId) || HISTORICAL_ERAS[0];

  const nationsList = Object.values(eraSetup.nations);
  const [selectedNationId, setSelectedNationId] = useState<string>(eraSetup.defaultPlayerId);

  // Fallback if nation not in current era
  const selectedNation: Nation = eraSetup.nations[selectedNationId] || nationsList[0];

  const handleEraChange = (eraId: EraId) => {
    setSelectedEraId(eraId);
    const newSetup = getEraSetup(eraId);
    setSelectedNationId(newSetup.defaultPlayerId);
  };

  const ownProvinces = Object.values(eraSetup.provinces).filter(p => p.ownerNationId === selectedNation?.id);

  // Filter nations
  const filteredNations = nationsList.filter(nation => {
    if (search && !nation.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterType === 'great_powers') return nation.isGreatPower;
    if (filterType === 'europe') {
      const europeIds = ['britain', 'russia', 'prussia', 'france', 'austria', 'germany', 'italy', 'spain', 'portugal', 'netherlands', 'belgium', 'sweden', 'denmark', 'twosicilies', 'poland', 'ukraine', 'finland', 'valerion', 'castelia', 'yarogor', 'bergland', 'serenissima', 'england_1500'];
      return europeIds.some(prefix => nation.id.startsWith(prefix));
    }
    if (filterType === 'asia_americas') {
      const otherIds = ['usa', 'china', 'qing', 'japan', 'india', 'ottoman', 'egypt', 'persia', 'siam', 'mexico', 'brazil', 'argentina', 'colombia', 'peru', 'korea', 'indonesia', 'australia', 'canada', 'saudi', 'iran', 'al_zahir', 'safavid_1500', 'minghai'];
      return otherIds.some(prefix => nation.id.startsWith(prefix));
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#070b12] text-slate-200 select-none overflow-hidden">
      {/* Top Historical Era Selection Header (Bookmarks like HoI4/EU4/CK3) */}
      <div className="bg-slate-950/95 border-b border-slate-800/80 px-6 py-3 flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
            title="Назад в меню"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold font-serif-title tracking-wider text-slate-100 uppercase">
              Выбор Исторической Эпохи и Державы
            </h1>
            <div className="text-[11px] text-slate-400">
              {currentEra.subtitle} · Год начала: <strong className="text-amber-300 font-mono-num">{currentEra.year}</strong>
            </div>
          </div>
        </div>

        {/* Era Segmented Control Tabs */}
        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1 gap-1">
          {HISTORICAL_ERAS.map(era => {
            const Icon = ERA_ICONS[era.bannerIcon] || Crown;
            const isActive = selectedEraId === era.id;

            return (
              <button
                key={era.id}
                onClick={() => handleEraChange(era.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${isActive ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
              >
                <Icon className="w-4 h-4" />
                <span>{era.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Selection Area: Left Countries List + Right Dossier */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Nations List */}
        <div className="w-80 md:w-96 border-r border-slate-800 bg-slate-950/60 flex flex-col h-full">
          {/* Search & Filter Header */}
          <div className="p-3 border-b border-slate-800/80 bg-slate-900/40 space-y-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Поиск державы..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex gap-1 p-0.5 bg-slate-950 rounded-lg border border-slate-800 text-[10px]">
              {[
                { id: 'all', label: `Все (${nationsList.length})` },
                { id: 'great_powers', label: 'Великие' },
                { id: 'europe', label: 'Европа' },
                { id: 'asia_americas', label: 'Мир' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setFilterType(tab.id as typeof filterType)}
                  className={`flex-1 py-1 text-center font-medium rounded transition-colors whitespace-nowrap ${filterType === tab.id ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-1.5">
            {filteredNations.map(nation => {
              const isSelected = selectedNation?.id === nation.id;

              return (
                <div
                  key={nation.id}
                  onClick={() => setSelectedNationId(nation.id)}
                  className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${isSelected ? 'bg-amber-500/20 border-amber-400 shadow-lg' : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/70'}`}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs text-white shadow border border-white/20 flex-shrink-0"
                      style={{ backgroundColor: nation.flagColor }}
                    >
                      {nation.name.substring(0, 1)}
                    </div>
                    <div>
                      <div className="font-bold text-xs text-slate-100 font-serif-title flex items-center gap-1.5">
                        <span>{nation.name}</span>
                        {nation.isGreatPower && (
                          <span className="text-[8px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1 py-0.2 rounded font-normal">
                            ★
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
                        <span>{nation.governmentType}</span>
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono-num text-amber-300 font-semibold">
                    {nation.prestige} престиж
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Nation Dossier & Start Button */}
        {selectedNation && (
          <div className="flex-1 flex flex-col justify-between p-8 overflow-y-auto bg-radial from-slate-900 via-[#070b12] to-[#04060a]">
            <div className="max-w-3xl mx-auto w-full space-y-5">
              {/* Nation Banner */}
              <div className="flex items-center gap-5 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 shadow-2xl">
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center font-bold font-serif-title text-3xl text-white shadow-2xl border-2 border-amber-400/40 flex-shrink-0"
                  style={{ backgroundColor: selectedNation.flagColor }}
                >
                  {selectedNation.name.substring(0, 1)}
                </div>
                <div>
                  <div className="flex items-center gap-2.5">
                    <h1 className="text-2xl font-bold font-serif-title text-slate-100">{selectedNation.name}</h1>
                    {selectedNation.isGreatPower && (
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/50 px-2 py-0.5 rounded-full font-semibold">
                        ★ ВЕЛИКАЯ ДЕРЖАВА
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                    <span>{selectedNation.governmentType}</span>
                    <span>·</span>
                    <span className="text-amber-300">{selectedNation.religion}</span>
                    <span>·</span>
                    <span>Культура: {selectedNation.culture}</span>
                  </div>
                </div>
              </div>

              {/* Leader & Starting Strength */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center gap-2 font-bold text-slate-200 text-sm border-b border-slate-800 pb-1.5">
                    <Crown className="w-4 h-4 text-amber-400" />
                    Лидер: {selectedNation.ruler.name}
                  </div>
                  <div className="text-xs text-slate-400">
                    Принадлежность: <strong className="text-slate-200">{selectedNation.ruler.dynasty}</strong> ({selectedNation.ruler.age} лет)
                  </div>
                  <div className="flex flex-wrap gap-1 pt-1">
                    {selectedNation.ruler.traits.map(trait => (
                      <span key={trait} className="text-[10px] bg-slate-950/80 border border-slate-700 text-amber-300 px-2 py-0.5 rounded">
                        {trait}
                      </span>
                    ))}
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center font-mono-num pt-2">
                    <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Управл.</div>
                      <div className="text-base font-bold text-emerald-400">{selectedNation.ruler.adminSkill}</div>
                    </div>
                    <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Дипломат.</div>
                      <div className="text-base font-bold text-sky-400">{selectedNation.ruler.diploSkill}</div>
                    </div>
                    <div className="bg-slate-950/80 p-2 rounded border border-slate-800">
                      <div className="text-[10px] text-slate-400">Воен. дело</div>
                      <div className="text-base font-bold text-rose-400">{selectedNation.ruler.milSkill}</div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800 space-y-2 font-mono-num text-xs">
                  <div className="flex items-center gap-2 font-bold text-slate-200 text-sm border-b border-slate-800 pb-1.5 font-sans">
                    <Coins className="w-4 h-4 text-amber-400" /> Стартовые показатели эпохи
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Казна:</span>
                    <span className="text-amber-300 font-bold">{selectedNation.treasury.toLocaleString()} золотых / кредитов</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Рекрутский резерв:</span>
                    <span className="text-slate-100">{selectedNation.manpower.toLocaleString()} чел.</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Подвластных провинций:</span>
                    <span className="text-slate-100">{ownProvinces.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Стабильность:</span>
                    <span className="text-emerald-400 font-bold">+{selectedNation.stability}%</span>
                  </div>
                  {selectedNation.rivalIds && selectedNation.rivalIds.length > 0 && (
                    <div className="flex justify-between pt-1 border-t border-slate-800/80">
                      <span className="text-slate-400 font-sans flex items-center gap-1">
                        <Flame className="w-3 h-3 text-rose-400" /> Соперники:
                      </span>
                      <span className="text-rose-300 font-sans truncate max-w-[180px]">
                        {selectedNation.rivalIds.map(rid => eraSetup.nations[rid]?.name || rid).join(', ')}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* National Idea & Technologies */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-amber-950/30 border border-amber-500/40 p-4 rounded-xl space-y-1.5">
                  <div className="flex items-center gap-2 font-bold text-amber-300 text-sm">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    Национальная традиция: {selectedNation.nationalIdea}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedNation.nationalIdeaDesc}
                  </p>
                </div>

                <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 font-bold text-slate-200 text-sm border-b border-slate-800 pb-1">
                    <Shield className="w-4 h-4 text-sky-400" />
                    Ключевые технологии и доктрины
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {selectedNation.researchedTechs.map(techId => {
                      const tech = eraSetup.technologies[techId];
                      return (
                        <span key={techId} className="px-2 py-0.5 rounded text-[11px] bg-slate-950/80 border border-slate-700/80 text-sky-300 font-medium">
                          {tech?.name || techId}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Territory Borders Preview */}
              <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-300 border-b border-slate-800 pb-1">
                  <span className="font-bold flex items-center gap-1.5">
                    <Compass className="w-4 h-4 text-amber-400" /> Подвластные провинции ({ownProvinces.length}):
                  </span>
                  <span className="text-[11px] text-slate-400">Столица: <strong className="text-amber-300">{eraSetup.provinces[selectedNation.capitalProvinceId]?.name}</strong></span>
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                  {ownProvinces.map(prov => (
                    <span
                      key={prov.id}
                      className={`text-[10px] px-2 py-0.5 rounded ${prov.capital ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 font-bold' : 'bg-slate-950/60 text-slate-300 border border-slate-800'}`}
                    >
                      {prov.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Start Game Action */}
            <div className="max-w-3xl mx-auto w-full pt-4 flex justify-end">
              <button
                onClick={() => onStart(selectedNation.id, selectedEraId)}
                className="flex items-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-base rounded-xl shadow-2xl transition-all font-serif-title tracking-wider cursor-pointer"
              >
                <span>Начать правление за {selectedNation.name} ({currentEra.year} г.)</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
