import React from 'react';
import { useGame } from '../../context/GameContext';
import { Swords, Shield, Award, UserCheck, X } from 'lucide-react';
import { getTotalTroopCount } from '../../utils/combat';

export const BattleModal: React.FC = () => {
  const { state, closeActiveBattleModal } = useGame();
  const battle = state.activeBattle;
  if (!battle) return null;

  const prov = state.provinces[battle.provinceId];
  const attNation = state.nations[battle.attackerNationId];
  const defNation = state.nations[battle.defenderNationId];
  const attArmy = state.armies[battle.attackerArmyId];
  const defArmy = state.armies[battle.defenderArmyId];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-xl bg-slate-950 border border-rose-500/50 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-950/80 via-slate-900 to-rose-950/80 border-b border-rose-500/40 p-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Swords className="w-5 h-5 text-rose-400 animate-pulse" />
            <div>
              <h2 className="text-base font-bold font-serif-title text-slate-100">
                Сражение при {prov?.name || 'провинции'} (День {battle.day})
              </h2>
              <div className="text-[10px] text-slate-400">Ландшафт поля боя: {battle.terrain}</div>
            </div>
          </div>
          <button
            onClick={closeActiveBattleModal}
            className="text-slate-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tactical Battlefield Grid */}
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Attacker Side */}
            <div className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 space-y-2.5">
              <div className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: attNation?.flagColor }}
                />
                <span className="font-bold text-slate-100 text-xs">{attNation?.name}</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Генерал: <strong className="text-slate-200">{attArmy?.general?.name || 'Офицер'}</strong>
              </div>
              <div className="font-mono-num text-[11px] space-y-1">
                <div className="flex justify-between">
                  <span>Войск в строю:</span>
                  <span className="text-slate-100 font-bold">{attArmy ? getTotalTroopCount(attArmy).toLocaleString() : 0}</span>
                </div>
                <div className="flex justify-between text-rose-400">
                  <span>Потери:</span>
                  <span>-{battle.attackerLosses.toLocaleString()}</span>
                </div>
              </div>

              {/* Morale bar */}
              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                  <span>Боевой дух:</span>
                  <span className="font-mono-num font-bold text-slate-200">{battle.attackerMorale}%</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-rose-500 h-full rounded-full transition-all"
                    style={{ width: `${battle.attackerMorale}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Defender Side */}
            <div className="bg-slate-900/80 p-3.5 rounded-lg border border-slate-800 space-y-2.5">
              <div className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: defNation?.flagColor }}
                />
                <span className="font-bold text-slate-100 text-xs">{defNation?.name}</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Генерал: <strong className="text-slate-200">{defArmy?.general?.name || 'Офицер'}</strong>
              </div>
              <div className="font-mono-num text-[11px] space-y-1">
                <div className="flex justify-between">
                  <span>Войск в строю:</span>
                  <span className="text-slate-100 font-bold">{defArmy ? getTotalTroopCount(defArmy).toLocaleString() : 0}</span>
                </div>
                <div className="flex justify-between text-rose-400">
                  <span>Потери:</span>
                  <span>-{battle.defenderLosses.toLocaleString()}</span>
                </div>
              </div>

              {/* Morale bar */}
              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                  <span>Боевой дух:</span>
                  <span className="font-mono-num font-bold text-slate-200">{battle.defenderMorale}%</span>
                </div>
                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-sky-500 h-full rounded-full transition-all"
                    style={{ width: `${battle.defenderMorale}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Status or Victory */}
          {battle.resolved ? (
            <div className="bg-emerald-950/40 border border-emerald-700 p-3 rounded-lg text-center space-y-1">
              <div className="font-bold text-emerald-300 text-sm flex items-center justify-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" />
                Сражение окончено! Победитель: {state.nations[battle.victorNationId || '']?.name}
              </div>
              <div className="text-xs text-slate-300">
                Разгромленный противник отступил в соседние земли.
              </div>
            </div>
          ) : (
            <div className="text-center text-xs text-slate-400 italic">
              Битва в разгаре! Каждый игровой день залпы орудий и кавалерийские атаки решают исход...
            </div>
          )}

          <div className="text-center pt-2">
            <button
              onClick={closeActiveBattleModal}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-6 py-2 rounded-lg font-semibold text-xs transition-colors"
            >
              Закрыть донесение
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
