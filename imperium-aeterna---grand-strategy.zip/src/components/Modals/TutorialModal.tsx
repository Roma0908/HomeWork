import React, { useState } from 'react';
import { Compass, Coins, Shield, Swords, BookOpen, Users, ArrowRight, ArrowLeft, Check, X } from 'lucide-react';

interface TutorialModalProps {
  onClose: () => void;
}

const TUTORIAL_STEPS = [
  {
    title: '1. Управление Картой и Режимы',
    icon: Compass,
    content: `
      • Перемещение: зажмите левую кнопку мыши на карте и тяните в любую сторону.
      • Масштаб: крутите колесико мыши или используйте кнопки (+) и (-) в правом нижнем углу.
      • Режимы карты: в верхней панели переключайтесь между «Политическая» (границы стран), «Ресурсы» (производство товаров), «Население» (плотность жителей) и «Военная» (крепости).
    `
  },
  {
    title: '2. Провинции и Экономика',
    icon: Coins,
    content: `
      • Клик по провинции открывает подробную нижнюю панель.
      • Развитие: повышайте уровень развития провинции за золото, чтобы увеличить налоги и прирост жителей.
      • Постройки: возводите Рынки (+налоги), Мануфактуры (+производство), Казармы (+рекруты) и Бастионы (+оборона).
      • Казна: во вкладке «Экономика» слева регулируйте налоговую ставку и при необходимости берите банковские займы.
    `
  },
  {
    title: '3. Армии и Ведение Войны',
    icon: Shield,
    content: `
      • Найм войск: во вкладке «Армия» слева или в нижней панели провинции нанимайте Линейную пехоту, Кавалерию, Артиллерию и Гвардию.
      • Приказ на марш: выберите армию (кликните на жетон на карте или в списке), затем в панели нажмите кнопку марша в соседнюю провинцию.
      • Сражения: когда вражеские армии встречаются в одной провинции, начинается битва с фазами огня и натиска.
      • Осада: войдя во вражескую провинцию, армия начинает осаду. После падения бастиона провинция переходит под ваш контроль.
    `
  },
  {
    title: '4. Дипломатия и Мирные Договоры',
    icon: Swords,
    content: `
      • Вкладка «Дипломатия» слева показывает все 20+ держав континента.
      • Вы можете объявлять войны, заключать военные союзы, пакты о ненападении и торговые соглашения.
      • Подарки и посольства (+25 к отношениям) помогают склонить соседей к альянсу.
      • В ходе войны захватывайте столицы врагов: накопленный счет победы позволяет в мирном договоре аннексировать провинции!
    `
  },
  {
    title: '5. Технологии и Сословия',
    icon: BookOpen,
    content: `
      • Вкладка «Технологии» содержит 4 ветви: Военное дело, Экономика, Администрация и Наука.
      • Очки науки накапливаются ежемесячно благодаря мудрости монарха и университетам.
      • Вкладка «Политика» позволяет управлять 6 сословиями: Дворяне, Армия, Торговцы, Рабочие, Крестьяне и Ученые. Балансируйте их лояльность ради стабильности трона.
    `
  }
];

export const TutorialModal: React.FC<TutorialModalProps> = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const step = TUTORIAL_STEPS[currentStep];
  const Icon = step.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-950 border border-amber-500/40 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-serif-title text-slate-100">{step.title}</h2>
              <div className="text-[11px] text-slate-400">Шаг {currentStep + 1} из {TUTORIAL_STEPS.length}</div>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div className="text-xs leading-relaxed text-slate-300 font-sans whitespace-pre-line bg-slate-900/60 p-4 rounded-lg border border-slate-800">
            {step.content.trim()}
          </div>

          {/* Progress dots */}
          <div className="flex justify-center gap-2 pt-2">
            {TUTORIAL_STEPS.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentStep(i)}
                className={`w-2 h-2 rounded-full transition-all ${currentStep === i ? 'bg-amber-400 w-5' : 'bg-slate-700'}`}
              />
            ))}
          </div>

          {/* Controls */}
          <div className="flex justify-between items-center pt-2 border-t border-slate-800">
            <button
              onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
              disabled={currentStep === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 rounded text-xs text-slate-300 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Назад
            </button>

            {currentStep < TUTORIAL_STEPS.length - 1 ? (
              <button
                onClick={() => setCurrentStep(prev => prev + 1)}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors shadow"
              >
                Далее <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs transition-colors shadow"
              >
                Начать игру <Check className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
