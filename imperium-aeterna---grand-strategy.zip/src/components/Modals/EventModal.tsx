import React from 'react';
import { useGame } from '../../context/GameContext';
import { Sparkles, AlertCircle, Coins, Flame } from 'lucide-react';

export const EventModal: React.FC = () => {
  const { state, handleEventOption } = useGame();
  const event = state.activeEvent;
  if (!event) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-950 border border-amber-500/50 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border-b border-amber-500/30 p-4 text-center">
          <div className="text-[10px] uppercase font-bold text-amber-400 tracking-widest mb-1 flex items-center justify-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> Историческое событие державы
          </div>
          <h2 className="text-xl font-bold font-serif-title text-slate-100">{event.title}</h2>
        </div>

        {/* Description Body */}
        <div className="p-5 space-y-4">
          <p className="text-sm leading-relaxed text-slate-300 font-serif text-justify border-l-2 border-amber-500/50 pl-3 py-1">
            «{event.description}»
          </p>

          <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold pt-2">
            Решение Вашего Величества:
          </div>

          {/* Options */}
          <div className="space-y-2">
            {event.options.map((opt, idx) => (
              <button
                key={opt.actionId}
                onClick={() => handleEventOption(opt.actionId)}
                className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-400 p-3 rounded-lg text-left transition-all group"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-100 group-hover:text-amber-300 transition-colors text-xs">
                    {String.fromCharCode(65 + idx)}. {opt.text}
                  </span>
                </div>
                <div className="text-[11px] text-amber-400/90 font-mono-num mt-1">
                  ↳ {opt.tooltip}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
