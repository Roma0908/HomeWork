import React, { useState } from 'react';
import { useGame } from '../../context/GameContext';
import { Handshake, Award, Shield, Check, X } from 'lucide-react';

interface PeaceDealModalProps {
  warId: string;
  onClose: () => void;
}

export const PeaceDealModal: React.FC<PeaceDealModalProps> = ({ warId, onClose }) => {
  const { state, proposePeace } = useGame();
  const war = state.wars.find(w => w.id === warId);
  if (!war) return null;

  const isAttacker = war.attackers.includes(state.playerNationId);
  const enemyNationId = isAttacker ? war.defenders[0] : war.attackers[0];
  const enemy = state.nations[enemyNationId];
  if (!enemy) return null;

  // Enemy provinces that can be demanded
  const enemyProvinces = Object.values(state.provinces).filter(p => p.ownerNationId === enemyNationId);
  const [demandedProvinces, setDemandedProvinces] = useState<string[]>([]);

  const toggleProvinceDemand = (provId: string) => {
    if (demandedProvinces.includes(provId)) {
      setDemandedProvinces(demandedProvinces.filter(id => id !== provId));
    } else {
      setDemandedProvinces([...demandedProvinces, provId]);
    }
  };

  const handleSignPeace = () => {
    proposePeace(warId, demandedProvinces);
    onClose();
  };

  // Cost calculation
  const totalWarScoreCost = demandedProvinces.length * 25;
  const currentWarScore = isAttacker ? war.warScore : -war.warScore;
  const canDemand = currentWarScore >= totalWarScoreCost;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-950 border border-slate-700 rounded-xl shadow-2xl overflow-hidden text-slate-200">
        {/* Header */}
        <div className="bg-slate-900 border-b border-slate-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Handshake className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold font-serif-title text-slate-100">
                Мирный трактат с {enemy.name}
              </h2>
              <div className="text-[11px] text-slate-400">
                Военный счет победы: <strong className={currentWarScore >= 0 ? 'text-emerald-400 font-mono-num' : 'text-rose-400 font-mono-num'}>
                  {currentWarScore > 0 ? `+${currentWarScore}%` : `${currentWarScore}%`}
                </strong>
              </div>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <p className="text-slate-300 leading-relaxed">
            Выберите провинции неприятеля, которые перейдут под нашу корону. Каждая провинция требует очков военного счета.
          </p>

          <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
            <div className="font-bold text-slate-200 flex justify-between">
              <span>Территориальные требования:</span>
              <span className="font-mono-num text-amber-400">Требуется: {totalWarScoreCost}%</span>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {enemyProvinces.map(prov => {
                const isSelected = demandedProvinces.includes(prov.id);
                return (
                  <div
                    key={prov.id}
                    onClick={() => toggleProvinceDemand(prov.id)}
                    className={`p-2 rounded border cursor-pointer flex items-center justify-between transition-colors ${isSelected ? 'bg-amber-500/20 border-amber-400' : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/60'}`}
                  >
                    <div>
                      <div className="font-semibold text-slate-200 text-xs">{prov.name}</div>
                      <div className="text-[10px] text-slate-400">
                        Население: {prov.population.toLocaleString()} · {prov.resource}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono-num text-amber-300">25% счета</span>
                      <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSelected ? 'bg-amber-400 border-amber-400 text-slate-950' : 'border-slate-600'}`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Отмена
            </button>
            <button
              onClick={handleSignPeace}
              disabled={!canDemand && demandedProvinces.length > 0}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white px-5 py-2 rounded-lg font-bold shadow-lg transition-colors flex items-center gap-1.5"
            >
              <Award className="w-4 h-4" /> Заключить мир
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
