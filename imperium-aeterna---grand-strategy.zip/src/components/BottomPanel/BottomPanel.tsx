import React from 'react';
import { useGame } from '../../context/GameContext';
import { ProvincePanel } from './ProvincePanel';
import { ArmyControlPanel } from './ArmyControlPanel';

export const BottomPanel: React.FC = () => {
  const { state } = useGame();
  const { selectedArmyId, selectedProvinceId } = state;

  if (selectedArmyId) {
    return (
      <div className="absolute bottom-0 left-0 right-0 z-20 pointer-events-auto">
        <ArmyControlPanel />
      </div>
    );
  }

  if (selectedProvinceId) {
    return (
      <div className="absolute bottom-0 left-0 right-0 z-20 pointer-events-auto">
        <ProvincePanel />
      </div>
    );
  }

  return null;
};
