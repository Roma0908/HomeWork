import React from 'react';
import { useGame } from '../../context/GameContext';
import { Building } from '../../types/game';
import {
  Landmark,
  Shield,
  TrendingUp,
  Hammer,
  Sparkles,
  Users,
  Compass,
  Check,
  UserCheck,
  Flame,
  Package
} from 'lucide-react';

const AVAILABLE_BUILDINGS = [
  { id: 'market', name: 'Рынок и Торговая палата', cost: 100, desc: '+25% к сбору налогов и ярмарочной пошлине' },
  { id: 'workshop', name: 'Мануфактура / Кузница', cost: 130, desc: '+35% к производству сырья провинции' },
  { id: 'barracks', name: 'Казармы и Арсенал', cost: 120, desc: '+50% к скорости пополнения рекрутов' },
  { id: 'fort', name: 'Каменный бастион', cost: 180, desc: 'Защита от осад, требует врагам много времени на штурм' },
  { id: 'academy', name: 'Университет / Академия', cost: 200, desc: '+10% к очкам науки и снижение бунтов' }
] as const;

export const ProvincePanel: React.FC = () => {
  const { state, buildBuilding, upgradeDevelopment, selectProvince, switchPlayerNation } = useGame();
  const { selectedProvinceId, provinces, nations, playerNationId, armies } = state;

  if (!selectedProvinceId) return null;
  const prov = provinces[selectedProvinceId];
  if (!prov) return null;

  const owner = nations[prov.ownerNationId];
  const isPlayerOwned = prov.ownerNationId === playerNationId;
  const devCost = prov.developmentLevel * 40;
  const canUpgradeDev = isPlayerOwned && (nations[playerNationId]?.treasury || 0) >= devCost;

  // Stationed armies
  const stationedArmies = Object.values(armies).filter(a => a.provinceId === prov.id);

  return (
    <div className="bg-slate-950/95 border-t border-slate-800 shadow-2xl p-4 text-xs text-slate-300 backdrop-blur-md max-w-4xl mx-auto rounded-t-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3">
        <div className="flex items-center gap-2.5">
          <div
            className="w-5 h-5 rounded flex items-center justify-center font-bold text-[10px] text-white border border-white/20"
            style={{ backgroundColor: owner?.flagColor || '#475569' }}
          >
            {owner?.name.substring(0, 1) || '·'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-slate-100 font-serif-title">{prov.name}</h3>
              {prov.capital && (
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.5 rounded font-semibold">
                  Столица
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <span>Владелец: <strong className="text-slate-200">{owner?.name || 'Ничейная'}</strong></span>
              {prov.occupiedBy && (
                <span className="text-rose-400 font-semibold">
                  · Оккупировано: {nations[prov.occupiedBy]?.name}
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isPlayerOwned && owner && (
            <button
              onClick={() => switchPlayerNation(owner.id)}
              className="bg-indigo-600/30 hover:bg-indigo-600/60 border border-indigo-500/60 text-indigo-200 font-semibold px-2.5 py-1 rounded text-[11px] flex items-center gap-1.5 transition-colors"
              title="Переключиться и играть за эту державу"
            >
              <UserCheck className="w-3.5 h-3.5 text-indigo-400" />
              <span>Играть за {owner.name}</span>
            </button>
          )}

          <button
            onClick={() => selectProvince(null)}
            className="text-slate-400 hover:text-white p-1 text-sm"
          >
            ✕
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Column 1: Demographics & Economy */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="font-bold text-slate-200 flex items-center gap-1.5 border-b border-slate-800 pb-1">
            <Users className="w-3.5 h-3.5 text-sky-400" /> Демография и экономика
          </div>
          <div className="space-y-1 font-mono-num text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Население:</span>
              <span className="text-slate-100">{prov.population.toLocaleString()} жителей</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Производимый ресурс:</span>
              <span className="text-amber-300 font-sans">{prov.resource.toUpperCase()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Налоговая база:</span>
              <span className="text-slate-100">{prov.taxBase} 🪙</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Производство товаров:</span>
              <span className="text-slate-100">{prov.productionBase}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Лимит снабжения:</span>
              <span className="text-emerald-400 font-sans">{(prov.supplyLimit || 40000).toLocaleString()} солдат</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Ландшафт:</span>
              <span className="text-slate-300 font-sans">{prov.terrain}</span>
            </div>
          </div>
        </div>

        {/* Column 2: Development & Infrastructure */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="font-bold text-slate-200 flex items-center justify-between border-b border-slate-800 pb-1">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Развитие провинции
            </span>
            <span className="font-mono-num font-bold text-amber-400">Ур. {prov.developmentLevel}</span>
          </div>
          <div className="text-[11px] text-slate-400">
            Укрепление инфраструктуры увеличивает население, налоговый сбор и добычу сырья на 15%.
          </div>
          {isPlayerOwned ? (
            <button
              onClick={() => upgradeDevelopment(prov.id)}
              disabled={!canUpgradeDev || prov.developmentLevel >= 10}
              className="w-full bg-amber-600/30 hover:bg-amber-600/50 border border-amber-600/60 disabled:opacity-30 text-amber-200 font-semibold py-1.5 rounded transition-colors"
            >
              {prov.developmentLevel >= 10 ? 'Максимальное развитие' : `Развить провинцию (${devCost} 🪙)`}
            </button>
          ) : (
            <div className="text-[11px] text-slate-400 italic">
              Принадлежит державе: <strong className="text-slate-200">{owner?.name}</strong>
            </div>
          )}
          <div className="text-[11px] flex justify-between pt-1">
            <span className="text-slate-400">Фортификация:</span>
            <span className="text-rose-400 font-mono-num font-bold">Бастион Ур. {prov.fortLevel}</span>
          </div>
        </div>

        {/* Column 3: Buildings Construction */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="font-bold text-slate-200 flex items-center gap-1.5 border-b border-slate-800 pb-1">
            <Hammer className="w-3.5 h-3.5 text-indigo-400" /> Постройки ({prov.buildings.length}/5)
          </div>
          <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
            {AVAILABLE_BUILDINGS.map(b => {
              const hasBuilt = prov.buildings.includes(b.id);
              const canAfford = isPlayerOwned && (nations[playerNationId]?.treasury || 0) >= b.cost;

              return (
                <div key={b.id} className="flex items-center justify-between bg-slate-950/60 p-1.5 rounded border border-slate-800/80">
                  <div>
                    <div className="font-medium text-slate-200 text-[11px]">{b.name}</div>
                    <div className="text-[9px] text-slate-400">{b.desc}</div>
                  </div>
                  {hasBuilt ? (
                    <span className="text-emerald-400 text-[11px] font-semibold flex items-center gap-1">
                      <Check className="w-3 h-3" /> Построено
                    </span>
                  ) : isPlayerOwned ? (
                    <button
                      onClick={() => buildBuilding(prov.id, b.id)}
                      disabled={!canAfford}
                      className="bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-amber-300 px-2 py-0.5 rounded text-[10px] font-mono-num transition-colors whitespace-nowrap ml-2"
                    >
                      {b.cost} 🪙
                    </button>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
