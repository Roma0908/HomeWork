import React from 'react';
import { useGame } from '../../context/GameContext';
import { Shield, Swords, UserCheck, Navigation, ArrowRight } from 'lucide-react';
import { getTotalTroopCount, calculateArmyPower } from '../../utils/combat';

export const ArmyControlPanel: React.FC = () => {
  const { state, selectArmy, moveArmy } = useGame();
  const { selectedArmyId, armies, provinces, nations, playerNationId } = state;

  if (!selectedArmyId) return null;
  const army = armies[selectedArmyId];
  if (!army) return null;

  const currentProv = provinces[army.provinceId];
  const nation = nations[army.nationId];
  const isPlayerArmy = army.nationId === playerNationId;
  const totalTroops = getTotalTroopCount(army);
  const power = calculateArmyPower(army);

  // Neighbors for movement
  const neighbors = currentProv ? currentProv.neighborIds.map(nid => provinces[nid]).filter(Boolean) : [];

  return (
    <div className="bg-slate-950/95 border-t border-slate-800 shadow-2xl p-4 text-xs text-slate-300 backdrop-blur-md max-w-4xl mx-auto rounded-t-xl">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3">
        <div className="flex items-center gap-3">
          <div
            className="w-5 h-5 rounded flex items-center justify-center font-bold text-xs text-white"
            style={{ backgroundColor: nation?.flagColor || '#334155' }}
          >
            {nation?.name?.substring(0, 1) || 'A'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-slate-100 font-serif-title">{army.name}</h3>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded ${army.status === 'fighting' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : army.status === 'besieging' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : army.isMoving ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40' : 'bg-slate-800 text-slate-300'}`}>
                {army.status === 'fighting' ? '⚔ В бою' : army.status === 'besieging' ? '🏰 Ведет осаду' : army.isMoving ? '🚩 На марше' : 'Гарнизон'}
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              Дислокация: <strong className="text-amber-300">{currentProv?.name}</strong>
            </div>
          </div>
        </div>

        <button
          onClick={() => selectArmy(null)}
          className="text-slate-400 hover:text-white p-1 text-sm"
        >
          ✕
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Column 1: Army Strength & General */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="font-bold text-slate-200 flex items-center justify-between border-b border-slate-800 pb-1">
            <span className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-rose-400" /> Численность и командир
            </span>
            <span className="font-mono-num font-bold text-rose-400">{totalTroops.toLocaleString()} воинов</span>
          </div>

          <div className="text-[11px] space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Полководец:</span>
              <span className="text-slate-100 font-semibold">{army.general?.name || 'Безымянный офицер'}</span>
            </div>
            {army.general && (
              <div className="flex justify-between font-mono-num text-[10px] text-slate-400">
                <span>Атака: <strong className="text-slate-200">+{army.general.attack}</strong></span>
                <span>Оборона: <strong className="text-slate-200">+{army.general.defense}</strong></span>
                <span>Маневр: <strong className="text-slate-200">+{army.general.maneuver}</strong></span>
              </div>
            )}
            <div className="flex justify-between font-mono-num">
              <span className="text-slate-400">Общая боевая мощь:</span>
              <span className="text-amber-400 font-bold">{power}</span>
            </div>
          </div>

          {/* Morale bar */}
          <div className="pt-1">
            <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
              <span>Боевой дух:</span>
              <span className="font-mono-num font-semibold text-slate-200">{army.morale}%</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all"
                style={{ width: `${army.morale}%` }}
              />
            </div>
          </div>
        </div>

        {/* Column 2: Units Breakdown */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="font-bold text-slate-200 flex items-center gap-1.5 border-b border-slate-800 pb-1">
            <Swords className="w-3.5 h-3.5 text-amber-400" /> Состав соединений
          </div>
          <div className="space-y-1 font-mono-num text-[11px]">
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Линейная пехота:</span>
              <span className="text-slate-100 font-semibold">{army.units.infantry.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Кавалерия:</span>
              <span className="text-slate-100 font-semibold">{army.units.cavalry.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Полевые орудия:</span>
              <span className="text-slate-100 font-semibold">{army.units.artillery.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Осадные машины:</span>
              <span className="text-slate-100 font-semibold">{army.units.siege.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400 font-sans">Гвардейцы:</span>
              <span className="text-amber-300 font-semibold">{army.units.elite.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Column 3: March Orders */}
        <div className="bg-slate-900/60 p-3 rounded-lg border border-slate-800 space-y-2">
          <div className="font-bold text-slate-200 flex items-center gap-1.5 border-b border-slate-800 pb-1">
            <Navigation className="w-3.5 h-3.5 text-sky-400" /> Приказ о наступлении / марше
          </div>
          {isPlayerArmy ? (
            <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
              <div className="text-[10px] text-slate-400">Выберите соседнюю провинцию для перехода:</div>
              {neighbors.map(neighbor => (
                <button
                  key={neighbor.id}
                  onClick={() => moveArmy(army.id, neighbor.id)}
                  disabled={army.isMoving || army.status === 'fighting'}
                  className="w-full bg-slate-950/80 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/60 p-1.5 rounded flex items-center justify-between text-[11px] transition-colors"
                >
                  <span className="font-medium text-slate-200">{neighbor.name}</span>
                  <span className="text-amber-400 flex items-center gap-1 font-semibold text-[10px]">
                    Выступить <ArrowRight className="w-3 h-3" />
                  </span>
                </button>
              ))}
            </div>
          ) : (
            <div className="text-[11px] text-slate-500 italic">Армия чужого государства</div>
          )}
        </div>
      </div>
    </div>
  );
};
