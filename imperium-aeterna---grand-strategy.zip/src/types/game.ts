export type ResourceType =
  | 'grain'
  | 'iron'
  | 'coal'
  | 'gold'
  | 'tar'
  | 'timber'
  | 'stone'
  | 'horses';

export type TerrainType = 'plains' | 'mountains' | 'hills' | 'forest' | 'marsh' | 'coastal';

export type MapMode = 'political' | 'resources' | 'population' | 'military' | 'stability' | 'diplomatic';

export type DiplomaticAttitude =
  | 'nemesis'       // Заклятый враг (-80 to -100)
  | 'rival'         // Соперник (-40 to -79)
  | 'hostile'       // Враждебный (-20 to -39)
  | 'neutral'       // Нейтральный (-19 to +29)
  | 'friendly'      // Дружественный (+30 to +69)
  | 'allied';       // Союзный / Братский (+70 to +100)

export type AIPersonality =
  | 'expansionist'
  | 'diplomatic'
  | 'militarist'
  | 'commercial'
  | 'isolationist';

export interface Ruler {
  name: string;
  dynasty: string;
  age: number;
  traits: string[];
  adminSkill: number; // 1-6
  diploSkill: number; // 1-6
  milSkill: number;   // 1-6
  popularity: number; // 0-100
}

export interface Estate {
  id: 'nobility' | 'military' | 'merchants' | 'workers' | 'peasants' | 'intellectuals';
  name: string;
  iconName: string;
  loyalty: number;    // 0-100
  influence: number;  // 0-100
  demands: string;
  bonus: string;
}

export interface Building {
  id: 'market' | 'workshop' | 'barracks' | 'fort' | 'academy';
  name: string;
  cost: number;
  buildDays: number;
  description: string;
}

export interface Province {
  id: string;
  name: string;
  ownerNationId: string;
  coreNationId: string;
  capital: boolean;
  population: number;
  taxBase: number;
  productionBase: number;
  resource: ResourceType;
  terrain: TerrainType;
  developmentLevel: number; // 1-10
  fortLevel: number;        // 0-4
  barracksLevel: number;    // 0-3
  buildings: Array<'market' | 'workshop' | 'barracks' | 'fort' | 'academy'>;
  unrest: number;           // 0-100
  center: [number, number]; // [x, y] on map canvas
  svgPath: string;          // SVG polygon / path
  neighborIds: string[];
  occupiedBy?: string;      // Nation ID occupying it during war
  siegeProgress?: number;   // 0-100
  supplyLimit: number;      // Max troop count before attrition (e.g. 25000)
  claimsBy: string[];       // Nation IDs that have active claims
}

export interface UnitCounts {
  infantry: number;
  cavalry: number;
  artillery: number;
  siege: number;
  elite: number;
}

export interface General {
  name: string;
  attack: number;
  defense: number;
  maneuver: number;
  moraleBuff: number;
}

export interface Army {
  id: string;
  name: string;
  nationId: string;
  provinceId: string;
  targetProvinceId?: string;
  path: string[];
  movementProgress: number; // 0-100%
  units: UnitCounts;
  morale: number;           // 0-100
  maxMorale: number;
  general?: General;
  isMoving: boolean;
  status: 'idle' | 'moving' | 'fighting' | 'besieging';
  isRebel?: boolean;
  attritionRate?: number;   // % attrition per month if out of supply
}

export interface Nation {
  id: string;
  name: string;
  adjective: string;
  flagColor: string;
  secondaryColor: string;
  emblem: string; // SVG icon symbol
  capitalProvinceId: string;
  ruler: Ruler;
  governmentType: string;
  culture: string;
  religion: string;
  nationalIdea: string;
  nationalIdeaDesc: string;
  treasury: number;
  taxRate: number; // 0.5 to 1.5 multiplier
  resources: Record<ResourceType, number>;
  stability: number; // -100 to +100
  prestige: number;
  manpower: number;
  maxManpower: number;
  techPoints: number;
  diplomaticPoints: number;
  aiPersonality: AIPersonality;
  isPlayer: boolean;
  activeTechId?: string;
  techProgress?: number;
  researchedTechs: string[];
  estates: Estate[];
  loans: number; // Count of loans (each gives 200 gold, +10 monthly interest)
  infamy: number; // 0 to 100 (Aggressive Expansion / Бесчестье, triggers coalitions at >50)
  warExhaustion: number; // 0 to 100 (Военная усталость)
  rivalIds: string[]; // List of declared rivals
  claims: string[]; // Province IDs where this nation has fabricated claims
  isGreatPower?: boolean;
}

export interface DiplomaticRelation {
  opinion: number; // -100 to +100
  attitude: DiplomaticAttitude;
  attitudeReason: string;
  isAllied: boolean;
  hasNonAggression: boolean;
  hasTradeAgreement: boolean;
  isAtWar: boolean;
  hasSanctions: boolean;
  isVassal: boolean; // if subject to the other
  isDeclaredRival: boolean;
  guaranteeIndependence: boolean;
  militaryAidSent: boolean;
  truceDaysRemaining: number;
}

export interface War {
  id: string;
  name: string;
  attackers: string[]; // Nation IDs
  defenders: string[]; // Nation IDs
  warGoal: string;
  warScore: number;    // -100 (attackers losing) to +100 (attackers winning)
  startDate: string;
  casualties: Record<string, number>;
  battlesCount?: number;
}

export interface Battle {
  id: string;
  provinceId: string;
  attackerArmyId: string;
  defenderArmyId: string;
  attackerNationId: string;
  defenderNationId: string;
  attackerLosses: number;
  defenderLosses: number;
  attackerMorale: number;
  defenderMorale: number;
  day: number;
  terrain: TerrainType;
  resolved: boolean;
  victorNationId?: string;
}

export interface Technology {
  id: string;
  name: string;
  category: 'military' | 'economy' | 'administration' | 'science';
  tier: number;
  cost: number;
  description: string;
  effects: string;
  modifier: {
    moraleBonus?: number;
    infantryAttack?: number;
    cavalryAttack?: number;
    artilleryAttack?: number;
    taxEfficiency?: number;
    tradeEfficiency?: number;
    productionEfficiency?: number;
    manpowerMaxBonus?: number;
    stabilityCostReduction?: number;
    researchSpeed?: number;
    fortDefense?: number;
  };
}

export interface GameEventOption {
  text: string;
  tooltip: string;
  actionId: string;
}

export interface GameEvent {
  id: string;
  title: string;
  category: 'crisis' | 'diplomatic' | 'economic' | 'cultural' | 'military';
  description: string;
  options: GameEventOption[];
}

export interface GameNotification {
  id: string;
  date: string;
  title: string;
  message: string;
  type: 'war' | 'peace' | 'diplomacy' | 'tech' | 'event' | 'economy';
}

export type EraId = 'victorian_1836' | 'ww2_1939' | 'modern_2026' | 'renaissance_1500';

export interface HistoricalEra {
  id: EraId;
  name: string;
  year: number;
  startDate: { day: number; month: number; year: number };
  subtitle: string;
  description: string;
  featuredNations: string[];
  bannerIcon: string;
}

export interface GameState {
  currentEra: EraId;
  currentDate: {
    day: number;
    month: number;
    year: number;
  };
  gameSpeed: number; // 0 = pause, 1 = 1x, 2 = 2x, 5 = 5x, 10 = 10x, 20 = 20x
  isPaused: boolean;
  playerNationId: string;
  nations: Record<string, Nation>;
  provinces: Record<string, Province>;
  armies: Record<string, Army>;
  wars: War[];
  battles: Battle[];
  diplomacy: Record<string, Record<string, DiplomaticRelation>>; // [nationA][nationB]
  technologies: Record<string, Technology>;
  notifications: GameNotification[];
  activeEvent: GameEvent | null;
  activeBattle: Battle | null;
  selectedProvinceId: string | null;
  selectedArmyId: string | null;
  mapMode: MapMode;
  audioEnabled: boolean;
  volume: number;
}
