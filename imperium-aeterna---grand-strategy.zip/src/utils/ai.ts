import { GameState, Nation, Province, Army, Technology, War } from '../types/game';
import { calculateArmyPower, getTotalTroopCount } from './combat';

export function runNationAIMonthly(
  nationId: string,
  state: GameState,
  logNotification: (title: string, message: string, type: 'war' | 'peace' | 'diplomacy' | 'tech' | 'event' | 'economy') => void
): Partial<GameState> {
  const nation = state.nations[nationId];
  if (!nation || nation.isPlayer) return {};

  const updatedNations = { ...state.nations };
  const updatedProvinces = { ...state.provinces };
  const updatedArmies = { ...state.armies };
  const updatedDiplomacy = { ...state.diplomacy };
  const updatedWars = [...state.wars];

  // 1. Research technology if techPoints available
  const availableTechs = Object.values(state.technologies).filter(
    tech => !nation.researchedTechs.includes(tech.id) && nation.techPoints >= tech.cost
  );

  if (availableTechs.length > 0) {
    let chosenTech: Technology = availableTechs[0];
    if (nation.aiPersonality === 'militarist' || nation.aiPersonality === 'expansionist') {
      const milTech = availableTechs.find(t => t.category === 'military');
      if (milTech) chosenTech = milTech;
    } else if (nation.aiPersonality === 'commercial') {
      const ecoTech = availableTechs.find(t => t.category === 'economy');
      if (ecoTech) chosenTech = ecoTech;
    } else if (nation.aiPersonality === 'diplomatic') {
      const admTech = availableTechs.find(t => t.category === 'administration');
      if (admTech) chosenTech = admTech;
    }

    if (nation.techPoints >= chosenTech.cost) {
      nation.techPoints -= chosenTech.cost;
      nation.researchedTechs.push(chosenTech.id);
    }
  }

  // 2. Construction of buildings in provinces
  const ownProvinces = Object.values(updatedProvinces).filter(p => p.ownerNationId === nationId);
  if (nation.treasury > 180 && ownProvinces.length > 0) {
    const provToBuild = ownProvinces.find(p => p.buildings.length < 3);
    if (provToBuild) {
      if (!provToBuild.buildings.includes('workshop') && (provToBuild.resource === 'iron' || provToBuild.resource === 'coal' || provToBuild.resource === 'gold' || provToBuild.resource === 'tar')) {
        provToBuild.buildings.push('workshop');
        nation.treasury -= 120;
      } else if (!provToBuild.buildings.includes('market')) {
        provToBuild.buildings.push('market');
        nation.treasury -= 100;
      } else if (!provToBuild.buildings.includes('barracks') && provToBuild.capital) {
        provToBuild.buildings.push('barracks');
        nation.treasury -= 110;
      }
    }
  }

  // 3. Military recruitment
  const ownArmies = Object.values(updatedArmies).filter(a => a.nationId === nationId && !a.isRebel);
  const totalTroops = ownArmies.reduce((sum, a) => sum + getTotalTroopCount(a), 0);

  if (nation.treasury > 150 && nation.manpower >= 3000 && totalTroops < 40000) {
    if (ownArmies.length > 0) {
      const army = ownArmies[0];
      const recruitInf = Math.min(2500, nation.manpower);
      const recruitCav = Math.min(600, Math.floor(nation.manpower / 4));
      army.units.infantry += recruitInf;
      army.units.cavalry += recruitCav;
      nation.manpower -= (recruitInf + recruitCav);
      nation.treasury -= 80;
    } else {
      const newArmyId = `army_${nationId}_${Date.now()}`;
      const recruitTotal = Math.min(6000, nation.manpower);
      const capProv = updatedProvinces[nation.capitalProvinceId] ? nation.capitalProvinceId : ownProvinces[0]?.id;
      if (capProv) {
        updatedArmies[newArmyId] = {
          id: newArmyId,
          name: `Полевой Корпус (${nation.name})`,
          nationId: nationId,
          provinceId: capProv,
          path: [],
          movementProgress: 0,
          units: {
            infantry: Math.floor(recruitTotal * 0.7),
            cavalry: Math.floor(recruitTotal * 0.2),
            artillery: 250,
            siege: 20,
            elite: 250
          },
          morale: 90,
          maxMorale: 100,
          general: { name: `Генерал ${nation.name}`, attack: 3, defense: 3, maneuver: 3, moraleBuff: 5 },
          isMoving: false,
          status: 'idle',
          isRebel: false,
          attritionRate: 0
        };
        nation.manpower -= recruitTotal;
        nation.treasury -= 120;
      }
    }
  }

  // 4. Rebellion Mechanic: Provinces with unrest > 50% spawn armed rebels!
  ownProvinces.forEach(prov => {
    if (prov.unrest > 50 && Math.random() < 0.08) {
      const rebelId = `rebel_${prov.id}_${Date.now()}`;
      const rebelCount = Math.round(prov.population * 0.015);
      updatedArmies[rebelId] = {
        id: rebelId,
        name: `Повстанцы (${prov.name})`,
        nationId: 'rebels',
        provinceId: prov.id,
        path: [],
        movementProgress: 0,
        units: {
          infantry: Math.min(15000, Math.max(3000, rebelCount)),
          cavalry: 500,
          artillery: 100,
          siege: 10,
          elite: 0
        },
        morale: 80,
        maxMorale: 100,
        general: { name: `Атаман повстанцев`, attack: 4, defense: 4, maneuver: 2, moraleBuff: 8 },
        isMoving: false,
        status: 'idle',
        isRebel: true,
        attritionRate: 0
      };
      prov.unrest = 20; // relieved temporarily by revolt outbreak
      logNotification(
        'Восстание сепаратистов!',
        `В провинции ${prov.name} вспыхнул вооруженный мятеж против центральной власти!`,
        'war'
      );
    }
  });

  // 5. Coalition against high Infamy / Aggressive Expansion
  const player = state.nations[state.playerNationId];
  if (player && player.infamy > 50 && !nation.isPlayer) {
    const relWithPlayer = updatedDiplomacy[nationId]?.[state.playerNationId];
    if (relWithPlayer && !relWithPlayer.isAllied && !relWithPlayer.isAtWar && relWithPlayer.opinion < 0) {
      // Join coalition, declare rival
      if (!nation.rivalIds.includes(state.playerNationId)) {
        nation.rivalIds.push(state.playerNationId);
        relWithPlayer.attitude = 'nemesis';
        relWithPlayer.attitudeReason = 'Антикоалиция против агрессивного гегемона (-100)';
        relWithPlayer.opinion = Math.max(-100, relWithPlayer.opinion - 30);
      }

      // If coalition member is strong, 5% chance to declare Coalition War
      if (player.infamy > 75 && Math.random() < 0.04) {
        relWithPlayer.isAtWar = true;
        if (updatedDiplomacy[state.playerNationId]?.[nationId]) {
          updatedDiplomacy[state.playerNationId][nationId].isAtWar = true;
        }
        const newWar: War = {
          id: `war_coalition_${Date.now()}`,
          name: `Коалиционная война сдерживания: ${nation.name} против ${player.name}`,
          attackers: [nationId],
          defenders: [state.playerNationId],
          warGoal: 'Сдерживание агрессивной экспансии',
          warScore: 0,
          startDate: `${state.currentDate.day}.${state.currentDate.month}.${state.currentDate.year}`,
          casualties: { [nationId]: 0, [state.playerNationId]: 0 }
        };
        updatedWars.push(newWar);
        logNotification(
          'Объявление Коалиционной Войны!',
          `Держава ${nation.name} сформировала военную коалицию против вашей империи за чрезмерное расширение!`,
          'war'
        );
      }
    }
  }

  // 6. Active wars & Army maneuvering
  const activeWars = updatedWars.filter(w => w.attackers.includes(nationId) || w.defenders.includes(nationId));
  const isAtWar = activeWars.length > 0;

  if (isAtWar) {
    const enemyNations: string[] = [];
    activeWars.forEach(w => {
      if (w.attackers.includes(nationId)) {
        enemyNations.push(...w.defenders);
      } else {
        enemyNations.push(...w.attackers);
      }
    });

    ownArmies.forEach(army => {
      if (army.status === 'idle' && !army.isMoving) {
        const currentProv = updatedProvinces[army.provinceId];
        if (!currentProv) return;

        const enemyAdjacent = currentProv.neighborIds.find(nid => {
          const np = updatedProvinces[nid];
          return np && enemyNations.includes(np.ownerNationId);
        });

        if (enemyAdjacent) {
          army.targetProvinceId = enemyAdjacent;
          army.path = [enemyAdjacent];
          army.isMoving = true;
          army.status = 'moving';
          army.movementProgress = 0;
        } else {
          const anyNeighbor = currentProv.neighborIds[0];
          if (anyNeighbor) {
            army.targetProvinceId = anyNeighbor;
            army.path = [anyNeighbor];
            army.isMoving = true;
            army.status = 'moving';
            army.movementProgress = 0;
          }
        }
      }
    });
  }

  return {
    nations: updatedNations,
    provinces: updatedProvinces,
    armies: updatedArmies,
    diplomacy: updatedDiplomacy,
    wars: updatedWars
  };
}
