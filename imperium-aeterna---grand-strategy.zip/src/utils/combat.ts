import { Army, Battle, Province, TerrainType } from '../types/game';

export interface CombatRoundResult {
  attackerCasualties: number;
  defenderCasualties: number;
  attackerMoraleChange: number;
  defenderMoraleChange: number;
  isOver: boolean;
  victorNationId?: string;
}

export function calculateArmyPower(army: Army): number {
  const { infantry, cavalry, artillery, siege, elite } = army.units;
  const rawPower = (infantry * 1.0) + (cavalry * 1.6) + (artillery * 2.5) + (siege * 0.8) + (elite * 2.2);
  const moraleMult = Math.max(0.2, army.morale / 100);
  const genBonus = army.general ? 1 + ((army.general.attack + army.general.defense) * 0.05) : 1;
  return Math.round(rawPower * moraleMult * genBonus);
}

export function getTotalTroopCount(army: Army): number {
  const { infantry, cavalry, artillery, siege, elite } = army.units;
  return infantry + cavalry + artillery + siege + elite;
}

export function resolveCombatRound(
  attackerArmy: Army,
  defenderArmy: Army,
  province: Province
): CombatRoundResult {
  const terrain = province.terrain;

  // Dice rolls (1-10)
  const attDice = Math.floor(Math.random() * 10) + 1;
  const defDice = Math.floor(Math.random() * 10) + 1;

  const attGen = attackerArmy.general ? attackerArmy.general.attack : 0;
  const defGen = defenderArmy.general ? defenderArmy.general.defense : 0;

  // Terrain modifiers
  let defTerrainBonus = 0;
  let attTerrainPenalty = 0;
  if (terrain === 'mountains') {
    defTerrainBonus = 3;
    attTerrainPenalty = 2;
  } else if (terrain === 'hills') {
    defTerrainBonus = 1.5;
  } else if (terrain === 'marsh') {
    attTerrainPenalty = 1.5;
  }

  const attScore = attDice + attGen - attTerrainPenalty;
  const defScore = defDice + defGen + defTerrainBonus;

  // Total counts
  const attTotal = getTotalTroopCount(attackerArmy);
  const defTotal = getTotalTroopCount(defenderArmy);

  if (attTotal <= 0) {
    return {
      attackerCasualties: 0,
      defenderCasualties: 0,
      attackerMoraleChange: -100,
      defenderMoraleChange: 0,
      isOver: true,
      victorNationId: defenderArmy.nationId
    };
  }

  if (defTotal <= 0) {
    return {
      attackerCasualties: 0,
      defenderCasualties: 0,
      attackerMoraleChange: 0,
      defenderMoraleChange: -100,
      isOver: true,
      victorNationId: attackerArmy.nationId
    };
  }

  // Base casualty rate per tick: ~2-5% of opposing troops, modulated by score diff
  const diff = attScore - defScore;
  const attLossRate = Math.max(0.01, 0.035 - (diff * 0.003));
  const defLossRate = Math.max(0.01, 0.035 + (diff * 0.003));

  const attCasualties = Math.min(attTotal, Math.round(attTotal * attLossRate + (defDice * 15)));
  const defCasualties = Math.min(defTotal, Math.round(defTotal * defLossRate + (attDice * 15)));

  // Morale damage
  const attMoraleDrop = Math.round(5 + (defScore * 1.5));
  const defMoraleDrop = Math.round(5 + (attScore * 1.5));

  const nextAttMorale = Math.max(0, attackerArmy.morale - attMoraleDrop);
  const nextDefMorale = Math.max(0, defenderArmy.morale - defMoraleDrop);

  let isOver = false;
  let victorNationId: string | undefined = undefined;

  if (nextAttMorale <= 0 && nextDefMorale <= 0) {
    // Both broke; defender wins by field retention
    isOver = true;
    victorNationId = defenderArmy.nationId;
  } else if (nextAttMorale <= 0 || (attTotal - attCasualties) <= 50) {
    isOver = true;
    victorNationId = defenderArmy.nationId;
  } else if (nextDefMorale <= 0 || (defTotal - defCasualties) <= 50) {
    isOver = true;
    victorNationId = attackerArmy.nationId;
  }

  return {
    attackerCasualties: attCasualties,
    defenderCasualties: defCasualties,
    attackerMoraleChange: -attMoraleDrop,
    defenderMoraleChange: -defMoraleDrop,
    isOver,
    victorNationId
  };
}

export function applyCasualties(army: Army, casualties: number): void {
  const total = getTotalTroopCount(army);
  if (total <= 0 || casualties <= 0) return;

  const ratio = Math.max(0, (total - casualties) / total);
  army.units.infantry = Math.max(0, Math.round(army.units.infantry * ratio));
  army.units.cavalry = Math.max(0, Math.round(army.units.cavalry * ratio));
  army.units.artillery = Math.max(0, Math.round(army.units.artillery * ratio));
  army.units.siege = Math.max(0, Math.round(army.units.siege * ratio));
  army.units.elite = Math.max(0, Math.round(army.units.elite * ratio));
}

// Calculate attrition if army exceeds province supply limit or marches through harsh hostile terrain
export function calculateSupplyAttrition(army: Army, province: Province, isHostile: boolean): number {
  const totalTroops = getTotalTroopCount(army);
  const supplyLimit = province.supplyLimit || 25000;

  let attritionRate = 0;
  if (totalTroops > supplyLimit) {
    const overflowRatio = (totalTroops - supplyLimit) / supplyLimit;
    attritionRate += Math.min(0.12, overflowRatio * 0.05);
  }

  if (isHostile) {
    attritionRate += 0.02; // Partisan and sabotage attrition
  }

  if (province.terrain === 'mountains' || province.terrain === 'marsh') {
    attritionRate += 0.03;
  }

  army.attritionRate = Math.round(attritionRate * 100);
  if (attritionRate <= 0) return 0;

  const casualties = Math.round(totalTroops * attritionRate);
  applyCasualties(army, casualties);
  army.morale = Math.max(20, army.morale - (attritionRate * 30));
  return casualties;
}
