import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as cn } from "./shell-CDtGCm80.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-DN1_Y5eS.js
var import_jsx_runtime = require_jsx_runtime();
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl bg-card p-5 text-ink shadow-border", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: cn("font-display text-lg font-medium tracking-tight text-ink", className),
		...props
	});
}
function CardDesc({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("mt-1 text-sm leading-relaxed text-muted", className),
		...props
	});
}
//#endregion
export { CardDesc as n, CardTitle as r, Card as t };
