import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Shell, n as EXAM_QUESTIONS, p as cn, t as Button, y as useProgress } from "./shell-CDtGCm80.mjs";
import { t as Badge } from "./badge-Df185QmB.mjs";
import { n as CardDesc, r as CardTitle, t as Card } from "./card-DN1_Y5eS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exam-CBNzqmVc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ExamPage() {
	const studentName = useProgress((s) => s.studentName);
	const examScore = useProgress((s) => s.examScore);
	const setExamScore = useProgress((s) => s.setExamScore);
	const [picks, setPicks] = (0, import_react.useState)({});
	const [submitted, setSubmitted] = (0, import_react.useState)(examScore !== null);
	const score = (0, import_react.useMemo)(() => {
		return EXAM_QUESTIONS.reduce((acc, q) => acc + (picks[q.id] === q.correct ? 1 : 0), 0);
	}, [picks]);
	const shown = submitted ? examScore ?? score : null;
	const passed = shown !== null && shown >= 7;
	const honors = shown !== null && shown >= 10;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: "Лекция 12 · зачёт"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-medium tracking-tight sm:text-4xl",
				children: "Журнал кафедры"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-lg text-muted",
				children: "Двенадцать вопросов. Семь — зачёт, десять — отличие. Можно пересдать."
			}),
			submitted && shown !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-8 rounded-2xl p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] tracking-[0.18em] text-faint uppercase",
						children: "Diploma"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "mt-2 text-2xl",
						children: honors ? "С отличием" : passed ? "Зачёт" : "Пока без зачёта"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDesc, { children: [
						studentName || "Слушатель",
						" · ",
						shown,
						"/12 · инженерия ИИ, боты → агенты"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-5",
						variant: "outline",
						onClick: () => {
							setSubmitted(false);
							setPicks({});
						},
						children: "Пересдать"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-10 space-y-8",
				children: EXAM_QUESTIONS.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-faint",
						children: String(i + 1).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-lg font-medium leading-snug",
						children: q.q
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2",
						children: q.options.map((opt, oi) => {
							const selected = picks[q.id] === oi;
							const reveal = submitted;
							const good = oi === q.correct;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: submitted,
								onClick: () => setPicks((p) => ({
									...p,
									[q.id]: oi
								})),
								className: cn("min-h-11 rounded-lg px-3 py-2.5 text-left text-sm leading-snug", selected ? "bg-paper-2 shadow-border" : "bg-card shadow-border", reveal && good && "bg-ok/10", reveal && selected && !good && "bg-danger/10"),
								children: opt
							}, opt);
						})
					}),
					submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: q.explain
					}) : null
				] }, q.id))
			}),
			!submitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-10",
				disabled: Object.keys(picks).length < EXAM_QUESTIONS.length,
				onClick: () => {
					setExamScore(score);
					setSubmitted(true);
				},
				children: "Сдать журнал"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
				className: "mt-10",
				variant: honors ? "forest" : passed ? "ok" : "warn",
				children: [shown, "/12"]
			})
		]
	}) });
}
//#endregion
export { ExamPage as component };
