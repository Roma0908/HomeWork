import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Shell, r as GLOSSARY } from "./shell-CDtGCm80.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/glossary-D4z7xqUI.js
var import_jsx_runtime = require_jsx_runtime();
function GlossaryPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: "Словарь кафедры"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-medium tracking-tight sm:text-4xl",
				children: "Глоссарий"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-lg text-muted",
				children: "Короткие определения. Если термин в лекции кажется чужим — вернись сюда."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-10 divide-y divide-rule",
				children: GLOSSARY.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1 py-5 sm:grid-cols-[180px_minmax(0,1fr)] sm:gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-medium text-ink",
						children: g.term
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-sm leading-relaxed text-muted sm:text-base",
						children: g.def
					})]
				}, g.term))
			})
		]
	}) });
}
//#endregion
export { GlossaryPage as component };
