import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { y as ArrowRight } from "../_libs/lucide-react.mjs";
import { c as Progress, h as lessonsFor, i as Input, l as Shell, o as LESSONS, s as Label, t as Button, u as TRACKS, y as useProgress } from "./shell-CDtGCm80.mjs";
import { t as Badge } from "./badge-Df185QmB.mjs";
import { n as CardDesc, r as CardTitle, t as Card } from "./card-DN1_Y5eS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQBHkgJt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const studentName = useProgress((s) => s.studentName);
	const setName = useProgress((s) => s.setName);
	const onboarded = useProgress((s) => s.onboarded);
	const setOnboarded = useProgress((s) => s.setOnboarded);
	const completed = useProgress((s) => s.completed);
	const lastLessonId = useProgress((s) => s.lastLessonId);
	const examScore = useProgress((s) => s.examScore);
	const [draft, setDraft] = (0, import_react.useState)(studentName);
	const done = LESSONS.filter((l) => completed[l.id]).length;
	const last = LESSONS.find((l) => l.id === lastLessonId) ?? LESSONS[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-4xl stagger-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.18em] text-muted uppercase",
				children: "Facultas · MMXXVI"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 max-w-xl text-4xl font-medium tracking-tight text-ink sm:text-5xl",
				children: "От ботов к настоящим агентам"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl font-display text-lg leading-relaxed text-muted",
				children: "Семестр кафедры инженерии ИИ. Двенадцать лекций, четыре лаборатории с живой моделью, зачёт. Сначала учимся называть вещи своими именами — потом собираем системы."
			}),
			!onboarded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 max-w-md rounded-2xl bg-card p-5 shadow-border",
				onSubmit: (e) => {
					e.preventDefault();
					setName(draft.trim().slice(0, 40));
					setOnboarded();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "name",
						children: "Как записать тебя в журнал"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "name",
						className: "mt-2",
						value: draft,
						placeholder: "Имя или псевдоним",
						onChange: (e) => setDraft(e.target.value.slice(0, 40))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Начать семестр"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => {
								setName("");
								setOnboarded();
							},
							children: "Остаться слушателем"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/lesson/$lessonId",
						params: { lessonId: last.id },
						children: [done === 0 ? "Первая лекция" : "Продолжить", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						studentName ? `${studentName} · ` : null,
						"лекция ",
						last.number,
						". ",
						last.title
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Прогресс семестра" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono tabular-nums",
						children: [
							done,
							"/",
							LESSONS.length
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					value: done / LESSONS.length * 100,
					className: "mt-2"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-4 sm:grid-cols-2",
				children: TRACKS.map((track) => {
					const list = lessonsFor(track.id);
					const n = list.filter((l) => completed[l.id]).length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "rounded-2xl p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] tracking-[0.16em] text-faint uppercase",
								children: track.latin
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
								className: "mt-2",
								children: track.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDesc, { children: track.blurb }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex flex-wrap gap-2",
								children: list.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/lesson/$lessonId",
									params: { lessonId: l.id },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: completed[l.id] ? "forest" : "default",
										children: l.number
									})
								}, l.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 font-mono text-xs tabular-nums text-faint",
								children: [
									n,
									"/",
									list.length
								]
							})
						]
					}, track.id);
				})
			}),
			examScore !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-8 rounded-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Зачёт сдан" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDesc, { children: [
					examScore,
					"/12",
					examScore >= 10 ? " · отличие" : examScore >= 7 ? " · зачёт" : " · стоит пересдать"
				] })]
			}) : null
		]
	}) });
}
//#endregion
export { Home as component };
