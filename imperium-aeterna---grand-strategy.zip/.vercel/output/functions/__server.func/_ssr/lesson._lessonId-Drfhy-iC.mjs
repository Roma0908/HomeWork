import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { B as notFound, b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as BookOpen, a as Search, b as ArrowLeft, d as Info, g as Bot, h as Check, m as FlaskConical, n as Wrench, p as Goal, r as TriangleAlert, s as PenLine, u as Lightbulb, v as ArrowUpRight, x as ArrowDown, y as ArrowRight } from "../_libs/lucide-react.mjs";
import { g as neighbors, i as Input, l as Shell, m as lessonById, p as cn, t as Button, y as useProgress } from "./shell-CDtGCm80.mjs";
import { t as Badge } from "./badge-Df185QmB.mjs";
import { n as Route } from "./router-BSlu4rsT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lesson._lessonId-Drfhy-iC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Floor({ icon: Icon, title, text, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex gap-3 rounded-lg bg-card p-3 shadow-border", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-md bg-paper-2 text-forest",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4",
				strokeWidth: 1.75
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 text-sm leading-relaxed text-muted",
			children: text
		})] })]
	});
}
function StackDiagram() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-6 grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Floor, {
				icon: Goal,
				title: "Агент",
				text: "Цель + цикл действий. Смотрит на результат и идёт дальше."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center text-faint",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Floor, {
				icon: Wrench,
				title: "Ассистент",
				text: "Диалог + инструменты. Человек ставит очередной запрос."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center text-faint",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Floor, {
				icon: Bot,
				title: "Бот",
				text: "Только разговор. Характер и правила, без рук в мире."
			})
		]
	});
}
function LoopDiagram() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
			children: [
				{
					t: "Цель",
					d: "Что должно получиться"
				},
				{
					t: "Мысль",
					d: "Какой шаг сейчас"
				},
				{
					t: "Действие",
					d: "Вызов инструмента"
				},
				{
					t: "Наблюдение",
					d: "Факт от программы"
				}
			].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-card p-3 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-faint",
						children: String(i + 1).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-medium text-ink",
						children: s.t
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm text-muted",
						children: s.d
					})
				]
			}, s.t))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-center text-sm text-muted",
			children: "Пока нет стопа: цель закрыта, лимит шагов, ошибка или вопрос человеку."
		})]
	});
}
function RagDiagram() {
	const cells = [
		{
			icon: Search,
			t: "Запрос",
			d: "Вопрос человека"
		},
		{
			icon: BookOpen,
			t: "Поиск",
			d: "Куски из вашей базы"
		},
		{
			icon: PenLine,
			t: "Промпт",
			d: "Устав + фрагменты"
		},
		{
			icon: Bot,
			t: "Ответ",
			d: "Только по источникам"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "my-6 flex flex-col gap-2 sm:flex-row sm:items-stretch",
		children: cells.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 rounded-lg bg-card p-3 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(c.icon, {
						className: "size-4 text-forest",
						strokeWidth: 1.75
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-medium text-ink",
						children: c.t
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: c.d
					})
				]
			}), i < cells.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "hidden size-4 shrink-0 text-faint sm:block" }) : null]
		}, c.t))
	});
}
function tokenize(s) {
	return s.match(/[A-Za-zА-Яа-яЁё]+|[0-9]+|[^\s]/g) ?? [];
}
function TokenWidget() {
	const [text, setText] = (0, import_react.useState)("Кафедра учит агентов.");
	const tokens = (0, import_react.useMemo)(() => tokenize(text), [text]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-6 rounded-xl bg-card p-4 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: "Разбор на токены — учебный, не промышленный BPE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "mt-3",
				value: text,
				onChange: (e) => setText(e.target.value.slice(0, 120)),
				"aria-label": "Фраза для разбора"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-1.5",
				children: tokens.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-md bg-paper-2 px-2 py-1 font-mono text-xs text-ink",
					children: t
				}, `${t}-${i}`))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-mono text-xs tabular-nums text-muted",
				children: [tokens.length, " кусков"]
			})
		]
	});
}
function TemperatureWidget() {
	const [t, setT] = (0, import_react.useState)(.3);
	const samples = t < .35 ? [
		"точный",
		"сухой",
		"повторяемый"
	] : t < .75 ? [
		"живой",
		"с вариантами",
		"ещё устойчивый"
	] : [
		"размашистый",
		"непредсказуемый",
		"легко врёт"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-6 rounded-xl bg-card p-4 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted",
					children: "Температура"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-sm tabular-nums text-ink",
					children: t.toFixed(1)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 1.2,
				step: .1,
				value: t,
				onChange: (e) => setT(Number(e.target.value)),
				className: "mt-3 h-11 w-full accent-forest",
				"aria-label": "Температура"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex flex-wrap gap-1.5",
				children: samples.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-paper-2 px-2.5 py-1 text-xs text-ink-soft",
					children: s
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: "Для бота-репетитора обычно 0.2–0.4. Для свободного персонажа — выше. Для агента с инструментами — снова низко."
			})
		]
	});
}
function RolesWidget() {
	const rows = [
		{
			role: "system",
			who: "Инженер",
			sample: "Ты репетитор 7 класса. До 5 предложений. Не выдумывай."
		},
		{
			role: "user",
			who: "Человек",
			sample: "Что такое дробь?"
		},
		{
			role: "assistant",
			who: "Модель",
			sample: "Дробь — это часть целого. Пример: 1/2 яблока."
		}
	];
	const [on, setOn] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-6 overflow-hidden rounded-xl bg-card shadow-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex border-b border-rule",
			children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setOn(i),
				className: cn("h-11 flex-1 px-2 text-sm font-medium transition-colors duration-150", on === i ? "bg-paper text-ink" : "bg-transparent text-muted hover:text-ink"),
				children: r.role
			}, r.role))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: rows[on].who
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-sm leading-relaxed text-ink",
				children: rows[on].sample
			})]
		})]
	});
}
function QuizBlock({ id, question, options, correct, explain, passed, onPass }) {
	const [pick, setPick] = (0, import_react.useState)(passed ? correct : null);
	const [checked, setChecked] = (0, import_react.useState)(Boolean(passed));
	const ok = pick === correct;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "my-8 rounded-xl bg-card p-5 shadow-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: "Проверка"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-lg font-medium leading-snug text-ink",
				children: question
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: options.map((opt, i) => {
					const selected = pick === i;
					const show = checked && selected;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setPick(i);
							setChecked(false);
						},
						className: cn("min-h-11 rounded-lg px-3 py-2.5 text-left text-sm leading-snug transition-[background-color,box-shadow] duration-150", selected ? "bg-paper-2 shadow-border" : "bg-paper hover:bg-paper-2", show && ok && "bg-ok/10", show && !ok && "bg-danger/10"),
						children: opt
					}, opt);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					disabled: pick === null,
					onClick: () => {
						if (pick === null) return;
						setChecked(true);
						onPass(id, pick === correct);
					},
					children: "Проверить"
				}), checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("text-sm", ok ? "text-ok" : "text-danger"),
					children: ok ? "Верно." : "Не то. Прочитай пояснение и попробуй ещё."
				}) : null]
			}),
			checked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: explain
			}) : null
		]
	});
}
function Callout({ tone, title, text }) {
	const Icon = tone === "warn" ? TriangleAlert : tone === "tip" ? Lightbulb : Info;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("my-6 rounded-xl p-4 shadow-border", tone === "warn" ? "bg-danger/5" : tone === "tip" ? "bg-forest/5" : "bg-card"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4 shrink-0",
				strokeWidth: 1.75
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: title
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-ink-soft",
			children: text
		})]
	});
}
function BlockView({ block }) {
	const markQuiz = useProgress((s) => s.markQuiz);
	const quizzes = useProgress((s) => s.quizzes);
	switch (block.type) {
		case "p": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "my-4 font-display text-base leading-relaxed text-ink-soft sm:text-lg",
			children: block.text
		});
		case "h": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-10 mb-3 text-xl font-medium text-ink",
			children: block.text
		});
		case "callout": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
			tone: block.tone,
			title: block.title,
			text: block.text
		});
		case "code": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
			className: "my-6 overflow-hidden rounded-xl bg-chalk shadow-chalk",
			children: [block.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "border-b border-dust/10 px-4 py-2 font-mono text-xs text-dust-2",
				children: block.title
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-dust",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: block.code })
			})]
		});
		case "compare": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "my-6 grid gap-3 sm:grid-cols-2",
			children: [block.left, block.right].map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-card p-4 shadow-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-ink",
					children: col.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: col.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm leading-relaxed text-muted",
						children: item
					}, item))
				})]
			}, col.title))
		});
		case "steps": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "my-6 space-y-3",
			children: block.items.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 rounded-xl bg-card p-4 shadow-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs tabular-nums text-faint",
					children: String(i + 1).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-ink",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: item.text
				})] })]
			}, item.title))
		});
		case "list": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "my-4 space-y-2",
			children: block.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex gap-3 text-sm leading-relaxed text-ink-soft sm:text-base",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-forest" }), item]
			}, item))
		});
		case "diagram":
			if (block.kind === "stack") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StackDiagram, {});
			if (block.kind === "loop") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoopDiagram, {});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RagDiagram, {});
		case "quiz": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizBlock, {
			id: block.id,
			question: block.question,
			options: block.options,
			correct: block.correct,
			explain: block.explain,
			passed: quizzes[block.id],
			onPass: markQuiz
		});
		case "lab": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/lab/$labId",
			params: { labId: block.labId },
			className: "my-6 flex items-start gap-3 rounded-xl bg-chalk p-4 text-dust shadow-chalk transition-colors duration-150 hover:bg-chalk-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, {
				className: "mt-0.5 size-4 shrink-0 text-dust-2",
				strokeWidth: 1.75
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 font-medium text-paper",
					children: [block.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-dust-2",
					children: block.hint
				})]
			})]
		});
		case "widget":
			if (block.kind === "tokens") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenWidget, {});
			if (block.kind === "temperature") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TemperatureWidget, {});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolesWidget, {});
		default: return null;
	}
}
function LessonBody({ lesson }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium tracking-wide text-muted",
				children: [
					"Лекция ",
					lesson.number,
					" · ",
					lesson.minutes,
					" мин"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-medium tracking-tight text-ink sm:text-4xl",
				children: lesson.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-lg leading-relaxed text-muted",
				children: lesson.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "forest",
					children: lesson.kicker
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: lesson.blocks.map((block, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockView, { block }, i))
			})
		]
	});
}
function LessonPage() {
	const { lessonId } = Route.useParams();
	const lesson = lessonById(lessonId);
	if (!lesson) throw notFound();
	const { prev, next } = neighbors(lesson.id);
	const markLesson = useProgress((s) => s.markLesson);
	const setLast = useProgress((s) => s.setLast);
	const completed = useProgress((s) => s.completed);
	(0, import_react.useEffect)(() => {
		setLast(lesson.id);
	}, [lesson.id, setLast]);
	const isExam = lesson.id === "exam";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonBody, { lesson }),
		isExam ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto mt-10 max-w-2xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/exam",
					children: ["Открыть зачёт", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
				})
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "mx-auto mt-12 flex max-w-2xl flex-col gap-3 border-t border-rule pt-6 sm:flex-row sm:items-center",
			children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/lesson/$lessonId",
					params: { lessonId: prev.id },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), prev.number]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-wrap items-center justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: completed[lesson.id] ? "forest" : "outline",
					onClick: () => markLesson(lesson.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), completed[lesson.id] ? "В журнале" : "Отметить прочитанным"]
				}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/lesson/$lessonId",
						params: { lessonId: next.id },
						children: ["Дальше", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/exam",
						children: ["К зачёту", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				})]
			})]
		})
	] });
}
//#endregion
export { LessonPage as component };
