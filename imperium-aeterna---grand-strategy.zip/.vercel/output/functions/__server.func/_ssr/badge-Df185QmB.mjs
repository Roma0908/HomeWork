import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { p as cn } from "./shell-CDtGCm80.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-Df185QmB.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-paper-2 text-ink-soft",
		ink: "bg-ink text-paper",
		chalk: "bg-chalk-2 text-dust",
		forest: "bg-forest/10 text-forest",
		ok: "bg-ok/10 text-ok",
		warn: "bg-warn/10 text-warn"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
