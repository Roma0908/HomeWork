//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DT-aOkuT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/exam",
			"/glossary",
			"/lab/$labId",
			"/lesson/$lessonId"
		],
		preloads: ["/assets/index-BWaeQNDE.js", "/assets/createLucideIcon-C85cKRl9.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BWaeQNDE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CCWsoWJJ.js",
			"/assets/shell-BhOoAib_.js",
			"/assets/arrow-right-Xx9gZwgK.js",
			"/assets/badge-CZOqjxXa.js",
			"/assets/card-V6RBQap_.js"
		]
	},
	"/exam": {
		filePath: "/workspace/src/routes/exam.tsx",
		children: void 0,
		preloads: [
			"/assets/exam-B2329ws-.js",
			"/assets/shell-BhOoAib_.js",
			"/assets/badge-CZOqjxXa.js",
			"/assets/card-V6RBQap_.js"
		]
	},
	"/glossary": {
		filePath: "/workspace/src/routes/glossary.tsx",
		children: void 0,
		preloads: ["/assets/glossary-D4zG0UVn.js", "/assets/shell-BhOoAib_.js"]
	},
	"/lab/$labId": {
		filePath: "/workspace/src/routes/lab.$labId.tsx",
		children: void 0,
		preloads: [
			"/assets/lab._labId-B_umwzXV.js",
			"/assets/shell-BhOoAib_.js",
			"/assets/badge-CZOqjxXa.js"
		]
	},
	"/lesson/$lessonId": {
		filePath: "/workspace/src/routes/lesson.$lessonId.tsx",
		children: void 0,
		preloads: [
			"/assets/lesson._lessonId-CNDlr5aL.js",
			"/assets/shell-BhOoAib_.js",
			"/assets/arrow-right-Xx9gZwgK.js",
			"/assets/badge-CZOqjxXa.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
